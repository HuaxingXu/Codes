<?php
class AppModel extends Model {	
	protected $_validate = array();
	protected $_auto = array();
	
}
?>