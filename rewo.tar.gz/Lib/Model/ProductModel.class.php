<?php
class ProductModel extends Model {	
	protected $_validate = array();
	protected $_auto = array();
	
}
?>