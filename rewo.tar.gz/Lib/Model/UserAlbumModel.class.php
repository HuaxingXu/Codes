<?php
//userapp的model
class UserAlbumModel extends Model {
}
?>
