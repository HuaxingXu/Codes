<?php
//userapp的model
class UserMessageModel extends Model {
}
?>
