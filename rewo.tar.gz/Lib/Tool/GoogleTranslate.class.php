<?php
class GoogleTranslate
{   
    public static function Translate($text='', $from='', $to='')
    {

        $GoogleURL = 'http://translate.google.com/translate_a/t';
	$snoopy="Lib/Tool/Snoopy.class.php";

        if (is_file($snoopy))
        {
            require_once $snoopy;
            $snoopy = new Snoopy();
            $snoopy->agent = 'Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1';
            $snoopy->accept= 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
            $snoopy->referer = '	http://translate.google.cn/?hl=zh-CN';
            $snoopy->rawheaders['Accept-Language'] = 'zh-cn,zh;q=0.5';
        }else{
            echo "file '$snoopy' do not exists!";
            exit;
        }
        
        $vars['client'] = 't';
        $vars['hl'] = 'zh-CN';
        //$vars['js'] = 'n';
        //$vars['layout'] = 2;

        //$vars['prev'] = '_t';
        //$vars['multires'] = 1;
        $vars['multires'] = 1;
        $vars['otf'] = 1;
        $vars['pc'] = 1;
        $vars['ssel'] = 5;
        $vars['tsel'] = 0;
        $vars['swap'] = 1;


        $vars['sl'] = $from;
        $vars['tl'] = $to;
        $vars['text'] = $text;

        if(!$text)
        {
            return NULL;
        }
        $snoopy->submit($GoogleURL, $vars);
        $strdata = $snoopy->results;

        $strdata = str_replace(',,', ',"",', $strdata);
        $strdata = str_replace(',,', ',"",', $strdata);
        
        $traslatearray = json_decode($strdata);
        
        for($a =0; $a < count($traslatearray['0']); $a++)
        {
            $result .= $traslatearray['0'][$a]['0'];
        }
        return $result;
    }

}
