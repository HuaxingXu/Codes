<?php if (!defined('THINK_PATH')) exit(); $title_num=5; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content ="text/html; charset=UTF-8" http-equiv="Content-Type" />
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <script src="__ROOT__/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script_help.js" type="text/javascript"></script>
        <link type="text/css" href="__ROOT__/Css/css.css" rel="stylesheet" />
        
            
    <title>REWO-<?php echo WebTranslate('帮助'); ?></title> 
	</head>
	<body>
    <center>
    
    <table width="100%" border="0" id="main_tb" cellpadding="0" cellspacing="0">
    <tr><td align="center" valign="top">
    
    	<table width="1000" cellpadding="0" cellspacing="0" border="0">
            <tr><td height="44"></td></tr>
        	<tr><td height="79" align="center" valign="top">
             <a href="__ROOT__/">
            <img src="__ROOT__/Image/rewo_logo.png"/>
            </a>
            </td></tr>
            <tr><td align="center" valign="middle">
            <div id="title_bar">
            				<?php
 $title_style1="title_bar_tb"; $title_style2="title_bar_tb"; $title_style3="title_bar_tb"; $title_style4="title_bar_tb"; $title_style5="title_bar_tb"; $title_style6="title_bar_tb"; if(intval($title_num)==0) $title_num=1; $whichTitle="title_style".$title_num; $$whichTitle="title_bar_tb title_".$title_num; ?>

<table border="0" style="position:absolute;margin-top:-120px;" width="963" height="20" cellpadding="0" cellspacing="0">
<tr><td width="930" align="right" valign="middle">
<lable style="font-size:14px;">
<a href="javascript:chooseLanguage('__ROOT__','zh_CN')" style="color:#ffffff;">中文</a>
<font style="color:#ffffff;">|</font>
<a href="javascript:chooseLanguage('__ROOT__','en')" style="color:#ffffff;">English</a>
</lable>
</td><td width="33">


</td></tr>
</table>

                <table border="0" width="963" height="38" cellpadding="0" cellspacing="0">
                	<tr>
                    	<td width="97" id="title_1" class="title_bar_tb" onclick="document.location.href='__ROOT__/'" align="center" valign="middle">
                        <div style="width:97px; height:38px;" class="<?php echo ($title_style1); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;">REWO</td></tr></table>
			</div>
                        </td>
                        <td width="94" id="title_2" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Product/product'">
                        <div style="width:94px; height:38px;" class="<?php echo ($title_style2); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("产品");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_3" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/App/app'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style3); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("应用");?></td></tr></table>
			</div>
                        </td>
                        <td width="91" id="title_4" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/User/user'">
                         <div style="width:91px; height:38px;" class="<?php echo ($title_style4); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("个人");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_5" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Help/help'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style5); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("帮助");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" class="title_bar_tb" id="title_6" onclick="document.location.href='__ROOT__/index.php/Contact/contact'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style6); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("关于我们");?></td></tr></table>
			</div>
                        </td>
                        <td width="0"></td>

			<td width="242" align="right" valign="middle">

<?php
 if(isset($_SESSION["user"])) { ?>
                        <?php echo "<a href='__ROOT__/index.php/User/user' style='color:#2c2c2e;font-size:12px;'>".cut_str($_SESSION["user"],5)."&nbsp;".WebTranslate('欢迎您')."!</a>"; ?>
                        <a href="__ROOT__/index.php/User/logout" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('退出');?></a>
                        <?php }else{ ?>
                        <a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('登陆');?></a>
                        <?php } ?>
                        <font color="#999999">|</font>
<a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;">
<?php echo WebTranslate('注册');?></a>&nbsp;
</td>

                        <td width="6"></td>
                        <td width="114" align="left" valign="middle">

                        <input type="text" value="" class="title_bar_search" id="search" onkeyup="if(event.keyCode==13){dealSearch('__ROOT__');}" onfocus="inTitleBar('__ROOT__')" onblur="outTitleBar('__ROOT__')"/>
                        <img src="__ROOT__/Image/title_bar_bg_w.png" style="display:none;" />
                        </td>
                        <td width="37" class="title_bar_tb" onclick="dealSearch('__ROOT__')"></td>
                    </tr>
                </table>
            </div>
            </td></tr>


            <tr><td height="30"></td></tr>
            <tr><td align="center" valign="top">
            	<div class="help_top">
                <table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">
               <tr>
               <td width="50">&nbsp;</td>
               <td width="155" align="center" valign="middle" class="sub_title_word"><?php echo WebTranslate('帮助与支持'); ?></td>
               <td>&nbsp;</td></tr>
               </table>
                </div>
                
                <div class="product_frame_middle">
                <table border="0" cellpadding="0" cellspacing="0">
                
            	
            <tr><td height="10" align="center" valign="top">
               	<div class="help_sub_pic_frame">
               		<table border="0" cellpadding="0" cellspacing="0" width="870px">
               			<tr>
               				<td align="left" valign="top" width="378px" id="help_tb">
                            
                            <?php
 $now_type_id=1; $now_id=1; if(isset($_REQUEST["id"])) $now_id=$_REQUEST["id"]; if(isset($_REQUEST["type_id"])) $now_type_id=$_REQUEST["type_id"]; ?>
                            
               				<!-- 添加了 id="help_common" 用作锚点 -->
               					<div style="height:550px; overflow-y:auto">
	               					<?php if(is_array($types)): foreach($types as $key=>$type): if(($type["type_id"] == $now_type_id)): ?><h2 type_id="<?php echo ($type["type_id"]); ?>" class="help_title help_bar" style="cursor:pointer;" onclick="select_help_type(<?php echo ($type["type_id"]); ?>)"><?php echo WebTranslate($type['type_name']); ?> ^</h2>
	               							<div>
	               						<?php else: ?>
	               							<h2 type_id="<?php echo ($type["type_id"]); ?>" class="help_title help_bar" style="cursor:pointer;" onclick="select_help_type(<?php echo ($type["type_id"]); ?>)"><?php echo WebTranslate($type['type_name']); ?> &gt;</h2>
	               							<div style="display:none;"><?php endif; ?>
		               						<?php if(is_array($type["questions"])): foreach($type["questions"] as $key=>$ques): if(($ques["id"] == $now_id)): ?><div style="cursor:pointer;display:inline-block;" qid="<?php echo ($ques["id"]); ?>" class="help_question help_question_select" onclick="select_question('__ROOT__', <?php echo ($ques["id"]); ?>)"><?php echo WebTranslate($ques["question"]);?></div>
				               						<!--[if !IE]><!-->
				               						<br/>
				               						<!--<![endif]-->
				               					<?php else: ?>
				               						<div style="cursor:pointer;display:inline-block;" qid="<?php echo ($ques["id"]); ?>" class="help_question" onclick="select_question('__ROOT__', <?php echo ($ques["id"]); ?>)"><?php echo WebTranslate($ques['question']); ?></div>
				               						<!--[if !IE]><!-->
				               						<br/>
				               						<!--<![endif]--><?php endif; endforeach; endif; ?>
				               				</div><?php endforeach; endif; ?>
               					</div>
               					<!-- 加了个图片 -->
                                <a href="__ROOT__/index.php/Contact/contact#ToLeaveProblem">
               					
                                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr><td align="right" valign="middle">
                                <table class="otherProblem" border="0" cellpadding="0" cellspacing="0">
                                <tr><td width="77" align="center" valign="middle"><?php echo WebTranslate("其它问题"); ?></td><td width="16">&nbsp;</td></tr></table>
                                </td><td width="10">&nbsp;</td></tr></table>
                                 </a>
               				</td>
			             	<td align="left" valign="top" width="43px">
			             		<img src="__ROOT__/Image/help_mid.png" alt="help_mid" />
				            </td>
				            <td align="left" valign="top" width="450px">
				            	<h4 id="answer_title" class="help_question_select"><?php echo WebTranslate($answer['question']); ?></h4>
				            	<div id="answer_content" class="help_content">
				            		<?php echo WebTranslate($answer['answer']); ?>
				            	</div>
				            	<div>
				            		<img src="__ROOT__/Image/help_pic.png" alt="img" />
				            	</div>
				            </td>
				        </tr>
	                 </table>
               	</div>
            	</td></tr>
            <tr><td align="center">
            	<div class="help_sub_pic_footer"></div>
            	</td></tr>
                
           
           </table>
           </div>
           <div class="product_frame_bottom"></div>
            </td></tr>
            
            <tr><td height="80"></td></tr>
            </table>
            </td></tr><tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">

               
            <tr><td height="65"></td></tr>
            
            <tr><td height="30" align="left" valign="top" class="footer_top_text">
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('网站地图');?></td></tr>
            <tr><td height="170" align="left" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr>
                    <td width="19"></td>
                        <td align="center" valign="top">
                        
                        <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('产品');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_new"><?php echo WebTranslate('新品推介');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_accessory"><?php echo WebTranslate('热门配件');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_meng"><?php echo WebTranslate('全部产品');?></a></td></tr>
                            </table>
                        
                        	
                            
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:60px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('应用');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#newApp"><?php echo WebTranslate('最新应用');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#downloadApp"><?php echo WebTranslate('应用下载');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	
                            <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('个人');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userApp#userApp"><?php echo WebTranslate('应用库');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userMsg#user_msg"><?php echo WebTranslate('未读消息');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/user#userDetail"><?php echo WebTranslate('个人信息');?></a></td></tr>
                            </table>
                            
                        </td>
                        
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="5" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:110px;"></div></td>
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('帮助');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('关于');?>REWO</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=11&type_id=3#help_common"><?php echo WebTranslate('驱动下载');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=15&type_id=2#help_common"><?php echo WebTranslate('使用步骤');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=1&type_id=1#help_common"><?php echo WebTranslate('常见问题');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            <tr>
                            <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:63px;"></div></td>
                            <!-- 网站地图的链接 -->
                            <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('关于我们');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/contact"><?php echo WebTranslate('联系方式');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('公司简介');?></a></td></tr>
                                
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td width="183"></td>
                        
                    </tr>
                </table>
            </td></tr>
            
            <tr><td height="20"></td></tr>
            
            </table>
            </td></tr>
            <tr><td class="footer_bg"></td></tr>
            <tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">
            
            <tr><td height="40" align="right" valign="top">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="1" rowspan="5"></td></tr>
            <tr><td width="55" align="center" valign="middle" class="footer_share"><?php echo WebTranslate('分享到');?> </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareWeibo('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_weibo.jpg" style="cursor:pointer;" alt="新浪微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
             <a href="javascript:shareQQ('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_tengxun.jpg" style="cursor:pointer;" alt="腾讯微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareRenren('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_renren.jpg" style="cursor:pointer;" alt="人人网"/></td>
            </a>
            <td width="40"></td>
            </tr>
            </table>
            
            </td></tr>
            </table>
            
            
            <div id="mask" style="display:none; height:100%">
           
             <div id="maskFaceDiv">
            	<div class="open_frame_top"></div>
                <div class="open_frame_middle">
                <table border="0" width="82%" height="100%" style="background-color:#ffffff;" cellpadding="0" cellspacing="0">
                <tr><td height="15" align="right" valign="top" style="float:right;">
                <label style="position:absolute; margin-top:-43px; margin-left:-3px;cursor:pointer;" onclick="closeMask()">
                <img src="__ROOT__/Image/coin_close.png"/>
                </label>
                </td></tr>
                <tr><td id="open_frame_title" height="30" align="left" valign="middle"
                 style="color:#929292; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_content" height="115" align="left" valign="top"
                 style="color:#030303; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_bottom" align="right" valign="bottom">
               
                </td></tr>
                <tr><td height="14"></td></tr>
                </table>
                </div>
                <div class="open_frame_bottom"></div>
            </div>
          
            </div>
           <div style="display:none;">
          <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fa0459d40afa2d5b581c169fc424d4509' type='text/javascript'%3E%3C/script%3E"));
</script>
         </div>
         
         <script> 
		<?php  $lang=""; if(isset($_SESSION["language"])) { if($_SESSION["language"]!="zh_CN") $lang=$_SESSION["language"]; } echo "AddDivTranslate('".$lang."');"; ?>
        </script>

           
            

        
        </td></tr></table>
        
    </center>
    </body>
</html>