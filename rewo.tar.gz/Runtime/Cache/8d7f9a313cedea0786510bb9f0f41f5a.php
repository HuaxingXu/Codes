<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/web/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <script src="__ROOT__/web/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/web/Script/script.js" type="text/javascript"></script>
        <link type="text/css" href="__ROOT__/web/Css/css.css" rel="stylesheet">
        <script>
			$(window).load(function() {
				$('#featured').orbit({
				bullets: false
				});
			}); 
		</script>
            
    <title>REWO-购物车</title> 
	</head>
	<body style="background:url(__ROOT__/web/Image/userDetail_bg.jpg);">
    <center>
    	<table width="1000" cellpadding="0" cellspacing="0" border="0">
            <tr><td height="44"></td></tr>
        	<tr><td height="79" align="center" valign="top"><img src="__ROOT__/web/Image/rewo_logo.png"/></td></tr>
            <tr><td align="center" valign="middle">
            <div id="title_bar" style="background:url(__ROOT__/web/Image/title_bar_user.png);">
            					<table border="0" width="100%" height="38" cellpadding="0" cellspacing="0">
                	<tr>
                    	<td width="97" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/'"></td>
                        <td width="98" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/Product/product'"></td>
                        <td width="98" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/App/app'"></td>
                        <td width="97" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/User/user'"></td>
                        <td width="98" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/Help/help'"></td>
                        <td width="98" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/Contact/contact'"></td>
                        
                        <td width="143"></td>
                        
                        <td width="38" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/User/loginRegister'"></td>
                        <td width="38" class="title_bar_tb" onclick="document.location.href='__ROOT__/web/index.php/User/loginRegister'"></td>
                        <td width="2"></td>
                        <td width="118" align="left" valign="middle">
                        <input type="text" value="" class="title_bar_search" id="search"/>
                        </td>
                        <td width="37" class="title_bar_tb"></td>
                    </tr>
                </table>
            </div>
            </td></tr>
            
            <!-- <tr><td height="34" align="left" valign="middle" class="product_frame_title">&nbsp;&nbsp;&nbsp;&nbsp;个人中心</td></tr>
      -->      
      		<tr><td height="30"></td></tr>
            <tr><td height="200" align="center" valign="top">
            <div class="user_center_top"></div>
            <div class="product_frame_middle">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="25" colspan="3"></td></tr>
            <tr><td align="right" valign="bottom" width="150">
            <img src="__ROOT__/web/Image/user/user_01.jpg"/>
            </td>
            <td width="15"></td>
            <td align="left" valign="bottom" width="775">
            	<table border="0" cellpadding="0" cellspacing="0">
                <tr><td align="left" valign="middle" class="userDetail_username">
                <?php
 if(isset($_SESSION["user"])) { echo $_SESSION["user"]; } ?>
                </td></tr>
                <tr><td height="3"></td></tr>
                <tr><td align="left" valign="middle" class="userDetail_nav">
                REWO&nbsp;-&nbsp;<font style="color:#8db4eb;">已连接</font>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/web/index.php/User/userMsg">未读信息(1)</a>
                <!-- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/web/index.php/User/userBuy">购物车(1)</a> -->
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/web/index.php/User/userApp">应用库(20)</a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/web/index.php/User/userDetail">个人信息</a>
                </td></tr>
                </table>
            </td></tr>
            <tr><td height="23" colspan="3"></td></tr>
            </table>
            
            </div>
            <div class="product_frame_bottom"></div>
            </td></tr>
            
             <tr><td height="34" align="left" valign="middle" class="product_frame_title">&nbsp;&nbsp;&nbsp;&nbsp;购物车</td></tr>
             <tr><td height="538" align="center" valign="top">
             <div class="product_frame_top"></div>
             <div class="product_frame_middle">
             
             <table border="0" width="890" cellpadding="0" cellspacing="0">
             <tr><td height="15"></td></tr>
             <tr><td height="40" align="left" valign="middle">
             	<table border="0" cellpadding="0" cellspacing="0" class="userBuy_nav">
                				<tr>
                	<td onclick="document.location.href='__ROOT__/web/index.php/User/userBuy'">&nbsp;</td>
                	<td onclick="document.location.href='__ROOT__/web/index.php/User/userBuyReceive'">&nbsp;</td>
                    <td onclick="document.location.href='__ROOT__/web/index.php/User/userBuyPay'">&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
             	</table>
             </td></tr>
             <tr><td height="23" align="left" valign="middle">
             	<table border="0" cellpadding="0" cellspacing="0" class="userBuy_title">
                <tr><td width="173"></td>
                <td align="center" valign="middle">商品信息</td><td width="80"></td>
                <td align="center" valign="middle">我的要求</td><td width="80"></td>
                <td align="center" valign="middle">为它结账</td><td width="95"></td>
                <td align="center" valign="middle">数量</td><td width="105"></td>
                <td align="center" valign="middle">价格</td><td width="75"></td>
                </tr>
                </table>
             </td></tr>
             <tr><td class="app_level_split">&nbsp;</td></tr>
             <tr><td align="left" valign="middle" height="160">
             	<table border="0" height="150" cellpadding="0" cellspacing="0">
                <tr><td align="center" valign="middle" width="130">
                <img src="__ROOT__/web/Image/product/product_buy_2_02.jpg"/>
                </td><td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <font class="userBuy_div_text">
                正品REWO2012打底毛衣韩版修身针织衫中长款羊绒衫秋冬新款颜色分类：圆领酒红（专柜正品）尺码：XL=5码
                </font>
                </div>
                </td>
                <td align="center" valign="middle" width="130">
                <textarea class="userBuy_request_input"></textarea>
                </td>
                <td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <img src="__ROOT__/web/Image/userBuy_right.jpg" style="position:absolute; margin-left:-30px; margin-top:25px;"/>
                </div>
                </td>
                <td align="center" valign="middle" width="130">
                	<table cellpadding="0" cellspacing="0" class="userBuy_tb">
                    <tr><td align="center" valign="top" height="17">
                    <img src="__ROOT__/web/Image/userBuy_addNum.jpg"/>
                    </td></tr>
                    <tr><td align="center" valign="middle" height="84" style="font-size:54px;">
                    1
                    </td></tr>
                    <tr><td align="center" valign="bottom" height="17">
                    <img src="__ROOT__/web/Image/userBuy_delNum.jpg" style="position:absolute; margin-top:-16px; margin-left:-44px;"/>
                    </td></tr>
                    </table>
                </td>
                <td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <font class="userBuy_price">
                <table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" valign="middle">888</td></tr>
                </table>
                </font>
                </div>
                </td>
                <td align="right" valign="bottom" width="100">
                <img src="__ROOT__/web/Image/userBuy_move.jpg"/>
                <br/><br/>
             	<img src="__ROOT__/web/Image/userBuy_confireMsg.jpg"/><br/><br/>
                </td></tr>
                </table>
             </td></tr>
             <tr><td class="app_level_split">&nbsp;</td></tr>
             <tr><td align="left" valign="middle" height="160">
             	<table border="0" height="150" cellpadding="0" cellspacing="0">
                <tr><td align="center" valign="middle" width="130">
                <img src="__ROOT__/web/Image/product/product_buy_2_02.jpg"/>
                </td><td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <font class="userBuy_div_text">
                正品REWO2012打底毛衣韩版修身针织衫中长款羊绒衫秋冬新款颜色分类：圆领酒红（专柜正品）尺码：XL=5码
                </font>
                </div>
                </td>
                <td align="center" valign="middle" width="130">
                <textarea class="userBuy_request_input"></textarea>
                </td>
                <td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <img src="__ROOT__/web/Image/userBuy_wrong.jpg" style="position:absolute; margin-left:-30px; margin-top:25px;"/>
                </div>
                </td>
                <td align="center" valign="middle" width="130">
                <table cellpadding="0" cellspacing="0" class="userBuy_tb">
                    <tr><td align="center" valign="top" height="17">
                    <img src="__ROOT__/web/Image/userBuy_addNum.jpg"/>
                    </td></tr>
                    <tr><td align="center" valign="middle" height="86" style="font-size:54px;">
                    2
                    </td></tr>
                     <tr><td align="center" valign="bottom" height="17">
                    <img src="__ROOT__/web/Image/userBuy_delNum.jpg" style="position:absolute; margin-top:-16px; margin-left:-44px;"/>
                    </td></tr>
                    </table>
                </td>
                <td align="center" valign="middle" width="130">
                <div class="userBuy_div">
                <font class="userBuy_price">
                <table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" valign="middle">999</td></tr>
                </table>
                </font>
                </div>
                </td>
                <td align="right" valign="bottom" width="100">
                <img src="__ROOT__/web/Image/userBuy_move.jpg"/>
                <br/><br/>
             	<img src="__ROOT__/web/Image/userBuy_confireMsg.jpg"/><br/><br/>
                </td></tr>
                </table>
             </td></tr>
             <tr><td class="app_level_split">&nbsp;</td></tr>
             <tr><td height="2"></td></tr>
             <tr><td height="35" valign="middle" align="right">
             <font class="userBuy_sum_text">总价 : 888元</font>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="__ROOT__/web/Image/userBuy_sum.jpg" style="position:absolute; margin-left:-100px; margin-top:-5px;"/>
             </td></tr>
             <tr><td height="20"></td></tr>
             </table>
             
             </div>
             <div class="product_frame_bottom"></div>
             </td></tr>
             
            
            <tr><td height="40"></td></tr>

               
            <tr><td height="65"></td></tr>
            
            <tr><td height="30" align="left" valign="top" class="footer_top_text">
            &nbsp;&nbsp;&nbsp;&nbsp;网站地图</td></tr>
            <tr><td height="170" align="center" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr>
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="6" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:130px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">个人</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/User/loginRegister">登录</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/User/loginRegister">注册</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/User/loginRegister">找回账号密码</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/User/user">个人信息</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/User/userApp">应用管理</a></td></tr>
                            </table>
                            
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:60px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">应用</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/App/app">最新应用</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/App/app">应用下载</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">产品</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Product/product#product_new">新品推介</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Product/product#product_accessory">热门配件</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Product/product#product_meng">全部产品</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                                <td align="left" valign="middle" class="footer_nav_th">试玩</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="#">试玩注册</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="#">试玩入口</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="#">试玩心得</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="5" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:110px;"></div></td>
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">帮助</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="#">关于REWO</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Help/help#help_download">驱动下载</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Help/help#help_common">使用步骤</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Help/help#help_common">常见问题</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            <tr>
                            <td rowspan="2" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:40px;"></div></td>
                            <!-- 网站地图的链接 -->
                            <td align="left" valign="middle" class="footer_nav_th">联系我们</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/web/index.php/Contact/contact">联系方式</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td width="183"></td>
                        
                    </tr>
                </table>
            </td></tr>
            
            <tr><td height="70"></td></tr>
            <tr><td height="40" align="right" valign="top">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="1" rowspan="5"></td></tr>
            <tr><td width="55" align="center" valign="middle" class="footer_share">分享到 </td>
            <td width="35" align="center" valign="middle"><img src="__ROOT__/web/Image/coin_weibo.jpg"/></td>
            <td width="35" align="center" valign="middle"><img src="__ROOT__/web/Image/coin_tengxun.jpg"/></td>
            <td width="35" align="center" valign="middle"><img src="__ROOT__/web/Image/coin_renren.jpg"/></td>
            <td width="40"></td>
            </tr>
            </table>
            
            </td></tr>
            </table>
            
            
            <div id="mask" style="display:none; height:100%">
           
             <div id="maskFaceDiv">
            	<div class="open_frame_top"></div>
                <div class="open_frame_middle">
                <table border="0" width="90%" height="100%" cellpadding="0" cellspacing="0">
                <tr><td height="15" align="right" valign="top">
                <img src="__ROOT__/web/Image/coin_close.png" style="position:absolute; margin-top:-43px; cursor:pointer;"
                onclick="closeMask()"/>
                </td></tr>
                <tr><td id="open_frame_title" height="30" align="left" valign="middle"
                 style="color:#929292; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_content" height="115" align="left" valign="top"
                 style="color:#030303; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_bottom" align="right" valign="bottom">
               
                </td></tr>
                <tr><td height="10"></td></tr>
                </table>
                </div>
                <div class="open_frame_bottom"></div>
            </div>
          
            </div>
           
           
            
        
    </center>
    </body>
</html>