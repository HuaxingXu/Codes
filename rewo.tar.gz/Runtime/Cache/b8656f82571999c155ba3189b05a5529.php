<?php if (!defined('THINK_PATH')) exit(); $title_num=4; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content ="text/html; charset=UTF-8" http-equiv="Content-Type" />
        <meta name="Author" content="SeekEver">
  		<meta name="Keywords" content="">
  		<meta name="Description" content="">
        <META HTTP-EQUIV="pragma" CONTENT="no-cache">
		<meta http-equiv="cache-control" content="no-cache">
		<meta http-equiv="expires" content="0">
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <script src="__ROOT__/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/jcrop/jquery.min.js" type="text/javascript"></script>
  		<script src="__ROOT__/Script/jcrop/jquery.Jcrop.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script_userDetail.js" type="text/javascript"></script>
        <link type="text/css" href="__ROOT__/Css/css.css" rel="stylesheet" />
        <link rel="stylesheet" href="__ROOT__/Css/jquery.Jcrop.css" type="text/css" />
		
            
    <title>REWO-<?php echo WebTranslate('个人信息'); ?></title> 
	</head>
	<body>
    <center>
    
    <table width="100%" border="0" id="main_tb" cellpadding="0" cellspacing="0">
    <tr><td align="center" valign="top">
    
    	<table width="1000" cellpadding="0" cellspacing="0" border="0">
            <tr><td height="44"></td></tr>
        	<tr><td height="79" align="center" valign="top">
             <a href="__ROOT__/">
            <img src="__ROOT__/Image/rewo_logo.png"/>
            </a>
            </td></tr>
            <tr><td align="center" valign="middle">
            <div id="title_bar">
            				<?php
 if(isset($_COOKIE["remindCookie"])&&(!isset($_SESSION["user"]))) $_SESSION["user"]=$_COOKIE["remindCookie"]; $title_style1="title_bar_tb"; $title_style2="title_bar_tb"; $title_style3="title_bar_tb"; $title_style4="title_bar_tb"; $title_style5="title_bar_tb"; $title_style6="title_bar_tb"; if(intval($title_num)==0) $title_num=1; $whichTitle="title_style".$title_num; $$whichTitle="title_bar_tb title_".$title_num; ?>

<table border="0" style="position:absolute;margin-top:-120px;" width="963" height="20" cellpadding="0" cellspacing="0">
<tr><td width="930" align="right" valign="middle">
<lable style="font-size:14px;">
<a href="javascript:chooseLanguage('__ROOT__','zh_CN')" style="color:#ffffff;">中文</a>
<font style="color:#ffffff;">|</font>
<a href="javascript:chooseLanguage('__ROOT__','en')" style="color:#ffffff;">English</a>
</lable>
</td><td width="33">


</td></tr>
</table>

                <table border="0" width="963" height="38" cellpadding="0" cellspacing="0">
                	<tr>
                    	<td width="97" id="title_1" class="title_bar_tb" onclick="document.location.href='__ROOT__/'" align="center" valign="middle">
                        <div style="width:97px; height:38px;" class="<?php echo ($title_style1); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;">REWO</td></tr></table>
			</div>
                        </td>
                        <td width="94" id="title_2" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Product/product'">
                        <div style="width:94px; height:38px;" class="<?php echo ($title_style2); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("产品");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_3" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/App/app'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style3); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("应用");?></td></tr></table>
			</div>
                        </td>
                        <td width="91" id="title_4" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/User/user'">
                         <div style="width:91px; height:38px;" class="<?php echo ($title_style4); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("个人");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_5" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Help/help'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style5); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("帮助");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" class="title_bar_tb" id="title_6" onclick="document.location.href='__ROOT__/index.php/Contact/contact'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style6); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("关于我们");?></td></tr></table>
			</div>
                        </td>
                        <td width="0"></td>

			<td width="242" align="right" valign="middle">

<?php
 if(isset($_SESSION["user"])) { ?>
                        <?php echo "<a href='__ROOT__/index.php/User/user' style='color:#2c2c2e;font-size:12px;'>".cut_str($_SESSION["user"],5)."&nbsp;".WebTranslate('欢迎您')."!</a>"; ?>
                        <a href="__ROOT__/index.php/User/logout" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('退出');?></a>
                        <?php }else{ ?>
                        <a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('登陆');?></a>
                        <?php } ?>
                        <font color="#999999">|</font>
<a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;">
<?php echo WebTranslate('注册');?></a>&nbsp;
</td>

                        <td width="6"></td>
                        <td width="114" align="left" valign="middle">

                        <input type="text" value="" class="title_bar_search" id="search" onkeyup="if(event.keyCode==13){dealSearch('__ROOT__');}" onfocus="inTitleBar('__ROOT__')" onblur="outTitleBar('__ROOT__')"/>
                        <img src="__ROOT__/Image/title_bar_bg_w.png" style="display:none;" />
                        </td>
                        <td width="37" class="title_bar_tb" onclick="dealSearch('__ROOT__')"></td>
                    </tr>
                </table>
            </div>
            </td></tr>

            
            <!-- <tr><td height="34" align="left" valign="middle" class="product_frame_title">&nbsp;&nbsp;&nbsp;&nbsp;个人中心</td></tr>
      -->      
      		<tr><td height="30"></td></tr>
            <tr><td height="200" align="center" valign="top">
            <div class="user_center_top">
            <table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">
               <tr>
               <td width="50">&nbsp;</td>
               <td width="155" align="center" valign="middle" class="sub_title_word"><?php echo WebTranslate('个人中心'); ?></td>
               <td>&nbsp;</td></tr>
               </table>
            </div>
            <div class="product_frame_middle">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="25" colspan="3"></td></tr>
            <tr><td align="right" valign="bottom" width="150">
            <img src="__ROOT__/aptana/public_image/user/<?php echo ($user["head_pic"]); ?>" style="width:121px;height:121px;"/>
            </td>
            <td width="15"></td>
            <td align="left" valign="bottom" width="775">
            	<table border="0" cellpadding="0" cellspacing="0">
                <tr><td align="left" valign="middle" class="userDetail_username">
                <?php
 if(isset($_SESSION["user"])) { echo "<font class='userDetail_username'>".$_SESSION["user"]."</font>"; if($is_band) echo "<font class='userDetail_robotLink'>&nbsp;-&nbsp;REWO/".WebTranslate('已绑定')."</font>"; else echo "<font class='userDetail_robotLink'>&nbsp;-&nbsp;REWO/<a href='__ROOT__/index.php/User/userConfig' style='color:#5992e1;'>".WebTranslate('未绑定')."</a></font>"; echo "<font class='userDetail_robotLink'>&nbsp;-&nbsp;".WebTranslate('已连接')."</font>"; } ?>
                </td></tr>
                <tr><td height="3"></td></tr>
                <tr><td align="left" valign="middle" class="userDetail_nav">
                <!-- REWO&nbsp;-&nbsp;<font style="color:#8db4eb;">已连接</font> -->
                <a href="__ROOT__/index.php/User/userConfig"><?php echo WebTranslate('配置'); ?>REWO</a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="__ROOT__/index.php/User/userApp"><?php echo WebTranslate('应用库');?>(<?php echo ($appNum); ?>)</a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/index.php/User/userMsg"><?php echo WebTranslate('未读信息');?>(<?php echo ($readNum); ?>)</a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/index.php/User/user"><?php echo WebTranslate('个人信息'); ?></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="__ROOT__/index.php/User/userGrow"><?php echo WebTranslate('REWO相册'); ?>(<?php echo ($albumNum); ?>)</a>
                </td></tr>
                </table>
            </td></tr>
            <tr><td height="23" colspan="3"></td></tr>
            </table>

            
            </div>
            <div class="product_frame_bottom"></div>
            </td></tr>
            <!-- 
             <tr><td height="34" align="left" valign="middle" class="product_frame_title">&nbsp;&nbsp;&nbsp;&nbsp;个人信息</td></tr>
              -->
              <tr><td height="30" id="userDetail"></td></tr>
             <tr><td height="538" align="center" valign="top">
             <div class="user_info_top">
             <table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">
               <tr>
               <td width="50">&nbsp;</td>
               <td width="155" align="center" valign="middle" class="sub_title_word"><?php echo WebTranslate('个人信息');?></td>
               <td>&nbsp;</td></tr>
               </table>
             </div>
             <div class="product_frame_middle">
             
             <table border="0" width="100%" cellpadding="0" cellspacing="0">
             <tr><td colspan="3" height="15"></td></tr>
             <tr><td width="40"></td><td align="left" width="400" valign="top">
             
             
             <table border="0" width="100%" cellpadding="0" cellspacing="0">
             <tr><td colspan="2"></td></tr>
             
             <tr><td colspan="2" align="left" valign="bottom" height="180">
             
             <table border="0" width="100%" cellpadding="0" cellspacing="0">
             <tr><td align="left" valign="bottom">
             
             <table border="0" width="100%" cellpadding="0" cellspacing="0">
             <tr><td align="left" valign="middle" width="125">
             <img src="__ROOT__/aptana/public_image/user/<?php echo ($user["head_pic"]); ?>" style="width:121px; height:121px;"/>
             </td><td width="5"></td>
             <td align="left" valign="bottom">
             <table border="0" cellpadding="0" cellspacing="0">
             <tr><td align="left" valign="bottom" class="userDetail_pic_text">
             <?php echo WebTranslate('你可以从电脑中你喜欢');?><br/><?php echo WebTranslate('的图片作为头像');?>
             </td></tr>
             <tr><td align="left" valign="middle" height="62"></td></tr>
             <tr><td align="left" valign="middle" height="30" class="userDetail_upload_text">
             
            
             <table class="coin_upload" onclick="uploadUserHead('__ROOT__')" style="cursor:pointer;" border="0" cellpadding="0" cellspacing="0">
             <tr><td align="center" valign="middle"><?php echo WebTranslate('上传');?></td></tr>
             </table>
             
             </td></tr>
             </table>
             </td></tr>
             </table>
             
             </td></tr>
             <tr><td colspan="2" height="10"></td></tr>
             <tr><td height="40" align="left" valign="middle" class="userDetail_username">
            	 <?php echo WebTranslate('性别');?>：
              <img id="sex_man" src="__ROOT__/Image/userDetail_selected.jpg" style="position:absolute; margin-top:3px;cursor:pointer;" 
              		onclick="select_sex('man')"/>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('男');?>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <img id="sex_woman" src="__ROOT__/Image/userDetail_not_selected.jpg" style="position:absolute; margin-top:3px;cursor:pointer;"
              		onclick="select_sex('woman')"/>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('女');?>
              <input id="sex_value" type="hidden" value="<?php echo ($user["sex"]); ?>" />
             </td></tr>
             </table>
             
             </td></tr>
             <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text"><?php echo WebTranslate('名称');?></td>
                <td align="left" valign="middle">
                <input id="username" type="text" class="userDetail_input" value="<?php echo ($user["username"]); ?>" onblur="check_username('__ROOT__')"/>
                <div id="check_username_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
             <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text"><?php echo WebTranslate('登录邮箱');?>：</td>
                <td align="left" valign="middle">
                <input id="email" type="text" class="userDetail_input" value="<?php echo ($user["email"]); ?>" onblur="check_email('__ROOT__')"/>
                <div id="check_email_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
	    <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text"><?php echo WebTranslate('个性签名');?>：</td>
                <td align="left" valign="middle">
                <input id="signature" type="text" class="userDetail_input" value="<?php echo ($user["signature"]); ?>" onblur="check_signature('__ROOT__')"/>
                <div id="check_signature_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
             
              <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text"><?php echo WebTranslate('登陆密码');?>：</td>
                <td align="left" valign="middle">
                <a href="__ROOT__/index.php/User/userModPwd" style="color:#2b86bb; text-decoration:underline;"><?php echo WebTranslate('修改');?></a>
                <input id="old_password" type="hidden" value=""/>
                <input id="new_password" type="hidden" value=""/>
                <input id="new_password_repeat" type="hidden" value=""/>
                </td>
             </tr>
             
             <!--
              <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text">现在密码：</td>
                <td align="left" valign="middle">
                <input id="old_password" type="password" class="userDetail_input" value="" onblur="check_old_password('__ROOT__')"/>
                <div id="check_old_password_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
             <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text">新密码：</td>
                <td align="left" valign="middle">
                <input id="new_password" type="password" class="userDetail_input" value="" onblur="check_new_password('__ROOT__')"/>
                <div id="check_new_password_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
             <tr>
             	<td width="68" height="36" align="left" valign="middle" class="userDetail_input_text">确认密码：</td>
                <td align="left" valign="middle">
                <input id="new_password_repeat" type="password" class="userDetail_input" value="" onblur="check_new_password_repeat('__ROOT__')"/>
                <div id="check_new_password_repeat_div" style="position:absolute; display:inline; z-index:10;"></div>
                </td>
             </tr>
             -->
            
             <tr><td></td><td height="45" align="left" valign="middle">
             <!--
             <img src="__ROOT__/Image/user_reduce.jpg" style="cursor:pointer;" onclick="reset_information('__ROOT__')"/>
             -->
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td width="110">&nbsp;</td><td align="left" valign="middle">
             <label style="cursor:pointer;" onclick="deal_save('__ROOT__')">
                  <div class="coin_login" style="font-size:12px;" >
                  <table style="cursor:pointer;display:inline;" border="0" cellpadding="0" cellspacing="0">
                            <tr><td width="95" height="28" align="center" valign="middle"><?php echo WebTranslate('保存'); ?></td></tr>
                            </table>
                  </div>
                  </label></td></tr></table>
             
             </td></tr>
             <tr><td colspan="2"></td></tr>
             </table>
             
             <!-- 加了个图片和调了一下间距 -->
             </td>
             <td align="center" valign="left" width="300">
             	<!-- <img src="__ROOT__/Image/user_tips.png" alt="" /> -->
                
                
                <table border="0" cellpadding="0" cellspacing="0">
             <tr><td height="0"></td></tr>
             <tr><td class="userConfigTipsTb" align="center" valign="top">
             
             	<table width="80%" border="0" cellpadding="0" cellspacing="0">
                <tr><td height="35"></td></tr>
                <tr><td align="left" valign="top" style="font-size:11px; color:#272727; letter-spacing:1px; line-height:23px;">
                <?php echo WebTranslate('你可以在这里更改你的个人信息等等，输入您的e-mail地址和密码。');?><br/><br/>
                <?php echo WebTranslate('如果你还没有创建账户，输入您的e-mail地址，姓名和密码，然后勾选 "我已阅读并接受使用" 框,然后使你可以点击
                "注册的条款及条款" 并创建一个账户');?>.<br/><br/><br/>
                <?php echo WebTranslate('在出现任何问题，请随时与我们联系单击 "联系我们" 页面导航');?>.
                </td></tr>
                </table>
                
             </td></tr>
             </table>
             
                
             </td>
             <td width="20px"></td></tr>
             </table>
             </div>
             <div class="product_frame_bottom"></div>
             </td></tr>
             
            
            <tr><td height="20"></td></tr>
			</table>
            </td></tr><tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">

               
            <tr><td height="65"></td></tr>
            
            <tr><td height="30" align="left" valign="top" class="footer_top_text">
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('网站地图');?></td></tr>
            <tr><td height="170" align="left" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr>
                    <td width="19"></td>
                        <td align="center" valign="top">
                        
                        <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('产品');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_new"><?php echo WebTranslate('新品推介');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_accessory"><?php echo WebTranslate('热门配件');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_meng"><?php echo WebTranslate('全部产品');?></a></td></tr>
                            </table>
                        
                        	
                            
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:60px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('应用');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#newApp"><?php echo WebTranslate('最新应用');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#downloadApp"><?php echo WebTranslate('应用下载');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	
                            <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('个人');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userApp#userApp"><?php echo WebTranslate('应用库');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userMsg#user_msg"><?php echo WebTranslate('未读消息');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/user#userDetail"><?php echo WebTranslate('个人信息');?></a></td></tr>
                            </table>
                            
                        </td>
                        
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="5" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:110px;"></div></td>
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('帮助');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('关于');?>REWO</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=11&type_id=3#help_common"><?php echo WebTranslate('驱动下载');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=15&type_id=2#help_common"><?php echo WebTranslate('使用步骤');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=1&type_id=1#help_common"><?php echo WebTranslate('常见问题');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            <tr>
                            <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:63px;"></div></td>
                            <!-- 网站地图的链接 -->
                            <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('关于我们');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/contact"><?php echo WebTranslate('联系方式');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('公司简介');?></a></td></tr>
                                
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td width="183"></td>
                        
                    </tr>
                </table>
            </td></tr>
            
            <tr><td height="20"></td></tr>
            
            </table>
            </td></tr>
            <tr><td class="footer_bg"></td></tr>
            <tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">
            
            <tr><td height="40" align="right" valign="top">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="1" rowspan="5"></td></tr>
            <tr><td width="55" align="center" valign="middle" class="footer_share"><?php echo WebTranslate('分享到');?> </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareWeibo('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_weibo.jpg" style="cursor:pointer;" alt="新浪微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
             <a href="javascript:shareQQ('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_tengxun.jpg" style="cursor:pointer;" alt="腾讯微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareRenren('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_renren.jpg" style="cursor:pointer;" alt="人人网"/></td>
            </a>
            <td width="40"></td>
            </tr>
            </table>
            
            </td></tr>
            </table>
            
            
            <div id="mask" style="display:none; height:100%">
           
             <div id="maskFaceDiv">
            	<div class="open_frame_top"></div>
                <div class="open_frame_middle">
                <table border="0" width="82%" height="100%" style="background-color:#ffffff;" cellpadding="0" cellspacing="0">
                <tr><td height="15" align="right" valign="top" style="float:right;">
                <label style="position:absolute; margin-top:-43px; margin-left:-3px;cursor:pointer;" onclick="closeMask()">
                <img src="__ROOT__/Image/coin_close.png"/>
                </label>
                </td></tr>
                <tr><td id="open_frame_title" height="30" align="left" valign="middle"
                 style="color:#929292; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_content" height="115" align="left" valign="top"
                 style="color:#030303; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_bottom" align="right" valign="bottom">
               
                </td></tr>
                <tr><td height="14"></td></tr>
                </table>
                </div>
                <div class="open_frame_bottom"></div>
            </div>
          
            </div>
           <div style="display:none;">
          <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fa0459d40afa2d5b581c169fc424d4509' type='text/javascript'%3E%3C/script%3E"));
</script>
         </div>
         
         <script> 
		<?php  $lang=""; if(isset($_SESSION["language"])) { if($_SESSION["language"]!="zh_CN") $lang=$_SESSION["language"]; } echo "AddDivTranslate('".$lang."');"; ?>
        </script>

           
            

        
         </td></tr></table>
                
    </center>
    </body>
</html>