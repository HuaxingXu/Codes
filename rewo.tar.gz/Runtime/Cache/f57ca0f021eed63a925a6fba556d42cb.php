<?php if (!defined('THINK_PATH')) exit(); $remindCookie=""; if(isset($_COOKIE["remindCookie"])) { $remindCookie=$_COOKIE["remindCookie"]; } ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <script src="__ROOT__/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script_loginRegister.js" type="text/javascript"></script>
        <link type="text/css" href="__ROOT__/Css/css.css" rel="stylesheet">
            
    <title>REWO-搜索结果</title> 
	</head>
	<body>
    <center>
    
    <?php
 $page=1; if(isset($_REQUEST["page"])) $page=intval($_REQUEST["page"]); $page_length=3; $begin_p=($page-1)*$page_length; $begin_a=($page-1)*$page_length; $end_p=$begin_p+$page_length; $end_a=$begin_a+$page_length; if($end_p>sizeof($productList)) $end_p=sizeof($productList); if($end_a>sizeof($appList)) $end_a=sizeof($appList); $all_count=sizeof($appList)+sizeof($productList); ?>
    
    <table width="100%" border="0" id="main_tb" cellpadding="0" cellspacing="0">
    <tr><td align="center" valign="top">
    
    	<table width="1000" cellpadding="0" cellspacing="0" border="0">
            <tr><td height="44"></td></tr>
        	<tr><td height="79" align="center" valign="top">
             <a href="__ROOT__/">
            <img src="__ROOT__/Image/rewo_logo.png"/>
            </a>
            </td></tr>
            <tr><td align="center" valign="middle">
            <div id="title_bar">
            				<?php
 $title_style1="title_bar_tb"; $title_style2="title_bar_tb"; $title_style3="title_bar_tb"; $title_style4="title_bar_tb"; $title_style5="title_bar_tb"; $title_style6="title_bar_tb"; if(intval($title_num)==0) $title_num=1; $whichTitle="title_style".$title_num; $$whichTitle="title_bar_tb title_".$title_num; ?>
                <table border="0" width="963" height="38" cellpadding="0" cellspacing="0">
                	<tr>
                    	<td width="97" id="title_1" class="title_bar_tb" onclick="document.location.href='__ROOT__/'">
                        <div style="width:97px; height:38px;" class="<?php echo ($title_style1); ?>"></div>
                        </td>
                        <td width="94" id="title_2" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Product/product'">
                        <div style="width:94px; height:38px;" class="<?php echo ($title_style2); ?>"></div>
                        </td>
                        <td width="93" id="title_3" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/App/app'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style3); ?>"></div>
                        </td>
                        <td width="91" id="title_4" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/User/user'">
                         <div style="width:91px; height:38px;" class="<?php echo ($title_style4); ?>"></div>
                        </td>
                        <td width="93" id="title_5" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Help/help'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style5); ?>"></div>
                        </td>
                        <td width="109" class="title_bar_tb" id="title_6" onclick="document.location.href='__ROOT__/index.php/Contact/contact'">
                        <div style="width:109px; height:38px;" class="<?php echo ($title_style6); ?>"></div>
                        </td>
                        <td width="4"></td>
                        <?php
 if(isset($_SESSION["user"])) { ?>
                        <td width="0"></td>
                        <td width="186" align="right" valign="middle">
                        <?php echo "<a href='__ROOT__/index.php/User/user' style='color:#2c2c2e;font-size:12px;'>".cut_str($_SESSION["user"],5)."&nbsp;欢迎您！</a>"; ?>
                        <a href="__ROOT__/index.php/User/logout" style="color:#fefffd; font-size:13px;">退出</a>&nbsp;&nbsp;&nbsp;
                        </td>
                        <?php }else{ ?>
                        <td width="0"></td>
                        <td width="186" class="title_bar_tb" align="right" valign="middle">
                        <a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;">登陆</a>&nbsp;&nbsp;&nbsp;
                        </td>
                        <?php } ?>
                        <td width="38" class="title_bar_tb" align="left" valign="middle" onclick="document.location.href='__ROOT__/index.php/User/loginRegister'" style="color:#fefffd; font-size:13px;">
                        注册
                        </td>
                        <td width="6"></td>
                        <td width="114" align="left" valign="middle">
                        <input type="text" value="" class="title_bar_search" id="search" onkeyup="if(event.keyCode==13){dealSearch('__ROOT__');}" onfocus="inTitleBar('__ROOT__')" onblur="outTitleBar('__ROOT__')"/>
                        <img src="__ROOT__/Image/title_bar_bg_w.png" style="display:none;" />
                        </td>
                        <td width="37" class="title_bar_tb" onclick="dealSearch('__ROOT__')"></td>
                    </tr>
                </table>
            </div>
            </td></tr>
            <tr><td height="15"></td></tr>
            <tr><td height="40" align="left" valign="middle" class="product_frame_title">&nbsp;&nbsp;&nbsp;&nbsp;搜索结果</td></tr>
            <tr><td height="0"></td></tr>
            
            <tr><td align="center" valign="top">
            <div class="product_frame_top"></div>
            <div class="product_frame_middle">
            
            <table width="86%" border="0" cellpadding="0" cellspacing="0">
            <tr><td height="15"></td></tr>
            
			<?php  if($isEmpty==1){ ?>
            <?php for($p=$begin_p;$p<$end_p;$p++){ ?>
            <tr><td align="left" valign="middle">
            	<table width="750" border="0" cellpadding="0" cellspacing="0">
                
                 <tr><td align="left" valign="middle" style="color:#000000; font-size:14px;">
                 
                 <img src="__ROOT__/Image/product/<?php echo $productList[$p]['series_id'].'/'.$productList[$p]['product_type'].'/'.$productList[$p]['image']; ?>" style="width:45px;"/>
                 
                 <label style="font-size:26px; color:#1b1b1b;">
                 <font color='#96da15'>REWO</font>
                 <?php echo removeREWO($productList[$p]["product_name"]); ?></label>
                 </td></tr>
                 <tr><td align="left" valign="middle" height="25" style="color:#1b1b1b; font-size:15px;">
                 <?php echo removeBR($productList[$p]["info"]); ?>&nbsp;&nbsp;&nbsp;价格：<?php echo $productList[$p]["price"]; ?>
                 </td></tr>
                  <tr><td align="left" valign="middle">
                 <a href="__ROOT__/index.php/Product/productDetail?product_id=<?php echo $productList[$p]["product_id"]; ?>" style="color:#96da15; font-size:14px; text-decoration:none;" target="_blank">
                 <?php echo "http://".$_SERVER ['HTTP_HOST'];?>__ROOT__/index.php/Product/productDetail?product_id=<?php echo $productList[$p]["product_id"]; ?>
                 </a>
                 </td></tr>
                 <tr><td colspan="2" height="13"></td></tr>
                 
                </table>
            </td></tr>
            <tr><td height="20"></td></tr>
            <?php } ?>
            
            <?php for($a=$begin_a;$a<$end_a;$a++){ ?>
            <tr><td align="left" valign="middle">
            	<table width="750" border="0" cellpadding="0" cellspacing="0">
                
                 <tr><td align="left" valign="middle" style="color:#000000; font-size:14px;">
                 
                 <img src="__ROOT__/public_image/apps/<?php echo $appList[$a]['category_dir'].'/'.$appList[$a]['app_dir'].'/ico_big.png'; ?>" style="width:45px;"/>
                 
                 <label style="font-size:26px; color:#1b1b1b;">
                 <font color='#96da15'>REWO</font>
                 <?php echo removeREWO($appList[$a]["name"]); ?></label>
                 </td></tr>
                 <tr><td align="left" valign="middle" height="25" style="color:#1b1b1b; font-size:15px;">
                 <?php echo removeBR($appList[$a]["info"]); ?>&nbsp;&nbsp;&nbsp;价格：<?php echo $appList[$a]["price"]; ?>
                 </td></tr>
                  <tr><td align="left" valign="middle">
                 <a href="__ROOT__/index.php/App/appOne?id=<?php echo $appList[$a]["id"]; ?>" style="color:#96da15; font-size:14px; text-decoration:none;" target="_blank">
                 <?php echo "http://".$_SERVER ['HTTP_HOST'];?>__ROOT__/index.php/App/appOne?id=<?php echo $appList[$a]["id"]; ?>
                 </a>
                 </td></tr>
                 <tr><td colspan="2" height="13"></td></tr>
                 
                </table>
            </td></tr>
            <tr><td height="20"></td></tr>
            <?php } ?>
            <?php }else{ ?>
            	<tr><td height="20"></td></tr>
            	<tr><td height="200" align="center" valign="top" style="color:#000000; font-size:14px;">没有搜索结果！</td></tr>
            <?php } ?>
            
            <tr><td height="15"></td></tr>
            
            <tr><td height="35" align="center" valign="middle">
            
            <?php  $now_page=1; if(isset($_REQUEST["page"])) $now_page=$_REQUEST["page"]; ?>
                                
                                <?php  $pre_page=$now_page-1; if($pre_page<=0) $pre_page=1; ?>
                                <a href="__ROOT__/index.php/Index/search?search=<?php echo $_REQUEST["search"]; ?>&page=<?php echo $pre_page;?>">
                         <img src="__ROOT__/Image/app_left_coin.jpg"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php  ?>
                                
                                <?php
 for($k=1;$k<intval(($all_count-1)/($page_length*2))+2;$k++) { if($k==$now_page) { ?>
                         
                         
                         
                        <a href="__ROOT__/index.php/Index/search?search=<?php echo $_REQUEST["search"]; ?>&page=<?php echo ($k); ?>">
                        <img src="__ROOT__/Image/app_coin_green.jpg"/></a>
                        <?php  }else{ ?>
                        <a href="__ROOT__/index.php/Index/search?search=<?php echo $_REQUEST["search"]; ?>&page=<?php echo ($k); ?>">
                        <img src="__ROOT__/Image/app_coin_while.jpg"/></a>
                        <?php } } ?>
                        
                         &nbsp;&nbsp;&nbsp;&nbsp;
                         <?php  $next_page=$now_page+1; if($next_page>$k-1) $next_page=$k-1; ?>
                         <a href="__ROOT__/index.php/Index/search?search=<?php echo $_REQUEST["search"]; ?>&page=<?php echo $next_page;?>">
                        <img src="__ROOT__/Image/app_right_coin.jpg"/></a>
                        <?php  ?>
            
            </td></tr>
            
            </table>
            
            </div>
            <div class="product_frame_bottom"></div>
            </td></tr>

            <tr><td height="64"></td></tr>
             </table>
            </td></tr><tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">

               
            <tr><td height="65"></td></tr>
            
            <tr><td height="30" align="left" valign="top" class="footer_top_text">
            &nbsp;&nbsp;&nbsp;&nbsp;网站地图</td></tr>
            <tr><td height="170" align="left" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr>
                    <td width="19"></td>
                        <td align="center" valign="top">
                        
                        <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">产品</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_new">新品推介</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_accessory">热门配件</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_meng">全部产品</a></td></tr>
                            </table>
                        
                        	
                            
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:60px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">应用</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#newApp">最新应用</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#downloadApp">应用下载</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	
                            <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">个人</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userApp#userApp">应用库</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userMsg#user_msg">未读消息</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/user#userDetail">个人信息</a></td></tr>
                            </table>
                            
                        </td>
                        
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="5" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:110px;"></div></td>
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th">帮助</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company">关于REWO</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=11&type_id=3#help_common">驱动下载</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=15&type_id=2#help_common">使用步骤</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=1&type_id=1#help_common">常见问题</a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            <tr>
                            <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:63px;"></div></td>
                            <!-- 网站地图的链接 -->
                            <td align="left" valign="middle" class="footer_nav_th">关于我们</td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/contact">联系方式</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company">公司简介</a></td></tr>
                                
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td width="183"></td>
                        
                    </tr>
                </table>
            </td></tr>
            
            <tr><td height="20"></td></tr>
            
            </table>
            </td></tr>
            <tr><td class="footer_bg"></td></tr>
            <tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">
            
            <tr><td height="40" align="right" valign="top">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="1" rowspan="5"></td></tr>
            <tr><td width="55" align="center" valign="middle" class="footer_share">分享到 </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareWeibo('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_weibo.jpg" style="cursor:pointer;" alt="新浪微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
             <a href="javascript:shareQQ('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_tengxun.jpg" style="cursor:pointer;" alt="腾讯微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareRenren('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_renren.jpg" style="cursor:pointer;" alt="人人网"/></td>
            </a>
            <td width="40"></td>
            </tr>
            </table>
            
            </td></tr>
            </table>
            
            
            <div id="mask" style="display:none; height:100%">
           
             <div id="maskFaceDiv">
            	<div class="open_frame_top"></div>
                <div class="open_frame_middle">
                <table border="0" width="82%" height="100%" style="background-color:#ffffff;" cellpadding="0" cellspacing="0">
                <tr><td height="15" align="right" valign="top" style="float:right;">
                <label style="position:absolute; margin-top:-43px; margin-left:-3px;cursor:pointer;" onclick="closeMask()">
                <img src="__ROOT__/Image/coin_close.png"/>
                </label>
                </td></tr>
                <tr><td id="open_frame_title" height="30" align="left" valign="middle"
                 style="color:#929292; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_content" height="115" align="left" valign="top"
                 style="color:#030303; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_bottom" align="right" valign="bottom">
               
                </td></tr>
                <tr><td height="14"></td></tr>
                </table>
                </div>
                <div class="open_frame_bottom"></div>
            </div>
          
            </div>
           <div style="display:none;">
          <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fa0459d40afa2d5b581c169fc424d4509' type='text/javascript'%3E%3C/script%3E"));
</script>
         </div>


           
            
        
         </td></tr></table>
        
    </center>
    </body>
</html>