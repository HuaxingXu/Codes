<?php if (!defined('THINK_PATH')) exit(); $title_num=6; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content ="text/html; charset=UTF-8" http-equiv="Content-Type"/>
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <script src="__ROOT__/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script.js" type="text/javascript"></script>
        <script src="__ROOT__/Script/script_contact.js" type="text/javascript"></script>
        <link type="text/css" href="__ROOT__/Css/css.css" rel="stylesheet"/>

		<title>REWO-<?php echo WebTranslate('联系我们'); ?></title> 
	</head>
	<body>
    <center>
    
    <table width="100%" border="0" id="main_tb" cellpadding="0" cellspacing="0">
    <tr><td align="center" valign="top">
    
    	<table width="1000" cellpadding="0" cellspacing="0" border="0">
            <tr><td height="44"></td></tr>
        	<tr><td height="79" align="center" valign="top">
             <a href="__ROOT__/">
            <img src="__ROOT__/Image/rewo_logo.png"/>
            </a>
            </td></tr>
            <tr><td align="center" valign="middle">
            <div id="title_bar">
            				<?php
 $title_style1="title_bar_tb"; $title_style2="title_bar_tb"; $title_style3="title_bar_tb"; $title_style4="title_bar_tb"; $title_style5="title_bar_tb"; $title_style6="title_bar_tb"; if(intval($title_num)==0) $title_num=1; $whichTitle="title_style".$title_num; $$whichTitle="title_bar_tb title_".$title_num; ?>

<table border="0" style="position:absolute;margin-top:-120px;" width="963" height="20" cellpadding="0" cellspacing="0">
<tr><td width="930" align="right" valign="middle">
<lable style="font-size:14px;">
<a href="javascript:chooseLanguage('__ROOT__','zh_CN')" style="color:#ffffff;">中文</a>
<font style="color:#ffffff;">|</font>
<a href="javascript:chooseLanguage('__ROOT__','en')" style="color:#ffffff;">English</a>
</lable>
</td><td width="33">


</td></tr>
</table>

                <table border="0" width="963" height="38" cellpadding="0" cellspacing="0">
                	<tr>
                    	<td width="97" id="title_1" class="title_bar_tb" onclick="document.location.href='__ROOT__/'" align="center" valign="middle">
                        <div style="width:97px; height:38px;" class="<?php echo ($title_style1); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;">REWO</td></tr></table>
			</div>
                        </td>
                        <td width="94" id="title_2" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Product/product'">
                        <div style="width:94px; height:38px;" class="<?php echo ($title_style2); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("产品");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_3" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/App/app'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style3); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("应用");?></td></tr></table>
			</div>
                        </td>
                        <td width="91" id="title_4" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/User/user'">
                         <div style="width:91px; height:38px;" class="<?php echo ($title_style4); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("个人");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" id="title_5" class="title_bar_tb" onclick="document.location.href='__ROOT__/index.php/Help/help'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style5); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("帮助");?></td></tr></table>
			</div>
                        </td>
                        <td width="93" class="title_bar_tb" id="title_6" onclick="document.location.href='__ROOT__/index.php/Contact/contact'">
                        <div style="width:93px; height:38px;" class="<?php echo ($title_style6); ?>">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
			<tr><td align="center" valign="middle" style="font-size:15px;"><?php echo WebTranslate("关于我们");?></td></tr></table>
			</div>
                        </td>
                        <td width="0"></td>

			<td width="242" align="right" valign="middle">

<?php
 if(isset($_SESSION["user"])) { ?>
                        <?php echo "<a href='__ROOT__/index.php/User/user' style='color:#2c2c2e;font-size:12px;'>".cut_str($_SESSION["user"],5)."&nbsp;".WebTranslate('欢迎您')."!</a>"; ?>
                        <a href="__ROOT__/index.php/User/logout" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('退出');?></a>
                        <?php }else{ ?>
                        <a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;"><?php echo WebTranslate('登陆');?></a>
                        <?php } ?>
                        <font color="#999999">|</font>
<a href="__ROOT__/index.php/User/loginRegister" style="color:#fefffd; font-size:13px;">
<?php echo WebTranslate('注册');?></a>&nbsp;
</td>

                        <td width="6"></td>
                        <td width="114" align="left" valign="middle">

                        <input type="text" value="" class="title_bar_search" id="search" onkeyup="if(event.keyCode==13){dealSearch('__ROOT__');}" onfocus="inTitleBar('__ROOT__')" onblur="outTitleBar('__ROOT__')"/>
                        <img src="__ROOT__/Image/title_bar_bg_w.png" style="display:none;" />
                        </td>
                        <td width="37" class="title_bar_tb" onclick="dealSearch('__ROOT__')"></td>
                    </tr>
                </table>
            </div>
            </td></tr>

            <!-- 
            <tr><td class="product_frame_title" align="left" valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;联系我们</td></tr>
             -->
            <tr><td height="3" align="left" valign="middle"></td></tr>
           
            <td><td height="30"></td></td>
            <tr><td height="656px" align="center" valign="top">
            <div class="contact_top2">
            
             <table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">
               <tr>
               <td width="50">&nbsp;</td>
               <td width="156" align="center" valign="middle" class="sub_title_word">
               <a href="__ROOT__/index.php/Contact/contact" style="color:#898989;"><?php echo WebTranslate('联系我们'); ?></a>
               </td>
               <td width="156" align="center" valign="middle" class="sub_title_word">&nbsp;
               <a href="__ROOT__/index.php/Contact/company" style="color:#000000;"><?php echo WebTranslate('公司简介'); ?></a>
               </td>
               <td>&nbsp;</td></tr>
               </table>
            
            </div>
            <div class="product_frame_middle">
               <table border="0" width="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" valign="middle">
                <img src="__ROOT__/Image/company_logo.jpg"/>
                </td></tr>
               	<tr><td height="25"></td></tr>
                <tr><td align="center" valign="top">
                	<table border="0" cellpadding="0" cellspacing="0" style="font-size:14px; letter-spacing:1px; line-height:25px; color:#000000;">
                    <tr><td width="921" align="left" valign="top">
                    	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('广州火里火（WO-Rehov）智能科技有限公司是由WO-Rehov团队创建的新锐科技企业，本公司拥有多项智能玩具技术专利，其产品是以玩具为载体，进行技术上的智能化设计与改造，实现玩具产品的语音控制、语音识别以及手机遥控等功能，同时与手机游戏相结合，从而实现玩具的科技化、智能化、益智化。'); ?><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('公司以中山大学微电子学系的强大师资力量为坚实后盾,以中山大学国家大学科技园为研发基地，其研发的语音智能技术、手机游戏玩具产品已获得国家相关专利认证。本公司志在成为智能玩具产业的领导者，将持续地研制开发智能玩具及其相关衍生产品，逐渐形成以智能玩具为核心的多元化经营集团公司。欢迎志同道合者加入Wo-Rehov，共创民族智能玩具产业的美好明天。'); ?>
                    </td></tr>
                    <tr><td height="35"></td></tr>
                    <tr><td align="right" valign="bottom"><?php echo WebTranslate('广州火里火智能科技有限责任公司'); ?></td></tr>
                    </table>
                </td></tr>
                <tr><td height="40"></td></tr>
               </table>
            </div>
            <div class="product_frame_bottom"></div>
            </td></tr>
            
            <tr><td height="30px"></td></tr>
            </table>
            </td></tr><tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">
    
              
            <tr><td height="65"></td></tr>
            
            <tr><td height="30" align="left" valign="top" class="footer_top_text">
            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo WebTranslate('网站地图');?></td></tr>
            <tr><td height="170" align="left" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr>
                    <td width="19"></td>
                        <td align="center" valign="top">
                        
                        <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('产品');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_new"><?php echo WebTranslate('新品推介');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_accessory"><?php echo WebTranslate('热门配件');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Product/product#product_meng"><?php echo WebTranslate('全部产品');?></a></td></tr>
                            </table>
                        
                        	
                            
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:60px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('应用');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#newApp"><?php echo WebTranslate('最新应用');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/App/app#downloadApp"><?php echo WebTranslate('应用下载');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	
                            <table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="4" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:85px;"></div></td>
                            
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('个人');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userApp#userApp"><?php echo WebTranslate('应用库');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/userMsg#user_msg"><?php echo WebTranslate('未读消息');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/User/user#userDetail"><?php echo WebTranslate('个人信息');?></a></td></tr>
                            </table>
                            
                        </td>
                        
                        <td width="45"></td>
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            	<tr>
                                <td rowspan="5" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:110px;"></div></td>
                            	<!-- 网站地图的链接 -->
                                <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('帮助');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('关于');?>REWO</a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=11&type_id=3#help_common"><?php echo WebTranslate('驱动下载');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=15&type_id=2#help_common"><?php echo WebTranslate('使用步骤');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Help/help?id=1&type_id=1#help_common"><?php echo WebTranslate('常见问题');?></a></td></tr>
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        
                        <td align="center" valign="top">
                        	<table border="0" cellpadding="1" cellspacing="0">
                            <tr>
                            <td rowspan="3" align="center" valign="middle">
                            <div class="footer_left_pic" style="height:63px;"></div></td>
                            <!-- 网站地图的链接 -->
                            <td align="left" valign="middle" class="footer_nav_th"><?php echo WebTranslate('关于我们');?></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/contact"><?php echo WebTranslate('联系方式');?></a></td></tr>
                                <tr><td align="left" valign="middle" class="footer_nav_tb">
                                		<a href="__ROOT__/index.php/Contact/company"><?php echo WebTranslate('公司简介');?></a></td></tr>
                                
                            </table>
                        </td>
                        <td width="45"></td>
                        
                        <td width="183"></td>
                        
                    </tr>
                </table>
            </td></tr>
            
            <tr><td height="20"></td></tr>
            
            </table>
            </td></tr>
            <tr><td class="footer_bg"></td></tr>
            <tr><td align="center" valign="top" class="footer_style">
            <table width="1000" cellpadding="0" cellspacing="0" border="0">
            
            <tr><td height="40" align="right" valign="top">
            
            <table border="0" cellpadding="0" cellspacing="0">
            <tr><td height="1" rowspan="5"></td></tr>
            <tr><td width="55" align="center" valign="middle" class="footer_share"><?php echo WebTranslate('分享到');?> </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareWeibo('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_weibo.jpg" style="cursor:pointer;" alt="新浪微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
             <a href="javascript:shareQQ('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_tengxun.jpg" style="cursor:pointer;" alt="腾讯微博"/>
            </a>
            </td>
            <td width="35" align="center" valign="middle">
            <a href="javascript:shareRenren('rewo','rewo萌兔仔');"/>
            <img src="__ROOT__/Image/coin_renren.jpg" style="cursor:pointer;" alt="人人网"/></td>
            </a>
            <td width="40"></td>
            </tr>
            </table>
            
            </td></tr>
            </table>
            
            
            <div id="mask" style="display:none; height:100%">
           
             <div id="maskFaceDiv">
            	<div class="open_frame_top"></div>
                <div class="open_frame_middle">
                <table border="0" width="82%" height="100%" style="background-color:#ffffff;" cellpadding="0" cellspacing="0">
                <tr><td height="15" align="right" valign="top" style="float:right;">
                <label style="position:absolute; margin-top:-43px; margin-left:-3px;cursor:pointer;" onclick="closeMask()">
                <img src="__ROOT__/Image/coin_close.png"/>
                </label>
                </td></tr>
                <tr><td id="open_frame_title" height="30" align="left" valign="middle"
                 style="color:#929292; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_content" height="115" align="left" valign="top"
                 style="color:#030303; font-size:15px; font-family:'微软雅黑';">
                </td></tr>
                <tr><td id="open_frame_bottom" align="right" valign="bottom">
               
                </td></tr>
                <tr><td height="14"></td></tr>
                </table>
                </div>
                <div class="open_frame_bottom"></div>
            </div>
          
            </div>
           <div style="display:none;">
          <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fa0459d40afa2d5b581c169fc424d4509' type='text/javascript'%3E%3C/script%3E"));
</script>
         </div>
         
         <script> 
		<?php  $lang=""; if(isset($_SESSION["language"])) { if($_SESSION["language"]!="zh_CN") $lang=$_SESSION["language"]; } echo "AddDivTranslate('".$lang."');"; ?>
        </script>

           
            

 
 		</td></tr></table>
 
    </center>
    </body>
</html>