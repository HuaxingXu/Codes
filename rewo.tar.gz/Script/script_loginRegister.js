/* 登陆注册js */
function open_frame_wrong_pwd(root){
	bottom_str="<img src=\""+root+"/Image/user_forgetPwd.jpg\"/>&nbsp;&nbsp;&nbsp;&nbsp;";
	bottom_str+="<img src=\""+root+"/Image/coin_reInput.jpg\"/>";
	open_frame(JsTranslate("错误提示"),JsTranslate("密码输入错误。"),bottom_str);
}

function open_frame_forget_pwd(root){
	content_str=JsTranslate("请输入注册时填的邮箱")+"&nbsp;";
	content_str+="<input type='text' id='find_email' value='' style='border-width:1px;border-style:solid;border-color:#a5a5a5;width:202px;height:22px;";
	content_str+="font-size:16px;'/>";
	content_str+="<div id=\"find_email_div\" style=\"position:absolute; display:inline; z-index:10;\"></div>";
	
bottom_str="<table class='confirm' onclick='dealFindPwd(\""+root+"\")' style='cursor:pointer;' border='0' cellspacing='0' cellpadding='0'><tr><td align='center' valign='middle'>"+JsTranslate("找回密码")+"</td></tr></table>";

	open_frame(JsTranslate("找回密码"),content_str,bottom_str);
}


function open_frame_RegSuccess(root){
	bottom_str="<a href='"+root+"/index.php/User/userConfig'>";
	bottom_str+="<table class='confirm' style='cursor:pointer;' border='0' cellspacing='0' cellpadding='0'><tr><td align='center' valign='middle'>"+JsTranslate("确定")+"</td></tr></table></a>";
	open_frame(JsTranslate("提示信息"),JsTranslate("注册成功"),bottom_str);
}

function open_frame_ReSetPwdSuccess(root){
	bottom_str="<a href='"+root+"/index.php/User/user'>";
	bottom_str+="<table class='confirm' style='cursor:pointer;' border='0' cellspacing='0' cellpadding='0'><tr><td align='center' valign='middle'>"+JsTranslate("确定")+"</td></tr></table></a>";
	open_frame(JsTranslate("提示信息"),JsTranslate("重置密码成功"),bottom_str);
}

function open_frame_LoginSuccess(root){
	bottom_str="<a href='"+root+"/index.php/User/user'>";
	bottom_str+="<img src=\""+root+"/Image/confirm.jpg\" style='cursor:pointer;'/></a>";
	open_frame(JsTranslate("提示信息"),JsTranslate("登录成功"),bottom_str);
}

function open_frame_unstall_app(root){
	bottom_str="<img src=\""+root+"/Image/coin_cancel2.jpg\"/>&nbsp;&nbsp;&nbsp;&nbsp;";
	bottom_str+="<img src=\""+root+"/Image/coin_comfire2.jpg\"/>";
	open_frame(JsTranslate("卸载应用"),JsTranslate("确定要卸载应用吗？"),bottom_str);
}

function RegCheckEmail(root){
	now_reg_email=$("#reg_email").val();
    EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    /*if(now_reg_email=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>邮箱不能为空</font>";
		$("#reg_email_div").html(div_str);
	}
    else */
	if(!EmailReg.test(now_reg_email)&&now_reg_email!="")
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱或已注册")+"</font>";
		$("#reg_email_div").html(div_str);
	}
	else
	{
		
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/ExistEmail",
		dataType:"json",
		data:{"reg_email":now_reg_email},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
			div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱或已注册")+"</font>";
		$("#reg_email_div").html(div_str);
		if(now_reg_email=="")
			$("#reg_email_div").html("");
			}
			else
			{
				div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#reg_email_div").html(div_str);
		if(now_reg_email=="")
			$("#reg_email_div").html("");
			}
		}
		}
		});
		
		
	}
}

function RegCheckPwd(root){
	now_reg_pwd=$("#reg_pwd").val();
    PwdReg = /^\w{6,17}$/;
	/*
	if(now_reg_pwd=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>密码不能为空</font>";
		$("#reg_pwd_div").html(div_str);
	}
    else */
	if(!PwdReg.test(now_reg_pwd)&&now_reg_pwd!="")
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("为6-17位非特殊字符")+"</font>";
		$("#reg_pwd_div").html(div_str);
	}
	else
	{
		div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#reg_pwd_div").html(div_str);
		if(now_reg_pwd=="")
			$("#reg_pwd_div").html("");
	}
}

function RegCheckPwd2(root){
	now_reg_pwd=$("#reg_pwd").val();
	now_reg_pwd2=$("#reg_pwd2").val();
    /*
	if(now_reg_pwd2=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>确认密码不能为空</font>";
		$("#reg_pwd2_div").html(div_str);
	}
	else */
	if(now_reg_pwd!=now_reg_pwd2&&now_reg_pwd2!="")
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("密码不一致")+"</font>";
		$("#reg_pwd2_div").html(div_str);
	}
	else
	{
		div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#reg_pwd2_div").html(div_str);
		if(now_reg_pwd2=="")
			$("#reg_pwd2_div").html("");
	}
}

function clickReadClause(root){
	if($("#reg_isread_clause").val()==0)
	{
		$("#reg_clause_img").attr("src",root+"/Image/user_selected.jpg");
		$("#reg_isread_clause").val("1");
	}
	else
	{
		$("#reg_clause_img").attr("src",root+"/Image/user_not_selected.jpg");
		$("#reg_isread_clause").val("0");
	}
}


function dealRegister(root)
{
	now_reg_email=$("#reg_email").val();
	now_reg_pwd=$("#reg_pwd").val();
	now_reg_pwd2=$("#reg_pwd2").val();
	now_reg_isread_clause=$("#reg_isread_clause").val();
	EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	PwdReg = /^\w{6,17}$/;
    if(now_reg_email=="")
	{
		open_frame_wrongMsg(root,JsTranslate("邮件格式错误或此邮箱已经被注册，请重新输入有效邮箱。"));
		return
	}
    if(!EmailReg.test(now_reg_email))
    {
		open_frame_wrongMsg(root,JsTranslate("邮件格式错误或此邮箱已经被注册，请重新输入有效邮箱。"));
		return
	}
	if(now_reg_pwd=="")
	{
		open_frame_wrongMsg(root,JsTranslate("密码不能为空"));
		return
	}
    if(!PwdReg.test(now_reg_pwd))
    {
		open_frame_wrongMsg(root,JsTranslate("为6-17位非特殊字符"));
		return
	}
	if(now_reg_pwd2=="")
	{
		open_frame_wrongMsg(root,JsTranslate("确认密码不能为空"));
		return
	}
	if(now_reg_pwd!=now_reg_pwd2)
    {
		open_frame_wrongMsg(root,JsTranslate("密码不一致"));
		return
	}
	if(Number(now_reg_isread_clause)!=1)
    {
		open_frame_wrongMsg(root,JsTranslate("请阅读并同意服务条款"));
		return
	}
	
	$.ajax({
		type: "POST",
		url: "/index.php/User/Register",//https://www.irewo.com
		dataType:"json",
		data:{"reg_email":now_reg_email,
			  "reg_pwd":now_reg_pwd},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
				open_frame_RegSuccess(root);
			else
				open_frame_wrongMsg(root,JsTranslate(json.desc));
			return
		}
		}
	});
	
}


function checkLoginEmail(root){
	now_login_email=$("#login_email").val();
    EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    /*
	if(now_login_email=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>邮箱不能为空</font>";
		$("#login_email_div").html(div_str);
	}
    else */
	if(!EmailReg.test(now_login_email)&&now_login_email!="")
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱")+"</font>";
		$("#login_email_div").html(div_str);
	}
	else
	{
		
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/ExistEmail",
		dataType:"json",
		data:{"reg_email":now_login_email},
		success: function(json) {
		if(json!=null)
		{
			if(json.state!=1)
			{
			div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱")+"</font>";
		$("#login_email_div").html(div_str);
		if(now_login_email=="")
			$("#login_email_div").html("");
			}
			else
			{
				div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#login_email_div").html(div_str);
			}
		}
		}
		});
		
		
	}
}

function checkLoginPwd(root){
	now_login_pwd=$("#login_pwd").val();
    PwdReg = /^\w{6,17}$/;
	/*
	if(now_login_pwd=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>密码不能为空</font>";
		$("#login_pwd_div").html(div_str);
	}
    else */
	if(!PwdReg.test(now_login_pwd)&&now_login_pwd!="")
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("密码错误")+"</font>";
		$("#login_pwd_div").html(div_str);
	}
	else
	{
		
		now_login_email=$("#login_email").val();
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/LoginPwd",
		dataType:"json",
		data:{"login_pwd":now_login_pwd,
			  "login_email":now_login_email},
		success: function(json) {
			
		if(json!=null)
		{  
			if(json.state!=1)
			{
			div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("密码错误")+"</font>";
		$("#login_pwd_div").html(div_str);
		if(now_login_pwd=="")
			$("#login_pwd_div").html("");
			}
			else
			{
				div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#login_pwd_div").html(div_str);
			}
		}
		}
		});
		
		
	}
}


function clickLoginRemember(root){
	if($("#login_remember").val()==0)
	{
		$("#login_remember_img").attr("src",root+"/Image/user_selected.jpg");
		$("#login_remember").val("1");
	}
	else
	{
		$("#login_remember_img").attr("src",root+"/Image/user_not_selected.jpg");
		$("#login_remember").val("0");
	}
}

function dealLogin(root)
{
	now_login_email=$("#login_email").val();
	now_login_pwd=$("#login_pwd").val();
	now_login_remember=$("#login_remember").val();
	PwdReg = /^\w{6,17}$/;
	EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(now_login_email=="")
	{
		open_frame_wrongMsg(root,JsTranslate("邮箱或密码有误"));//邮箱不能为空
		return
	}
    if(!EmailReg.test(now_login_email))
    {
		open_frame_wrongMsg(root,JsTranslate("邮箱或密码有误"));//无效邮箱
		return
	}
	if(now_login_pwd=="")
	{
		open_frame_wrongMsg(root,JsTranslate("邮箱或密码有误"));//密码不能为空
		return
	}
    if(!PwdReg.test(now_login_pwd))
    {
		open_frame_wrongMsg(root,JsTranslate("邮箱或密码有误"));//密码输入错误
		return
	}
	
	$.ajax({
		type: "POST",
		url: "/index.php/User/Login",//https://www.irewo.com
		dataType:"json",
		data:{"login_pwd":now_login_pwd,
			  "login_email":now_login_email,
			  "login_remember":now_login_remember},
		success: function(json) {
		if(json!=null)
		{  
			if(json.state==1)//open_frame_LoginSuccess(root);
				document.location.href=root+"/index.php/User/userApp";
			else
				open_frame_wrongMsg(root,json.desc);
			return
		}
		
		}
		});
	
}


function dealFindPwd(root)
{
	now_find_email=$("#find_email").val();
	EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if(now_find_email=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px; color:red;'>"+JsTranslate("邮箱不能为空")+"</font>";
		$("#find_email_div").html(div_str);
	}
    else if(!EmailReg.test(now_find_email))
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px; color:red;'>"+JsTranslate("无效邮箱")+"</font>";
		$("#find_email_div").html(div_str);
	}
	else
	{
		
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/ExistEmail",
		dataType:"json",
		data:{"reg_email":now_find_email},
		success: function(json) {
		if(json!=null)
		{
			if(json.state!=1)
			{
			div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px; color:red;'>"+JsTranslate("无效邮箱")+"</font>";
		$("#find_email_div").html(div_str);
			}
			else
			{
				div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#find_email_div").html(div_str);
				dealFindMail(root,now_find_email);
			}
		}
		}
		});
		
		
	}
}


function dealFindMail(root,email)
{
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/ForgetPwd",
		dataType:"json",
		data:{"email":email},
		beforeSend: function(json){
			div_str="<img src='"+root+"/Image/wait_small.gif' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
			$("#find_email_div").html(div_str);
			},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
				open_frame_Msg(root,JsTranslate("重置密码邮件已经发送到你的注册邮箱当中"));
			else
				open_frame_wrongMsg(root,json.desc);
			return
		}
		}
		});
}


function dealResetPwd(root)
{
	now_re_email=$("#re_email").val();
	now_re_pwd=$("#re_pwd").val();
	now_re_pwd2=$("#re_pwd2").val();
	now_rand=$("#rand").val();
	EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	PwdReg = /^\w{6,17}$/;
	/*
    if(now_re_email=="")
	{
		open_frame_wrongMsg(root,"无效邮箱");
		return
	}
    if(!EmailReg.test(now_re_email))
    {
		open_frame_wrongMsg(root,"无效邮箱");
		return
	}*/
	if(now_re_pwd=="")
	{
		open_frame_wrongMsg(root,JsTranslate("新密码不能为空"));
		return
	}
    if(!PwdReg.test(now_re_pwd))
    {
		open_frame_wrongMsg(root,JsTranslate("为6-17位非特殊字符"));
		return
	}
	if(now_re_pwd2=="")
	{
		open_frame_wrongMsg(root,JsTranslate("确认密码不能为空"));
		return
	}
	if(now_re_pwd!=now_re_pwd2)
    {
		open_frame_wrongMsg(root,JsTranslate("密码不一致"));
		return
	}
	
	$.ajax({
		type: "POST",
		url: "/index.php/User/dealResetPwd",//https://www.irewo.com
		dataType:"json",
		data:{"re_email":now_re_email,
			  "re_pwd":now_re_pwd,
			  "rand":now_rand},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
				open_frame_ReSetPwdSuccess(root);
			else
				open_frame_wrongMsg(root,JsTranslate(json.desc));
			return
		}
		}
	});
	
}


function ReCheckEmail(root){
	now_re_email=$("#re_email").val();
    EmailReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if(now_re_email=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("邮箱不能为空")+"</font>";
		$("#re_email_div").html(div_str);
	}
    else if(!EmailReg.test(now_re_email))
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱或已注册")+"</font>";
		$("#re_email_div").html(div_str);
	}
	else
	{
		
		$.ajax({
		type: "POST",
		url: root+"/index.php/User/ExistEmail",
		dataType:"json",
		data:{"reg_email":now_re_email},
		success: function(json) {
		if(json!=null)
		{
			if(json.state!=1)
			{
			div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;'>"+JsTranslate("无效邮箱")+"</font>";
		$("#re_email_div").html(div_str);
			}
			else
			{
				div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#re_email_div").html(div_str);
			}
		}
		}
		});
		
		
	}
}

function ReCheckPwd(root){
	now_re_pwd=$("#re_pwd").val();
    PwdReg = /^\w{6,17}$/;
	if(now_re_pwd=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;color:red;'>"+JsTranslate("新密码不能为空")+"</font>";
		$("#re_pwd_div").html(div_str);
	}
    else if(!PwdReg.test(now_re_pwd))
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;color:red;'>"+JsTranslate("为6-17位非特殊字符")+"</font>";
		$("#re_pwd_div").html(div_str);
	}
	else
	{
		div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#re_pwd_div").html(div_str);
	}
}


function ReCheckPwd2(root){
	now_re_pwd=$("#re_pwd").val();
	now_re_pwd2=$("#re_pwd2").val();
    if(now_re_pwd2=="")
	{
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;color:red;'>"+JsTranslate("确认密码不能为空")+"</font>";
		$("#re_pwd2_div").html(div_str);
	}
	else if(now_re_pwd!=now_re_pwd2)
    {
		div_str="<img src='"+root+"/Image/coin_min_wrong.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
    	div_str+="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font class='user_login_left' style='font-size:12px;color:red;'>"+JsTranslate("密码不一致")+"</font>";
		$("#re_pwd2_div").html(div_str);
	}
	else
	{
		div_str="<img src='"+root+"/Image/coin_min_right.png' style='position:absolute; margin-top:2px; margin-left:2px;'/>";
		$("#re_pwd2_div").html(div_str);
	}
}
