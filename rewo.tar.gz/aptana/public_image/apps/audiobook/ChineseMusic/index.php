<?php
require_once RootDir . 'audiobook/responces.php';
debug_echo("ChineseMusic<br/>");
responce_controller('中文音乐', RootDir . 'audiobook/ChineseMusic/');

