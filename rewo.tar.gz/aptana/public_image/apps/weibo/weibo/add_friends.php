<?php
//添加新关注用户到数据库中指定的表
//一共有{"fashion","film","finance","food","fun","music","news","sport","tech","xingzuo","yule"}11种不同的类型；
//每种类型的表中有两个字段，用户id和微博名screen_name，填写以上两个字段并选择相应的类型就可以将一个新的关注加入到数据库中
include_once("db_connection.php");
$con = weiboDbConnet(); //连接数据库"weibo_broadcast"

$tableName = array("fashion","film","finance","food","fun","music","news","sport","tech","xingzuo","yule");
$id = $_REQUEST["id"];
$screen_name = $_REQUEST["screen_name"];
$type = $_REQUEST["type"];
//echo $type." ".$id." ".$screen_name."<br />";

$sql = "INSERT INTO `weibo_broadcast`.`guanzhu` (`id`, `screen_name`,`type`) VALUES ('$id', '$screen_name','$type');";
if (!mysql_query($sql, $con))
{
	die("Error".mysql_error());
}

echo "成功增加\"$tableName[$type]\"类型的关注用户\"$screen_name\"!!!";
mysql_close();
?>

<a href=add_friends.html><h2>继续添加</h2></a>
	

