<?php
//服务器从新浪取回新微博
session_start();
include_once( 'config.php' );
include_once( 'saetv2.ex.class.php' );

include_once("db_connection.php");
$con = weiboDbConnet(); //连接数据库"weibo_broadcast"

$sql1 = "SELECT MAX(`mid`) FROM `weibos`;";
$result1 = mysql_query($sql1,$con);

while ($row1=mysql_fetch_array($result1))
{
	$last_mid = $row1[0] ;
	//echo "hahah:".$last_mid."<br><br><br><br>";
}
if (!$last_mid)
{
	$last_mid = 0;
}
//echo "hahah:".$last_mid."<br><br><br><br>";
$c = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );
$ms  = $c->home_timeline(1, 100, $last_mid); // done

if (isset($ms['statuses']));
{
	$new_num = count($ms['statuses']);
	$sql_del = "DELETE FROM `weibos` LIMIT $new_num;"; //获得多少条新微博，就删掉多少条原有微博记录
	if(!mysql_query($sql_del, $con))
	{
		die("error:".mysql_error());
	}
	echo "删除数据库中".$new_num."条旧的微博记录<br><br>";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>获取最新微博</title>
</head>

<body>
<?php if( is_array( $ms['statuses'] ) ): ?>
<?php foreach( $ms['statuses'] as $item ): ?>
<div style="padding:10px;margin:5px;border:1px solid #ccc">
	<?php echo $item['mid'].": ".$item['text'];
		$mid = $item['mid'];
		$text = $item['text'];
		$uid = $item['user']['id'];
		$screen_name = $item['user']['screen_name'];
		$reposts_count = $item['reposts_count'];
		$comments_count = $item['comments_count'];
		
		$sql2 = "SELECT * FROM `guanzhu` WHERE `id` = '$uid'";
		if (!($result2=mysql_query($sql2, $con)))
		{
			die ("error2: ".mysql_error());
		}
		$row2 = mysql_fetch_array($result2);
		$type = $row2['type'];
		
		$sql3 = "INSERT INTO `weibo_broadcast`.`weibos` 
		(`mid`,`uid`,`screen_name`,`text`,`reposts_count`,`comments_count`,`type`) 
		VALUES 
		('$mid','$uid','$screen_name','$text','$reposts_count','$comments_count','$type');";
		if (!mysql_query($sql3, $con))
		{
			die ("error: ".mysql_error());
		}
		else
			echo "  成功添加到数据库!<br>";
		
	?>
</div>
<?php endforeach; ?>
<?php 
endif; 
mysql_close()
?>

</body>
</html>
