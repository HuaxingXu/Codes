<?php
//应用的主程序

include_once("db_connection.php");
$con = weiboDbConnet(); //连接数据库"weibo_broadcast"

$sql1 = "SELECT * FROM `users` LIMIT 1";
$result1 = mysql_query($sql1, $con);
$row1 = mysql_fetch_array($result1);
$listen_types = $row1['listen_types']; //返回一个包含用户对微博类型选择的string，形式如"1,0,1,1,0,0..."其中第一个1代表选择了收听fashion类型，第一个0代表不选择收听film类型
$last_mid = $row1['last_weibo_mid'];
//echo $listen_types;
$types = explode('|', $listen_types); //解析字符串为数组

$sql2 = "SELECT * FROM `weibos` WHERE `weibos`.`mid` > '$last_mid' ORDER BY `mid` DESC LIMIT 10;"; //获取此用户没读过的最新的5条微博
$result2 = mysql_query($sql2, $con);
$counter = 0;
$arr = array();
while ($row2 = mysql_fetch_array($result2))
{
	$row2 = mysql_fetch_array($result2);
	$i_type = $row2['type'];
	//$i_type指的是第几种类型，比如说$i_type为3时，若$types[$i_type]为1就说明用户选择了第三种类型，为0则没选择。
	//如果此条微博是用户选择收听的类型，就输出给硬件终端
	if ($types[$i_type]=='1') 
	{
		
		$arr[$counter]['weibo'] =$row2['screen_name'].": ".$row2['text'];
		$counter++;
	}
}
//输出的json带有两个字段，一个是'weibos'，是一个微博的数组，另一个是'counter'，表明本次发送微博的条数，最多不超过10条。
$weibo = json_encode(array('weibos'=>$arr,'counter'=>$counter));
echo $weibo;

?>

