-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 18, 2012 at 02:49 PM
-- Server version: 5.5.24
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `audiobook`
--
CREATE DATABASE `audiobook` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `audiobook`;

-- --------------------------------------------------------

--
-- Table structure for table `user_broadcast_status`
--

CREATE TABLE IF NOT EXISTS `user_broadcast_status` (
  `uid` bigint(20) NOT NULL COMMENT '用户id，对应于think_rewo表中的rewo_user的id',
  `bookname` varchar(50) NOT NULL COMMENT '有声读物书名',
  `chapter` varchar(50) NOT NULL COMMENT '书的章节名',
  PRIMARY KEY (`uid`,`bookname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_broadcast_status`
--

INSERT INTO `user_broadcast_status` (`uid`, `bookname`, `chapter`) VALUES
(1, '中文音乐', '我的歌声里'),
(1, '英文音乐', 'Somebody That I Used To Know');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
