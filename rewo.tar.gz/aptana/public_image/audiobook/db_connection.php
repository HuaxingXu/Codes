<?php
require_once RootDir . 'config.php';
/**
 * 连接有声读物的数据库
 * @return con resource[数据库连接]
 */
function audiobook_db_connect() {
	$con = mysql_connect(AUDIOBOOK_DB_HOST, 
					AUDIOBOOK_DB_USERNAME, 
					AUDIOBOOK_DB_PASSWORD);
	if (! $con) {
		die('Could not connect: ' . mysql_error());
	}
	mysql_select_db(AUDIOBOOK_DB, $con);
	mysql_query('SET NAMES UTF8');
	return $con;
}