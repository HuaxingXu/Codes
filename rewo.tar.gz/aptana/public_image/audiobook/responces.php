<?php
require_once RootDir . 'audiobook/audiobook.php';

/**
 * 响应控制器
 * @param bookname string[应用名、书名]
 * @param curDir string[代码目录]
 */
function responce_controller($bookname, $curDir) {
	$content = file_get_contents($curDir . 'chapters');
	$book = json_decode($content, true);

	//获取上次的播放记录
	if (isset($_REQUEST['last_broadcast'])) {
		responce_last_broadcast($_SESSION['id'], $bookname, $book);
	}
	//保存播放记录
	else if (isset($_REQUEST['chapter'])) {
		responce_save_last_broadcast($_SESSION['id'], $bookname, $_REQUEST['chapter']);
	}
	//获取章节名单
	else {
		responce_get_chapters($book);
	}
}
//响应不同操作的函数
/**
 * 响应获取上次播放记录
 * @param id int[用户id]
 * @param bookname string[应用名、书名]
 * @param book json[从chapters文件读出来的信息，详情见chapters文件]
 */
function responce_last_broadcast($id, $bookname, $book) {
	$last_broadcast = get_last_broadcast($id, $bookname);
	$json = array();
	if ($last_broadcast != null) {
		debug_echo("上次的播放:<a href='" . RTSP_DIR . $book['audio_dir'] .
				"/" . $book['chapters'][$last_broadcast] . "'>$last_broadcast</a><br/>");
		$json['flag'] = 1;
		$json['name'] = $last_broadcast;
		$json['url'] = RTSP_DIR . $book['audio_dir'] . "/$last_broadcast";
	}
	else {
		debug_echo("没有播放记录<br/>");
		$json['flag'] = 0;
	}
	echo json_encode($json);
}
/**
 * 响应保存播放记录
 * @param id int[用户id]
 * @param bookname string[应用名、书名]
 * @param chapter string[章节名]
 */
function responce_save_last_broadcast($id, $bookname, $chapter) {
	$json = array();
	$json['result'] = update_last_broadcast($id, $bookname, $chapter);
	echo json_encode($json);
}
/**
 * 响应获取章节名单
 * @param book json[从chapters文件读出来的信息，详情见chapters文件]
 */
function responce_get_chapters($book) {
	$json = array();
	debug_echo("章节：<br/>");
	foreach ($book['chapters'] as $key => $value) {
		 $chapter = array();
		 $chapter['name'] = $key;
		 $chapter['url'] = RTSP_DIR . $book['audio_dir'] . "/$value";
		 $json[] = $chapter;
		debug_echo("<a href='" . RTSP_DIR . $book['audio_dir'] . "/$value' >$key</a><br/>");
	}
	echo json_encode($json);
}
/**
 * 测试时用于输出的函数
 */
function debug_echo($message) {
	if (AUDIOBOOK_DEGUB) {
		echo $message;
	}
}