<?php
header('Content-Type: text/html; charset=UTF-8');

/*数据库的配置*/
define("WEATHER_FORECAST_DB", "weather_forecast");
define("WEATHER_FORECAST_DB_HOST", "localhost");
define("WEATHER_FORECAST_DB_USERNAME", "root");
define("WEATHER_FORECAST_DB_PASSWORD", "");