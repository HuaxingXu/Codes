<?php
require_once RootDir . 'weather/config.php';
/**
 * 连接到天气预报城市码数据库
 * @return con resource[数据库连接]
 */
function weather_forecast_db_connect() {
	$con = mysql_connect(WEATHER_FORECAST_DB_HOST,
			WEATHER_FORECAST_DB_USERNAME,
			WEATHER_FORECAST_DB_PASSWORD);
	if (! $con) {
		die('Could not connect: ' . mysql_error());
	}
	mysql_select_db(WEATHER_FORECAST_DB, $con);
	mysql_query('SET NAMES UTF8');
	return $con;
}