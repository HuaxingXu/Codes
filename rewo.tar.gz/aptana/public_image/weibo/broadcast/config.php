<?php
header('Content-Type: text/html; charset=UTF-8');
/*应用配置*/
define( "WB_AKEY" , '1981348119' ); //应用注册号
define( "WB_SKEY" , '584e2e475bcd1f8c1645da125fa2d126' ); //应用注册号
define( "WB_CALLBACK_URL" , 'http://localhost/aptana/rewo2/appz/index.php/App/getContent?id=80&method=redirect' );//回调地址，要与微博应用上填写的信息一致

