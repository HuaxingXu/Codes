<?php
//服务器从新浪取回新微博
session_start();
include_once( 'config.php' );
include_once( 'saetv2.ex.class.php' );
require_once 'broadcast.php';

$last_mid = get_newest_weibo_id();

$c = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );
$ms  = $c->home_timeline(1, 100, $last_mid); // done

//读取敏感词汇
$content = file_get_contents(RootDir . 'weibo/broadcast/sensitive');
$sensitiveWords = explode("\n", $content);
//读取非文字类词汇
$content = file_get_contents(RootDir . 'weibo/broadcast/non_text');
$nonTextWords = explode("\n", $content);
$count = 0;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>获取最新微博</title>
</head>

<body>
<?php if( is_array( $ms['statuses'] ) ): ?>
<?php foreach( $ms['statuses'] as $item ): ?>
<div style="padding:10px;margin:5px;border:1px solid #ccc">
	<?php echo $item['mid'].": ".$item['text'];
		$mid = $item['mid'];
		$text = $item['text'];
		$uid = $item['user']['id'];
		$screen_name = $item['user']['screen_name'];
		$reposts_count = $item['reposts_count'];
		$comments_count = $item['comments_count'];
		
		$type = get_weibo_type($uid);
		if (weibo_filter($text, $nonTextWords, $sensitiveWords)) {
			if (! add_weibo($mid, $uid, $screen_name, $text, 
					$reposts_count, $comments_count, $type)) {
				die("error:" . mysql_error());
			}
			else {
				++ $count;
				echo "<b>成功添加到数据库!!!!!!</b><br>";
			}
		}
	?>
</div>
<?php endforeach; ?>
<?php 
endif; 
// if (! delete_old_weibos($count)) {
// 	die("error:" . mysql_error());
// }
// echo "删除数据库中" . $count . "条旧的微博记录<br><br>";
?>

</body>
</html>
