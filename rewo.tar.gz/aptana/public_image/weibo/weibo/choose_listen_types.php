<?php
//将用户的类型选择添加到数据库
include_once("db_connection.php");
$con = weiboDbConnet(); //连接数据库"weibo_broadcast"

$uid = $_REQUEST['uid'];

echo "uid:".$uid;

$chosen_types = $_REQUEST['types'];
$types_arr = array();

for ($i = 0; $i<11; $i++)
{
	$isSet = false;
	foreach ($chosen_types as $type)
	{
		if ($type==$i)
		{
			$types_arr[$i] = '1';
			$isSet = ture;
		}
	}
	if (!$isSet)
		$types_arr[$i] = '0';
}

$choice_string = implode('|', $types_arr);
echo "选择类型的字符串: ".$choice_string."<br>";

$sql = "UPDATE `users` SET `listen_types` = '$choice_string' WHERE `uid` = '$uid';";
if (!mysql_query($sql, $con))
{
	die("error:".mysql_error());
}

echo "成功选择类型！！！";

mysql_close();
?> 
