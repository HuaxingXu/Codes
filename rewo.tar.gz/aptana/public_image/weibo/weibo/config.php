<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '365559684' ); //应用注册号
define( "WB_SKEY" , '925d695c9ddb8135f295118f253d7675' ); //应用注册号
define( "WB_CALLBACK_URL" , 'http://localhost/aptana/weibo/redirect.php' ); //回调地址，要与微博应用上填写的信息一致
