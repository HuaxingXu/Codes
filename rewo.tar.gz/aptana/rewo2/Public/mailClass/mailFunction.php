<?php

require("class.phpmailer.php"); 
date_default_timezone_set("Asia/Shanghai");

function sendEmail($send_mail,$send_name,$title,$content) {
$mail = new PHPMailer(); 
$mail->IsSMTP(); 
$mail->Host = "smtp.163.com"; 
$mail->SMTPAuth = true; 
$mail->Username = "rewomail@163.com"; 
$mail->Password = "rewomail123"; 
$mail->Port=25;
$mail->From = "rewomail@163.com"; 
$mail->FromName = "ReWo";
$mail->AddAddress("$send_mail", "$send_name");

//$mail->AddReplyTo("", "");
//$mail->AddAttachment("/var/tmp/file.tar.gz"); 
//$mail->IsHTML(true); // set email format to HTML 

$mail->Subject = $title; 
$mail->Body = $content; 
//$mail->AltBody = "This is the body in plain text for non-HTML mail clients"; 
if(!$mail->Send())
{
//echo "fault<p>";
//echo "error:" . $mail->ErrorInfo;
return false;
exit;
}
return true;

}



?>
