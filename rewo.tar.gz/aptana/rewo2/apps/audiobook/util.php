<?php
require_once RootDir . 'audiobook/audiobook.php';

/**
 * 响应控制器
 * @param bookname string[应用名、书名]
 * @param curDir string[代码目录]
 */
function responce_controller($bookname, $curDir) {
	$content = file_get_contents($curDir . 'chapters');
	$book = json_decode($content, true);
	
	//获取上次的播放记录
	if (isset($_REQUEST['last_broadcast'])) {
		responce_last_broadcast($_SESSION['id'], $bookname, $book);
	}
	//保存播放记录
	else if (isset($_REQUEST['chapter'])) {
		responce_save_last_broadcast($curDir, $_SESSION['id'], $bookname, $_REQUEST['chapter']);
	}
	//获取章节名单
	else {
		responce_get_chapters($book);
	}
}
//响应不同操作的函数
/**
 * 响应获取上次播放记录
 * @param id int[用户id]
 * @param bookname string[应用名、书名]
 * @param book json[从chapters文件读出来的信息，详情见chapters文件]
 * @return json['status'] 1 有记录 0 无记录
 *         json['desc'] 描述
 *         json['name'] 章节名
 *         json['url']  章节的rtsp地址
 */
function responce_last_broadcast($id, $bookname, $book) {
	$last_broadcast = get_last_broadcast($id, $bookname);
	$json = array();
	if ($last_broadcast != null) {
		$chapter = $last_broadcast['chapter'];
		$chapter_name = $last_broadcast['chapter_name'];

		debug_echo("上次的播放:<a href='" . RTSP_DIR . $book['audio_dir'] .
				"/" . $book['chapters'][$chapter] . "$chapter'>$chapter_name</a>");
		$json['status'] = 1;
		$json['desc'] = "ok";
		$json['name'] = $chapter_name;
		$json['url'] = RTSP_DIR . $book['audio_dir'] . "/$chapter";
	}
	else {
		debug_echo("没有播放记录");
		$json['status'] = 0;
		$json['desc'] = "no record!";
	}
	echo json_encode($json);
}
/**
 * 响应保存播放记录
 * @param id int[用户id]
 * @param bookname string[应用名、书名]
 * @param chapter string[章节名]
 * @return json
 * 			{"status":2,"desc":"insert"}  第一次记录
 *			{"status":1,"desc":"update"}  
 *			{"status":0,"desc":"fail"}	保存失败
 */
function responce_save_last_broadcast($curDir, $id, $bookname, $chapter) {
	if (! isset($chapter) || $chapter == '') {
		echo json_encode(array('status' => 0, 'desc' => "chapter is not set"));
		return;
	}
	$content = file_get_contents($curDir . 'chapters');
	$book = json_decode($content, true);
	foreach ($book['chapters'] as $cn => $c) {
		if ($c == $chapter) {
			$chapter_name = $cn;
			break;
		}
	}
	echo json_encode(update_last_broadcast($id, $bookname, $chapter, $chapter_name));
}
/**
 * 响应获取章节名单
 * @param book json[从chapters文件读出来的信息，详情见chapters文件]
 * @return json[i]['name'] 章节名
 * 	       json[i]['voice_name'] 章节对应的音频文件名
 *         json[i]['url'] 章节的rtsp地址
 */
function responce_get_chapters($book) {
	$json = array();
	debug_echo("章节：");
	foreach ($book['chapters'] as $key => $value) {
		 $chapter = array();
		 $chapter['name'] = $key;
		 $chapter['voice_name'] = $value;
		 $chapter['url'] = RTSP_DIR . $book['audio_dir'] . "/$value";
		 $json[] = $chapter;
		 debug_echo("<a href='" . RTSP_DIR . $book['audio_dir'] . "/$value' >$key</a>");
	}
	echo json_encode($json);
}
