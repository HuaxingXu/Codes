<?php
require_once RootDir . 'family/childrenhome/PHPMailer/class.phpmailer.php';

/**
 * 发送邮件
 * @param string address 收件人信息
 * @param string $subject 邮件主题
 * @param string $body 邮件内容
 * @return json['status'] 	1 发送成功 0 发送失败
 * 		   json['desc']     描述
 */
function send_email($address, $subject, $body) {
	$mail = new PHPMailer();

	$mail->IsSMTP();                                      // set mailer to use SMTP
	$mail->Host = "irewo.com";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "rewo";  // SMTP username
	$mail->Password = "rewo"; // SMTP password
	$mail->From = "rewo@irewo.com";
	$mail->FromName = "rewo";

	$mail->AddAddress($address['email']);
	$mail->Subject = $subject;
	$mail->Body    = $body;

	$return_arr = array();
	$return_arr['status'] = 0;
	$return_arr['desc'] = "";
	if ($mail->Send()) {
		$return_arr['status'] = 1;
		$return_arr['desc'] = "success";
	}
	else {
		$return_arr['desc'] = $mail->ErrorInfo;
	}

	return json_encode($return_arr);
}
/**
 *
 * @param string $mobile
 * @param string $content
 */
function send_message($mobile, $content) {
	$user = "rewo";
	$pass = "21b95a0f90138767b0fd324e6be3457b";
	$url = "http://vip.52ao.com/hk/submit?Sp_name=$user&Sp_pwd=$pass&Mobile=$mobile&Msg_Content=$content";
// 	redirect($url);
}
