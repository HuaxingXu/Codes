<?php
require_once RootDir . 'util.php';
require_once RootDir . 'family/config.php';
require_once RootDir . 'family/childrenhome/childrenhome.php';

$user_setting = $user_setting;
$setting = generate_app_setting($setting);
$rewo_setting = generate_app_setting($rewo_setting);
debug_print_r($user_setting);
debug_print_r($setting);
debug_print_r($rewo_setting);

$address = array();
$address['email'] = $user_setting['email'];
$subject = $rewo_setting['subject'];//邮件标题
$tmp = str_replace("__time__", date('Y-m-d H:i:s',time()), $rewo_setting['body']);//邮件内容
$body = str_replace("__child__", $user_setting['name'], $tmp);

if (! isset($address['email'])
		|| ! isset($subject) || ! isset($body)) {
	echo json_encode(array(
			'status'=>2,
			'desc'=>'emails or subject or body is not set.'));
	exit;
}
debug_echo("发邮件：");
if(isset($_REQUEST["img_path"])) {
	$body=$body."<br/><img src='".$_REQUEST["img_path"]."'/>";
}
echo send_email($address, $subject, $body);

$tel = $user_setting['tel'];//家长电话
$tmp = str_replace("__time__", date('Y-m-d H:i:s',time()), $rewo_setting['content']);
$content = iconv("UTF-8", "GBK",
		str_replace("__child__", $user_setting['name'], $tmp));
debug_echo("发信息：$tel $content");
send_message($tel, $content);

