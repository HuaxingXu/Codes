<?php
header('Content-Type: text/html; charset=UTF-8');


define("APPS_DEBUG", false);