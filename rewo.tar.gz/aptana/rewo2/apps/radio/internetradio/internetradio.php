<?php
require_once RootDir . 'util.php';
require_once RootDir . 'radio/config.php';
/**
 * 从ini文件中读取所有rtsp地址
 * @return multitype:multitype:
 */
function get_all_rtsps() {
	$content = file_get_contents(RootDir . "radio/internetradio/rtsp.ini");
	$type_num = preg_match_all("/\[.*?\]/", $content);
	$lines = explode("\n", $content);
	$return_arr = array();
	for ($i = 0; $i < $type_num; ++ $i) {
		$return_arr[$i]['type'] = '';
		$return_arr[$i]['addrs'] = array();
	}
	$i = -1;
	foreach ($lines as $line) {
		if (preg_match("/\[.*?\]/", $line)) {
			++ $i;
			$return_arr[$i]['type'] = substr($line, 1, strlen($line) - 2);
		}
		else if (strstr($line, "=") !== false) {
			$temp_arr = explode("=", $line);
			$return_arr[$i]['addrs'][$temp_arr[0]] = $temp_arr[1];
		}
	}
	return $return_arr;
}
/**
 * 获取网络电台类型
 * @return Ambigous <>
 */
function get_rtsp_types() {
	$content = file_get_contents(RootDir . "radio/internetradio/rtsp.ini");
	$return_arr = array();
	preg_match_all("/\[.*?\]/", $content, $return_arr);
	for ($i = 0; $i < count($return_arr[0]); ++ $i) {
		$return_arr[0][$i] = substr($return_arr[0][$i], 1, strlen($return_arr[0][$i]) - 2);
	}
	return $return_arr[0];
}
/**
 * 获取某个类型的所有rtsp链接
 * @param string $type rtsp类型
 * @return array
 */
function get_rtsps($type) {
	$rtsps = get_all_rtsps();
	foreach ($rtsps as $rtsp) {
		if ($rtsp['type'] == $type) {
			return $rtsp['addrs'];
		}
	}
	return array();
}