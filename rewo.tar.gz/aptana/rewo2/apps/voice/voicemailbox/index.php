<?php
require_once RootDir . 'util.php';
require_once RootDir . 'voice/voicemailbox/voicemailbox.php';
require_once RootDir . 'think_rewo.php';

$user_setting = $user_setting;
$setting = generate_app_setting($setting);
$rewo_setting = generate_app_setting($rewo_setting);

$voice_file_dir = RootDir . $rewo_setting['voice_file_dir'];
$voice_url = $rewo_setting['voice_url'];

$return_arr = array();
$return_arr['status'] = 0;
$return_arr['desc'] = "default message";
$to_id = $_REQUEST['to_id'];
$from_id = $_SESSION['id'];
$user_id = $_SESSION['id'];

if ($_FILES) {//上传文件处理
	$name_block = explode(".", $_FILES['voice']['name']);
	$name_block[1] = $name_block[1] ? "." . $name_block[1] : "";
	$file_name = md5(date('Y-m-d H:i:s',time())) . $name_block[1];
	$uploadfile = $voice_file_dir . $file_name;
	if (! $from_id || ! $to_id) {//登录检测
		$return_arr['status'] = 1;
		$return_arr['desc'] = "from_id or to_id is not set";
	}
	else if (is_uploaded_file($_FILES['voice']['tmp_name'])) {
		
		if ($user_setting['receive_stranger_voice'] == "01" && ! is_friend($from_id, $to_id)) {//不接收陌生人的语音
			$return_arr['status'] = 9;
			$return_arr['desc'] = "user does not receive stranger's voice";
		}
		else if (move_uploaded_file($_FILES['voice']['tmp_name'], $uploadfile) && save_voice($to_id, $from_id, $file_name)) {
			//保存文件并且插入到在数据库插入记录
			$return_arr['status'] = 2;
			$return_arr['desc'] = "voice is saved !";
		}
		else {
			$return_arr['status'] = 3;
			$return_arr['desc'] = "voice save failed!";
		}
	}
	else {
		$return_arr['status'] = 4;
		$return_arr['desc'] = "upload error";
	}
}
else if ($_REQUEST['voice']) {
	$voice_file = $voice_file_dir . $_REQUEST['voice'];
	if (file_exists($voice_file)) {//下载语音文件
		$return_arr['status'] = 5;
		$return_arr['desc'] = "download voice";
		redirect("http://" . $_SERVER['HTTP_HOST'] . $voice_url . $_REQUEST['voice']);//直接下载
	}
	else {//语音文件不存在
		$return_arr['status'] = 6;
		$return_arr['desc'] = "voice file does not exist!";
	}
} 
else {//获取未读语音文件列表
	if (! $user_id) {
		$return_arr['status'] = 7;
		$return_arr['desc'] = "login first";
	}
	else {
		$return_arr['status'] = 8;
		$return_arr['desc'] = "voices list!";
		$return_arr['voices'] = get_voices_unread($user_id);
		for ($i = 0; $i < count($return_arr['voices']); ++ $i) {
			unset($return_arr['voices'][$i][0]);
			unset($return_arr['voices'][$i][1]);
			$return_arr['voices'][$i]['url'] = "http://" . $_SERVER['HTTP_HOST'] . $voice_url . $return_arr['voices'][$i]['voice_name'];
		}
	}
}
debug_print_r($return_arr);
echo json_encode($return_arr);

