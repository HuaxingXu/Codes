<?php
require_once RootDir . 'util.php';
require_once RootDir . 'weather/forecast/forecast.php';

$setting = generate_app_setting($setting);
$rewo_setting = generate_app_setting($rewo_setting);

$city = $user_setting['city'];
if (! isset($city)) {
	echo json_encode(array('status'=>-2, 'desc'=>"you have not login or your app setting is not right"));
	exit;
}
$code = get_city_code($city);
if (! $code) {
    echo json_encode(array('status'=>-1, 'desc'=>"no such city"));
    exit;
}
switch ($_REQUEST['data']) {//三种不同的数据形式
	case 2:
		$url = "http://www.weather.com.cn/data/sk/" . $code . ".html";
		break;
	case 3:
		$url = "http://m.weather.com.cn/data/" . $code . ".html";
		break;
	default:
		$url = "http://www.weather.com.cn/data/cityinfo/" . $code . ".html";
}
$forecast = json_decode(file_get_contents($url), true);
// $forecast['weatherinfo']['temp1'] = convert_to_chinese($forecast['weatherinfo']['temp1']);
// $forecast['weatherinfo']['temp2'] = convert_to_chinese($forecast['weatherinfo']['temp2']);
deal_temp($forecast['weatherinfo']['temp1'], $forecast['weatherinfo']['temp2']);
$forecast['status'] = 1;
debug_print_r($forecast);
echo json_encode($forecast);

