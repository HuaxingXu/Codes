<?php
session_start();

include_once RootDir . 'weibo/saetv2.ex.class.php';
if (! isset($_SESSION['id'])) {
	echo json_encode(array('status'=>1,
			'desc'=>'login first'));
	exit;
}
//需要手动授权
$o = new SaeTOAuthV2( WB_AKEY , WB_SKEY );
$code_url = $o->getAuthorizeURL( WB_CALLBACK_URL );
echo "<script language='javascript' type='text/javascript'>";
echo "window.location.href='$code_url'";
echo "</script>";
