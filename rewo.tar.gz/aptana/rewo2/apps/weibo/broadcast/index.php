<?php
require_once RootDir . 'weibo/config.php';
require_once RootDir . 'util.php';
require_once RootDir . 'weibo/broadcast/config.php';
require_once RootDir . 'weibo/broadcast/broadcast.php';

$setting = generate_app_setting($setting);
$rewo_setting = generate_app_setting($rewo_setting);

if (isset ($_REQUEST['mid'])) {//保存广播的微博mid
	$result = save_user_last_broadcast($_SESSION['id'], $_REQUEST['mid']);
	echo json_encode(array('status' => 1,
			'desc' => $result));
	exit;
}
else if (! isset($_REQUEST['method'])) {
	include RootDir . 'weibo/broadcast/weibo_broadcast.php';
	exit;
}
//管理员的操作
if ($_SESSION['id'] != $rewo_setting['admin_id']) {
	echo json_encode(array('status' => 2,
				'desc' => 'admin only'));
	exit;
}
if ($_REQUEST['method'] == 'auth') {
	include RootDir . 'weibo/auth.php';
}
else if ($_REQUEST['method'] == 'redirect') {
	include RootDir . 'weibo/redirect.php';
}
else if ($_REQUEST['method'] == 'get_new_weibos') {
	include RootDir . 'weibo/broadcast_admin/get_new_weibos.php';
}
else if ($_REQUEST['method'] == 'add_friends') {
	isset($_REQUEST['update']) ? include RootDir . 'weibo/broadcast_admin/add_friends.php' :
								include RootDir . 'weibo/broadcast_admin/add_friends.html';
}
else if ($_REQUEST['method'] == 'choose_listen_types') {
	isset($_REQUEST['update']) ? include RootDir . 'weibo/broadcast_admin/choose_listen_types.php' : 
								 include RootDir . 'weibo/broadcast_admin/choose_listen_types.html';
}
else if ($_REQUEST['method'] == 'del' && isset($_REQUEST['count'])) {
	echo json_encode(array('status' => 1,
			'desc' => delete_old_weibos($_REQUEST['count'])));
}
else {
	echo json_encode(array('status' => 0,
							'desc' => "404 NOT FOUND!!"));
}
