<?php
//添加新关注用户到数据库中指定的表
//一共有{"fashion","film","finance","food","fun","music","news","sport","tech","xingzuo","yule"}11种不同的类型；
//每种类型的表中有两个字段，用户id和微博名screen_name，填写以上两个字段并选择相应的类型就可以将一个新的关注加入到数据库中
require_once RootDir . 'weibo/broadcast/broadcast.php';

$tableName = array("fashion","film","finance","food","fun","music","news","sport","tech","xingzuo","yule");
$id = $_REQUEST["id"];
$screen_name = $_REQUEST["screen_name"];
$type = $_REQUEST["type"];

if (! add_guanzhu($id, $screen_name, $type)) {
	die("Error".mysql_error());
}

echo "成功增加\"$tableName[$type]\"类型的关注用户\"$screen_name\"!!!";
?>

<a href="http://localhost/aptana/rewo2/appz/index.php/App/getContent?id=74&method=add_friends"><h2>继续添加</h2></a>
	

