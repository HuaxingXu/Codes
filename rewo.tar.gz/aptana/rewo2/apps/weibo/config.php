<?php
header('Content-Type: text/html; charset=UTF-8');

/*微博数据库的配置*/
define("WEIBO_DB", "weibo");
define("WEIBO_DB_HOST", "localhost");
define("WEIBO_DB_USERNAME", "root");
define("WEIBO_DB_PASSWORD", "");

define("APPS_DEBUG", true);
define("SQL_DEBUG", false);