<?php
require_once RootDir . 'util.php';
require_once RootDir . 'weibo/config.php';
/**
 * 连接微广播数据库
 * @return con resource[数据库连接]
 */
function weibo_db_connect() {
	return db_connect(WEIBO_DB_HOST, 
			WEIBO_DB_USERNAME, 
			WEIBO_DB_PASSWORD, 
			WEIBO_DB);
}
