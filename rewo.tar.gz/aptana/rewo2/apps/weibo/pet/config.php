<?php
header('Content-Type: text/html; charset=UTF-8');
/*应用配置*/
define( "WB_AKEY" , '2561713986' ); //应用注册号
define( "WB_SKEY" , '2ed3d08f38c4c6c625355f2f75b4f218' ); //应用注册号
define( "WB_CALLBACK_URL" , 'http://www.yzf.com/aptana/rewo2/appz/index.php/App/getContent?id=-10&method=redirect' );//回调地址，要与微博应用上填写的信息一致

define( "APP_URL", "http://www.yzf.com/aptana/rewo2/appz/index.php/App/getContent?id=-10" );
