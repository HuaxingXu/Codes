<?php
header('Content-Type: text/html; charset=UTF-8');
/*应用配置*/
define( "WB_AKEY" , '948301436' ); //应用注册号
define( "WB_SKEY" , '745216c943d0e98cf2a859311488dc1c' ); //应用注册号
define( "WB_CALLBACK_URL" , 'http://localhost/aptana/rewo2/appz/index.php/App/getContent?id=75&method=redirect' );//回调地址，要与微博应用上填写的信息一致

define( "APP_URL", "http://localhost/aptana/rewo2/appz/index.php/App/getContent?id=75&method=remind" );