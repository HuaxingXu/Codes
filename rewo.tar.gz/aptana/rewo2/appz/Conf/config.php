<?php
    if (!defined('THINK_PATH')) exit();
    $config = require('../config.php');
    $array = array(
    	'APP_DEBUG' => TRUE,
		'SHOW_PAGE_TRACE' => TRUE,

		'TMPL_CACHE_ON' => false,
		'ACTION_CACHE_ON'  => false,
		'HTML_CACHE_ON'   => false,
		
		'DB_FIELDS_CACHE' => false,
    );
	define('ConfigFile', 'conf');
	//define('RootDir', '/home/zero/workspace/aptana/rewo2/apps');
	//define('RootDir', 'E:/KingsoftCloud/workspace/Aptana/rewo2/apps');
	define('RootDir', '../apps/');
    return array_merge($config, $array);
?>