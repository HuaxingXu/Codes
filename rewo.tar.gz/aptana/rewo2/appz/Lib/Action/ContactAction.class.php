<?php

class ContactAction extends Action {
	
	public function contact() {
	$user="";
	if(isset($_SESSION["user"]))
	{
	    if(strlen(strstr($_SESSION["user"],'@'))>0)
			$user=$_SESSION["user"];
		else
		{
			$nowUser = M('user');
			$con=array();
			$con['username']=$_SESSION["user"];
		    $nowUserList=$nowUser->where($con)->find();
			if($nowUserList)
				$user=$nowUserList["email"];
		}
	}
	$this -> assign('txt_email_value', $user);
	
		$this -> display("Contact:contact");
	}
	//留言
	public function LeaveMessage() {
		$return_arr = array();
		$return_arr["state"] = 0;
		
		if (isset($_POST['content']) && isset($_POST['email'])) {	
			$data['contact_email'] = $this -> _post('email');
			$data['contact_tel'] = $this -> _post('tel');
			
			//验证
			$preg_email = "/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/";
			$preg_tel = "/^[0-9|\-]*$/";

			
			if (($data['contact_email'] == "" && $data['contact_tel'] == "") || 
					($data['contact_email'] != "" && ! preg_match($preg_email, $data['contact_email'])) ||
					($data['contact_tel'] != "" && ! preg_match($preg_tel, $data['contact_tel']))) {
				$return_arr['state'] = 1;
			}
			else {
				$User = M('user');
				if (!isset($_SESSION["user"]))
					$data['user_id'] = 0;
				else
					$data['user_id'] = $User -> where("`email`='" . $_SESSION["user"] . "' or username='".$_SESSION["user"]."'") -> getField('id');
				$data['time'] = date("Y-m-d H:i:s");
				$data['content'] = $this -> _post('content');
				//插入到数据库
				
					$Message = M('message');
					$Message -> add($data);
					
					$return_arr['state'] =2;
				
				
			}
		}
		echo json_encode($return_arr);
	}
	
	public function company() {
		$this -> display("Contact:company");
	}
	
}