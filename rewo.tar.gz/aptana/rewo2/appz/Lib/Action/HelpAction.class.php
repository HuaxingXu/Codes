<?php

class HelpAction extends Action {
	
	public function index() {
		$this -> redirect("help");
	}

	public function help() {
		$Help = M('help');
		/*获取所有问题*/
		$types = $Help -> distinct(true) -> field("type_id, type_name")->order("type_id,id asc") -> select();
		for ($i = 0; $i < count($types); ++ $i) {
			$type_id = $types[$i]['type_id'];
			$type_name = $types[$i]['type_name'];
			$con=array();
			$con['type_id']=$type_id;
			$con['type_name']=$type_name;
			$questions = $Help -> where($con)
							-> field("id, question") -> select();
			$types[$i]['questions'] = $questions;
		}
		//默认显示第一个问题的答案
		$id=1;
		if(isset($_REQUEST["id"]))
			$id=$_REQUEST["id"];
		$answer = $Help -> field("question, answer") -> find($id);
		$this -> assign("answer", $answer);
		$this -> assign("types", $types);
		$this -> display("Help:help");
	}
	//获取答案
	public function GetAnswer() {
		$id = intval($this -> _post("id"));
		$Help = M('help');
		$answer = $Help -> where("id='$id'") -> field("question as title, answer as content") -> find();
		echo json_encode($answer);
	}
}