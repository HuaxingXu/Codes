<?php
// 废弃，只是用于测试代码用
//require_once 'simple_html_dom.php';
class TestAction extends Action {
	
	public function test() {
		$a = new TestAction();
		$a->index();
	}
	
	public function index() {
		header('Content-Type: text/html; charset=UTF-8');
		$url = U('User/auth') . '?username=袁&password=123456';
		echo "<a href={$url}>登录</a><br/>";

		$url = U('App/scanAppInfo');
		echo "<a href={$url}>扫描本地文件系统的app信息</a><br/>";

		$url = U('App/action') . '?id=77&act=image';
		echo "<a href={$url}>图片测试</a><br/>";
		
		$url = U('UserGrow/childrenHome');
		echo "<form action={$url} method='post' enctype='multipart/form-data'>
				<input type='file' name='file'/><br/>
				<input type='submit' value='submit'/>
				</form>";
	}

	//测试使用的函数
	public function testExecPopen() {
		echo time();
		echo __ROOT__ . "       ";
		$Root = "/home/zero/workspace/aptana/";
		echo "<br/>exec   执行程序{$Root}test/test的结果：<br/>";
		$ret = array();
		exec($Root . "test/test testParam1 testParam2", $ret, $status);
		print_r($ret);

		echo "<br/>popen   w执行程序{$Root}test/test2  w的结果：<br/>";
		$handler = popen($Root . 'test/test2', 'w');
		if ($handler == FALSE) {
			echo 'error';
		}
		//print_r(fread($handler, 2096));
		fwrite($handler, "1 2\n");
		pclose($handler);

		echo "<br/>popen   r执行程序{$Root}test/test2的结果：<br/>";
		$handler = popen($Root . 'test/test2', 'r');
		print_r(fread($handler, 2096));
		pclose($handler);

		echo "<br/>proc_open执行程序{$Root}test/test2  r的结果：<br/>";
		$descriptorspec = array(0 => array("pipe", "r"), // stdin is a pipe that the child will read from
		1 => array("pipe", "w"), // stdout is a pipe that the child will write to
		2 => array("file", "/tmp/error-output.txt", "a") // stderr is a file to write to
		);
		$handler = proc_open($Root . "test/test2", $descriptorspec, $pipes);

		fwrite($pipes[0], "1 2\n");
		fclose($pipes[0]);

		echo stream_get_contents($pipes[1]);
		fclose($pipes[1]);

		$return_value = proc_close($handler);

		echo "command returned $return_value\n";
	}


	//--------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------

	// 通过谷歌的接口，进行语音识别的测试
	public function recognize() {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://www.google.com/speech-api/v1/recognize?xjerr=1&client=chromium&lang=zh-CN&maxresults=1");
		curl_setopt($ch, CURLOPT_VERBOSE, 0);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, file_get_contents('/srv/http/aptana/TTSDemo.flac'));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: audio/x-flac; rate=16000"));
		$data = curl_exec($ch);
		curl_close($ch);
		if ($data = json_decode($data, true)) {
			echo "<ul>";
			foreach ($data['hypotheses'] as $i)
				echo "<li>" . $i['utterance'] . "</li>";
			echo "</ul>";
		} else {
			echo "<i>识别出错</i>";
		}
		echo "<br/>";
		$UserApp = new UserAppModel();
		$appList = $UserApp -> where(array('user_id' => $_SESSION['id'])) -> select();
		foreach ($data['hypotheses'] as $item) {
			foreach ($appList as $app) {
				echo $item['utterance'] . $app['app_id'] . "<br/>";
				if ($item['utterance'] == $app['word']) {
					echo $app['app_id'] . "<br/>";
				}
			}
		}
	}

	// 通过php遥控机器人
	public function remote() {
		if (!isset($_SESSION['id'])) {
			$this -> ajaxReturn(0, 'no user_id', 400);
		}
		if (!isset($_REQUEST['id'])) {
			$this -> ajaxReturn(0, 'no app_id', 400);
		}
		$user_id = $_SESSION['id'];
		$app_id = $_REQUEST['id'];

		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		if ($socket < 0) {
			echo "create fail";
			//return;
		}
		$result = socket_connect($socket, 'localhost', 1234);
		if ($result < 0) {
			echo "connect fail";
			//return;
		}
		socket_write($socket, "remote\n{$user_id}\n{$app_id}\n");
		$readData = socket_read($socket, 2048);
		socket_close($socket);
		if (intval($readData) == 200) {
			$this -> ajaxReturn(0, 'success', 200);
		} else {
			$this -> ajaxReturn(0, 'fail', 404);
		}
	}

	// 判断是否机器人是否登录了
	public function isLogin() {
		if (!isset($_SESSION['id'])) {
			$this -> ajaxReturn(0, 'no user_id', 400);
		}
		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		$UserProduct = new UserProductModel();
		$UserProduct -> where($condition) -> find();
		if ($UserProduct > 0) {
			$this -> ajaxReturn(0, 'is login', 200);
		} else {
			$this -> ajaxReturn(0, 'not login', 404);
		}

	}

}
?>
