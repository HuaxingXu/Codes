<?php
class UserAppAction extends Action {
	//显示用户已经添加了的App列表
	public function index() {
		if (isset($_REQUEST['offset'])) {
			$offset = intval($_REQUEST['offset']);
		} else {
			$offset = 0;
		}
		$App = new UserAppModel();
		// 按照id排序显示前6条记录
		$userAppId = $this -> queryUserApps();
		$App = M("App");
		$condition = array();
		$userAppList = array();
		$i = 0;
		foreach ($userAppId as $key => $value) {
			$condition['id'] = $value['app_id'];
			$userAppList[$i] = $App -> where($condition) -> find();
			$userAppList[$i]['displayUrl'] = U('App/index') . '?id=' . $value['app_id'];
			$userAppList[$i]['image'] = U('App/getImage') . '?id=' . $value['app_id'];
			$i++;
		}

		$this -> assign('userAppList', $userAppList);
		$User = A('User');
		$isLogin = $User -> isLogin();
		$this -> assign('isLogin', $isLogin);
		$this -> display("User:userApp");
	}

	//查询用户是否已经添加了该App
	public function queryUserAppExist() {
		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		$condition['app_id'] = $_REQUEST['id'];

		$UserApp = new UserAppModel();
		if ($UserApp -> where($condition) -> count() == 1) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	//查询用户已经添加了的apps
	public function queryUserApps() {
		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		// flag 要大于0，才会返回
		//$condition['flag'] = array('gt', 0);  and flag>0

		$UserApp = new UserAppModel();
		$result = $UserApp->table("rewo_user_app,rewo_app") -> 
		where("rewo_user_app.app_id=rewo_app.id and rewo_user_app.user_id=".$_SESSION['id']."")->
		field("rewo_user_app.user_id,rewo_user_app.app_id,rewo_app.name as word,rewo_app.info,rewo_app.price,rewo_app.category,rewo_user_app.speech_command,rewo_user_app.rfid_card,rewo_app.brief,rewo_app.recommen_level as favourite_level,rewo_user_app.set_file_num,rewo_user_app.set_file_name,rewo_app.allow_multi_set") -> select();
		if ($result !== FALSE && !empty($result)) {
			return $result;
		} else {
			return FALSE;
		}
	}

	public function getUserApps() {
		//返回用户已经添加了的所有App的列表

		$userApps = $this -> queryUserApps();
		if ($userApps === FALSE) {
			$this -> ajaxReturn(0, 'fail', 404);
		} else {
			foreach ($userApps as $key => $value) {
				//$userApps[$key]['setting'] = str_replace('\"', '"', $value['setting']);
				//$userApps[$key]['setting'] = $this -> buildSettingOut($value['app_id'], $value['setting']);
				//unset($userApps[$key]['setting']);

				//$App = new AppModel();
				//$appInfo = $App -> where(array('id' => $value['app_id'])) -> find();
				$userApps[$key]['page_param']=$this->PhoneAppPageParam($value['app_id']);
			}

			$this -> ajaxReturn($userApps, 'success', 200);
		}

	}

	public function PhoneAppPageParam($app_id) {
		$re_str=0;
		$App = new AppModel();
		$applist=$App->where("id=".$app_id)->field("rewo_setting")->select();
		if(sizeof($applist)>0)
		{	
			$src_setting=$applist[0]["rewo_setting"];
			$src_setting=json_decode($src_setting);
			for($k=0;$k<sizeof($src_setting);$k++)
			{
				if($src_setting[$k]->Name=="pageParam")
					$re_str=intval($src_setting[$k]->Default);
			}
		}
		return $re_str;
	}

	//通过app的id，返回User已经添加了的某个应用的信息，包括setting信息
	//注意修改过
	//*********************
	public function getUserAppById() {

		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		$condition['app_id'] = $_REQUEST['id'];

		if(isset($_REQUEST['set_file_num']))
			$condition['set_file_num'] = $_REQUEST['set_file_num'];		

		$UserApp = new UserAppModel();
		$result = $UserApp->table("rewo_user_app") -> where($condition)->order("app_id,set_file_num asc") -> select();

		for($p=0;$p<sizeof($result);$p++)
		{


			$app_list=$UserApp->table("rewo_app") ->where("id=".$_REQUEST['id'])->find();  
			$result[$p]["word"]=$app_list["name"];

			$result[$p]["allow_multi_set"]=intval($app_list["allow_multi_set"]);
			$result[$p]["set_file_num"]=intval($result[$p]["set_file_num"]);

			$app_list2=$UserApp->table("rewo_user_app") ->where($condition)->find();	

			$now_language="普通话";
			if($app_list2["language_flag"]==0)
				$now_language="10";
			else
				$now_language="01";

		
		if ($result[$p] !== FALSE && !empty($result[$p])) {

			$now_json1="{\"Name\":\"语音命令\",\"Category\":\"EditText\",\"Default\":\"".$app_list2["speech_command"]."\",\"Candidate\":[]}";
			$now_json2="{\"Name\":\"RFID卡\",\"Category\":\"EditText\",\"Default\":\"".$app_list2["rfid_card"]."\",\"Candidate\":[]}";
			$now_json3="{\"Name\":\"语言版本\",\"Category\":\"RadioGroup\",\"Default\":\"".$now_language."\",\"Candidate\":[\"普通话\",\"粤语\"]}";

			$now_json=$this -> buildSettingOut($condition['app_id'], $result[$p]['setting']);

			$now_json[sizeof($now_json)]=json_decode($now_json1,true);
			$now_json[sizeof($now_json)]=json_decode($now_json2,true);
			$now_json[sizeof($now_json)]=json_decode($now_json3,true);

			$result[$p]['setting'] = $now_json;
			
		} else {
			$this -> ajaxReturn(0, 'fail', 404);
		}

		}

		$this -> ajaxReturn($result, 'success', 200);

	}

	private function buildSettingOut($app_id, $setting) {
		//从服务的信息建立新的格式，面向外部调用。
		$settingJson = json_decode($setting, TRUE);
		$App = new AppModel();
		$appInfo = $App -> where(array('id' => $app_id)) -> find();
		$appsettingJson = json_decode($appInfo['setting'], TRUE);
		foreach ($appsettingJson as $key => $value) {
			$newDefault = $settingJson[$value['Name']];
			$candidate = $value['Candidate'];	
			if (!isset($value['Category']) || empty($value['Category'])) {
				unset($appsettingJson[$key]);
			} else if (empty($candidate)) {
				$appsettingJson[$key]['Default'] = $newDefault;
			} else if (!empty($candidate) && strlen($newDefault) == count($candidate)) {
				$appsettingJson[$key]['Default'] = $newDefault;
			}
		}

		for($k=0;$k<sizeof($appsettingJson);$k++)
		{
			if(eregi("^[0-9]+$",$appsettingJson[$k]["Default"]))
				$appsettingJson[$k]["Default"]="".$appsettingJson[$k]["Default"]."";
			$appsettingJson[$k]["Name"]=appChinese($appsettingJson[$k]["Name"]);
			for($n=0;$n<sizeof($appsettingJson[$k]["Candidate"]);$n++)
				$appsettingJson[$k]["Candidate"][$n]=appChinese($appsettingJson[$k]["Candidate"][$n]);
		}

		return $appsettingJson;
	}

	// private function buildSettingIn($app_id, $setting) {
	// $settingJson = $this -> keyValueToJson(urldecode($setting));
	// return $settingJson;
	// }

	// private function keyValueToJson($str) {
	// $json = array();
	// $strArray = explode('&', $str);
	// foreach ($strArray as $item) {
	// $keyValue = explode(':', $item, 2);
	// $key = trim($keyValue[0]);
	// $value = trim($keyValue[1]);
	// $json[$key] = $value;
	// }
	// return $json;
	// }

	// public function updateUserAppSettingById() {
	// $condition = array();
	// $condition['user_id'] = $_SESSION['id'];
	// $condition['app_id'] = $_REQUEST['id'];
	// $condition['setting'] = $_REQUEST['setting'];
	// $UserApp = new UserAppModel();
	// $result = $UserApp -> save($condition);
	// if ($result === FALSE) {
	// $this -> ajaxReturn(0, 'false', 503);
	// } else if ($result === 0) {
	// $this -> ajaxReturn(0, 'fail', 404);
	// } else {
	// $this -> ajaxReturn(0, 'success', 200);
	// }
	// }

	public function updateUserAppSettingById() {		
		if(!isset($_SESSION['id']))
			$this -> ajaxReturn(0, 'no user_id', 400);
			
		if(isset($_REQUEST["app_id"])&&isset($_REQUEST["operator"]))
		{
			$operator=$_REQUEST["operator"];
			$now_con=array();
			$now_con["user_id"]=$_SESSION['id'];
			$now_con["app_id"]=$_REQUEST["app_id"];
			if(isset($_REQUEST["set_file_num"]))
				$now_con["set_file_num"]=$_REQUEST["set_file_num"];
			$UserApp = new UserAppModel();
			if($operator=="delete")
			{	$result=$UserApp->where($now_con)->delete(); 
			}else if($operator=="add"){
				if(isset($_REQUEST["setting_json"]))
				{

					$now_con2=array();
					$now_con2["user_id"]=$_SESSION['id'];
					$now_con2["app_id"]=$_REQUEST["app_id"];

					$now_con=array();
					$now_con["user_id"]=$_SESSION['id'];
					$now_con["app_id"]=$_REQUEST["app_id"];
				        $now_json=$_REQUEST["setting_json"];
					$now_json=str_replace("\\","",$now_json);
					$now_json=json_decode($now_json);

					
						$Name_1="语音命令";
						if(isset($now_json->$Name_1))
						{
							$now_con["speech_command"]=$now_json->$Name_1;

							unset($now_json->$Name_1);
						}

						$Name_2="RFID卡";
						if(isset($now_json->$Name_2))
						{
							$now_rfidCard=$now_json->$Name_2;
							$UserApp = new UserAppModel();
							$card_list=$UserApp->where("user_id=".$_SESSION['id'])->field("rfid_card,app_id,set_file_num")->select();
			
							for($m=0;$m<sizeof($card_list);$m++)
							{
								$set_file_num=0;
									if($card_list[$m]["rfid_card"]==$now_rfidCard&&($now_rfidCard!=$card_list[$m]["app_id"]||($now_rfidCard==$card_list[$m]["app_id"]&&$set_file_num!=$card_list[$m]["set_file_num"])))
							{
								$this -> ajaxReturn(0, 'rfid card Conflict', 405);
							}
							}
							$now_con["rfid_card"]=$now_json->$Name_2;

							unset($now_json->$Name_2);
						}

						$Name_3="语言版本";
						if(isset($now_json->$Name_3))
						{
							$now_value="0";
							if($now_json->$Name_3=="01")
								$now_value=1;
							$now_con["language_flag"]=$now_value;

							unset($now_json->$Name_3);
						}
					
					$now_con["setting"]=json_encode($now_json);
					$now_num=$UserApp->where($now_con2)->field("max(set_file_num) as num")->find();
					$now_con["set_file_num"]=intval($now_num["num"]+1);
					$now_con["set_file_name"]="档案".$now_con["set_file_num"];

					//print_r($now_con);
					$result=$UserApp->add($now_con);

				}else
					$result=0;
			}
			else
				$result=0;
			if($result)
			{
				echo "{\"status\":200,\"info\":\"success\",\"data\":0}";
				$this -> notifyUpdateAppConfig($_REQUEST["app_id"],$_SESSION['id'],false);
return 1;
			}
				else
					$this -> ajaxReturn(0, 'failed', 400);

		}

		if(isset($_REQUEST["app_id"])&&isset($_REQUEST["Default"])&&isset($_REQUEST["Name"]))
		{
			
		$now_con=array();
		$now_con["user_id"]=$_SESSION['id'];
		$now_con["app_id"]=$_REQUEST["app_id"];
		$set_file_num=0;
			if(isset($_REQUEST["set_file_num"]))
			{
				$now_con["set_file_num"]=$_REQUEST["set_file_num"];
				$set_file_num=$_REQUEST["set_file_num"];
			}

		if($_REQUEST["Name"]=="语音命令")
		{
			$UserApp = new UserAppModel();
			$data=array();
			$data["speech_command"]=$_REQUEST["Default"];
			$now_list=$UserApp->where($now_con)->field("speech_command")->find();
			if($now_list["speech_command"]==$_REQUEST["Default"])
				$result=1;
			else
				$result=$UserApp->where($now_con)->save($data);
		}else if($_REQUEST["Name"]=="RFID卡")
		{
			$UserApp = new UserAppModel();
			$data=array();
			$data["rfid_card"]=$_REQUEST["Default"];
			$card_list=$UserApp->where("user_id=".$_SESSION['id'])->field("rfid_card,app_id,set_file_num")->select();
			
			for($m=0;$m<sizeof($card_list);$m++)
			{
				if($set_file_num==0)
					$set_file_num=$card_list[$m]["set_file_num"];
				if($card_list[$m]["rfid_card"]==$data["rfid_card"]&&($_REQUEST["app_id"]!=$card_list[$m]["app_id"]||($_REQUEST["app_id"]==$card_list[$m]["app_id"]&&$set_file_num!=$card_list[$m]["set_file_num"])))
				{
						$this -> ajaxReturn(0, 'rfid card Conflict', 405);
				}
			}

			$now_list=$UserApp->where($now_con)->field("rfid_card")->find();
			if($now_list["rfid_card"]==$_REQUEST["Default"])
				$result=1;
			else
				$result=$UserApp->where($now_con)->save($data);
		}else if($_REQUEST["Name"]=="语言版本")
		{
			$UserApp = new UserAppModel();
			$data=array();
			if($_REQUEST["Default"]=="10")
				$data["language_flag"]=0;
			else if($_REQUEST["Default"]=="01")
				$data["language_flag"]=1;
			$now_list=$UserApp->where($now_con)->field("language_flag")->find();
			if($now_list["language_flag"]==$_REQUEST["Default"])
				$result=1;
			else
				$result=$UserApp->where($now_con)->save($data);
		}else{

		$req_name=appEnglish($_REQUEST["Name"]);
		$UserApp = new UserAppModel();
		$src_set=$UserApp->where($now_con)->field("setting")->find();
		$src_set=json_decode($src_set["setting"]);

		$flag=0;
		for($k=0;$k<sizeof($src_set);$k++)
		{
				$now_name=$req_name;
				if($src_set->$now_name==$_REQUEST["Default"])
					$flag=1;
				$src_set->$now_name=$_REQUEST["Default"];
		}
		$data=array();
		if(sizeof($src_set)<=0)
		{
			$src_set=array();
			$src_set[$req_name]=$_REQUEST["Default"];
		}

		$data["setting"]=json_encode($src_set);
		if($flag==0)
			$result=$UserApp->where($now_con)->save($data);
		else
			$result=1;



		}


		if($result)
		{
			//$this -> ajaxReturn(0, 'success', 200);
			echo "{\"status\":200,\"info\":\"success\",\"data\":0}";
			$this -> notifyUpdateAppConfig($_REQUEST["app_id"],$_SESSION['id'],false);
		}
		else
			$this -> ajaxReturn(0, 'failed', 400);


		


		}else
		{

		if(!isset($_REQUEST['JSONAppSetParams']))
			$this -> ajaxReturn(0, 'no JSONAppSetParams', 400);

		//更新用户已经添加了的app的配置信息。其中信息的传输格式为json。the second parameter is to make the decode result
		$JSONAppSetParams=$_REQUEST["JSONAppSetParams"];
		//$JSONAppSetParams=substr($JSONAppSetParams,1,strlen($JSONAppSetParams)-2);
		
		$JSONAppSetParams=str_replace("\\","",$JSONAppSetParams);
		$json = json_decode($JSONAppSetParams,TRUE);
		//echo " JSONAppSetParams:".$JSONAppSetParams."<br/> json:".$json."<br/> ";
		
		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		$condition['app_id'] = $json['app_id'];
		if(isset($_REQUEST["set_file_num"]))
			$condition['set_file_num'] = $_REQUEST['set_file_num'];
		
		$setting = array();
		foreach ($json['setting'] as $key => $value) {
			$setting[$value['Name']] = $value['Default'];
		}
		$data=array();
		$data['setting']= json_encode($setting);
		
		$UserApp = new UserAppModel();
		$list = $UserApp -> where($condition) -> select();
		if($list[0]['setting']==$data['setting'])
		{
			$this -> ajaxReturn(0, "成功", 200);
		}
		//print_r($condition);
		//print_r($data);
		
		
		/*
		$condition = array();
		$condition['user_id'] = 1;
		$condition['app_id'] = 58;
		$data=array();
		$data['setting']= "{".$JSONAppSetParams."}";
		$UserApp = new UserAppModel();
		*/
		$result = $UserApp -> where($condition) -> save($data);
		if ($result > 0) {

			echo "{\"status\":200,\"info\":\"成功\",\"data\":0}";
			$this -> notifyUpdateAppConfig($_REQUEST["app_id"],$_SESSION['id'],false);

			//$this -> ajaxReturn(0, "成功", 200);
		} else {
			$this -> ajaxReturn(0, "失败", 503);
		}
		print_r($condition);

		}
		
	}

	//---------------------------------------------------------
	//应用的添加删除
	//为用户添加某个应用，应用了事务处理
	public function add() {
		if (!isset($_SESSION['id'])) {
			$this -> ajaxReturn(0, 'no user_id', 400);
		}
		if (!isset($_REQUEST['id'])) {
			$this -> ajaxReturn(0, 'no app_id', 400);
		}

		$condition = array();
		//将session中的id取出作为user_id
		//echo $_REQUEST['id'];
		$condition['user_id'] = $_SESSION['id'];
		//将request中的id取出作为app_id
		$condition['app_id'] = $_REQUEST['id'];
			if(isset($_REQUEST["set_file_num"]))
				$condition['set_file_num'] = $_REQUEST['set_file_num'];

		$UserApp = new UserAppModel();
		$userAppInfo = $UserApp -> where($condition) -> find();



		if ($userAppInfo != 0) {
			$userAppInfo['flag'] = intval($userAppInfo['flag']) + 1;
			$UserApp -> save($userAppInfo);
			$this -> ajaxReturn(0, 'success change', 201);
		}

		//prepare some information to initial the user application
		$App = new AppModel();
		$appInfo = $App -> where(array('id' => $condition['app_id'])) -> find();
		$setting = json_decode($appInfo['setting'], TRUE);
		$defaultSetting = array();
		foreach ($setting as $key => $value) {
		$defaultSetting[$value['Name']] = $value['Default'];
		}
		$condition['setting'] = json_encode($defaultSetting);

		$User = new UserModel();
		$User -> startTrans();

		$userInfo = $User -> where(array('id' => $condition['user_id'])) -> find();

		if ($userInfo['balance'] > $appInfo['price'] && $appInfo['price'] >= 0) {
			$userInfo['balance'] -= $appInfo['price'];
			$userResult = $User -> save($userInfo);

			// 添加时候的初始状态flag可以在这里修改
			$condition['flag'] = 1;
			$userAppResult = $UserApp -> add($condition);
			if (($appInfo['price'] == 0 || $userResult) && $userAppResult) {
				$User -> commit();
				$this->RemakeUserSpeechFile();

				//$this -> ajaxReturn(0, 'success add', 200);
				echo "{\"status\":200,\"info\":\"success add\",\"data\":0}";
				$this -> notifyUpdateAppConfig($_REQUEST["app_id"],$_SESSION['id'],true);

			} else {
				$User -> rollback();
				// it's fail to add the app to user's app list
				$this -> ajaxReturn(0, 'fail', 503);
			}
		} else {
			$User -> rollback();
			$this -> ajaxReturn(0, 'balance not enough', 404);
		}
	}

	//删除用户的某个应用
	public function delete() {
		if (!isset($_SESSION['id'])) {
			$this -> ajaxReturn(0, 'no user_id', 400);
		}
		if (!isset($_REQUEST['id'])) {
			$this -> ajaxReturn(0, 'no app_id', 400);
		}
		$condition = array();
		$condition['user_id'] = $_SESSION['id'];
		$condition['app_id'] = $_REQUEST['id'];
			if(isset($_REQUEST["set_file_num"]))
				$condition['set_file_num'] = $_REQUEST['set_file_num'];
		$UserApp = new UserAppModel();
		$userAppInfo = $UserApp -> where($condition) -> find();
		//if the result is false
		if ($userAppInfo === FALSE) {
			$this -> ajaxReturn(0, 'false', 503);
		}

		//if the result is null(there is no such record)
		if ($userAppInfo === NULL) {
			$this -> ajaxReturn(0, 'null', 404);
		}

		//if the result is just like we want
		$App = new AppModel();
		$appInfo = $App -> where(array('id' => $userAppInfo['app_id'])) -> find();

		unset($userAppInfo['setting']);
		unset($userAppInfo['word']);

		if ($appInfo['price'] <= 0) {
			//unset($userAppInfo['flag']);
			if ($UserApp -> where($userAppInfo) -> delete() > 0) {
				$this->RemakeUserSpeechFile();

				//$this -> ajaxReturn(0, 'success delete', 200);
				echo "{\"status\":200,\"info\":\"success delete\",\"data\":0}";
				$this -> notifyUpdateAppConfig($_REQUEST["app_id"],$_SESSION['id'],false);

			} else {
				$this -> ajaxReturn(0, 'fail delete', 503);
			}
		} else {
			$userAppInfo['flag'] = 0;
			print_r($userAppInfo);
			if ($UserApp -> save($userAppInfo) > 0) {
				$this -> ajaxReturn(0, 'success change', 200);
			} else {
				$this -> ajaxReturn(0, 'fail change', 503);
			}
		}
	}

	//重新生成用户语音命令文件
	public function RemakeUserSpeechFile() {
		if (!$_SESSION['id']) {
			exit;
		}
		if(isset($_SESSION['id']))
		{
			$nowUser = new UserModel();
			$user_path="../../../aptana/public_image/user/".MakeUserPath($_SESSION['id'])."";			
			if(!file_exists($user_path)){       
			mkdir($user_path,0777,true);   
			}
			
			$list=$nowUser->table("rewo_user_app")->where("user_id=".$_SESSION['id'])->field("speech_command")->select();
			
			if(!file_exists($user_path.$_SESSION['id']."_speech.txt"))
 		    	touch($user_path.$_SESSION['id']."_speech.txt");
			
			$write_str="";
			for($k=0;$k<sizeof($list);$k++)
				$write_str.=$list[$k]["speech_command"]."\n";
			
			$handle=fopen($user_path.$_SESSION['id']."_speech.txt",'w');
			fwrite($handle,$write_str);
			fclose($handle);
			
			exec("python ../../speech_command_python/C2Sphinx.py ".$user_path.$_SESSION['id']."_speech.txt ".$user_path);
			
			$list=$nowUser->table("rewo_user_product")->where("user_id=".$_SESSION['id'])->field("product_id")->select();
			if(sizeof($list)>0)
			{
				$myNatManager=new NatManager();
				$myNatManager->getUserSpeechZipFile($list[0]["product_id"]);
			}
		}
	
	}

	//向守护进程发送同步用户应用
	public function notifyUpdateAppConfig($app_id,$user_id,$is_new) {

			$nowUser = new UserModel();
			$product_id=$nowUser->table("rewo_user,rewo_user_product")
			->where("rewo_user.id=rewo_user_product.user_id and rewo_user.id='".$user_id."'")
			->field("product_id")->select();
			if(sizeof($product_id)>0)
			{
				$myNatManager=new NatManager();
				$myNatManager->notifyUpdateConfig($product_id[0]["product_id"], $app_id,$is_new);
			}
		
	}



}
?>
