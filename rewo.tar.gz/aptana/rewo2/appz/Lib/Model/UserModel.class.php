<?php

class UserModel extends Model {
	protected $_validate = array(
		array('username', 'require', '用户名必须', 1),
		array('email', 'email', '格式错误', 1),
		array('id', '', 'id已经存在', 0, 'unique', self::MODEL_INSERT),
		array('username', '', '用户名已经存在', 0, 'unique', self::MODEL_INSERT),
		array('email', '', 'email已经存在', 0, 'unique', self::MODEL_INSERT),
	);
}
?>
