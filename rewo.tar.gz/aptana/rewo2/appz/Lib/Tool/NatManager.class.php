<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NatManager
 * @version 1.0 2012-11-7
 * @author 余海坚
 */
class NatManager
{
    //命令常量
    const NOTIFY_UPDATE_CONFIG           = 15; //通知机器人更新配置
    const NOTIFY_NEW_APP                 = 16; //通知机器人有新的应用可下载
    const BROADCAST_NOTIFY_UPDATE_CONFIG = 17; //通知机器人同步公共应用数据
    const NOTIFY_GET_USERSPEECHZIPFILE   = 18; //通知机器人同步用户语音字典文件
    const NOTIFY_UPDATE_RESOURCE         = 19; //通知机器人更新资源
    const NOTIFY_GET_USERFRIENDSZIPFILE  = 20; //通知机器人同步用户联系人字典文件

    //网络参数常量
    const IP   = '118.123.18.238';
    const PORT = 11111;

    /**
     * 通知机器人更新应用资源，一般指脚本文件
     * @param type $robot_id
     */
    public function notifyUpdateResource($robot_id, $app_id)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::NOTIFY_UPDATE_RESOURCE) . pack('I', $robot_id) . pack('I', $app_id);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }

    /**
     * 通知机器人更新应用配置
     * @param type $robot_id
     * @param type $app_id
     * @param type $is_new_app 是否是新安装的应用
     */
    public function notifyUpdateConfig($robot_id, $app_id, $is_new_app = false)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::NOTIFY_UPDATE_CONFIG) . pack('I', $robot_id)
                . pack('I', $app_id) . pack('I', (int)$is_new_app);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }
    
    /**
     * 广播通知在线机器人有新的应用可下载
     * @param type $app_id
     * @return boolean
     */
    public function broadcastNewApp($app_id)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::NOTIFY_NEW_APP) . pack('I', $app_id);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }
    
    /**
     * 通知机器人同步公共应用数据
     * @param type $app_id
     * @param type $is_new 是否新增加的应用
     */
    public function broadcastNotifyUpdateConfig($app_id, $is_new = FALSE)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::BROADCAST_NOTIFY_UPDATE_CONFIG) . pack('I', $app_id)
                . pack('I', (int)$is_new);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }
    
    /**
     * 通知机器人同步用户语音字典文件
     * @param type $robot_id
     * @return boolean
     */
    public function getUserSpeechZipFile($robot_id)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::NOTIFY_GET_USERSPEECHZIPFILE) . pack('I', $robot_id);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }
    
    /**
     * 通知机器人同步用户联系人字典文件
     * @param type $robot_id
     */
    public function getUserFriendsZipFile($robot_id)
    {
        $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if (!$socket)
        {
            return false;
        }

        if (!@socket_connect($socket, self::IP, self::PORT))
        {            
            socket_close($socket);
            return false;
        }
        
        //打包数据
        $data = pack('C', self::NOTIFY_GET_USERFRIENDSZIPFILE) . pack('I', $robot_id);

        if (!@socket_write($socket, $data, strlen($data)))
        {
            socket_close($socket);
            return false;
        }

        socket_close($socket);
        return true;
    }
}
