<?php if (!defined('THINK_PATH')) exit();?>
<html>
	<head>
		
		<title>测试成才图片的上传</title>
	</head>
	<body>
	<center>
		<form method="post" action="__ROOT__/appz/index.php/UserGrow/saveUserGrowPic" enctype="multipart/form-data">
			<input type="file" name="file" style='cursor:pointer;'/>
			<input type="text" name="info" value=""/>
			<input type="submit" value="上传" style='cursor:pointer;'>
		</form>


	</center>
	</body>
</html>