<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>User App</title>
		<meta name="author" content="Yefn" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
		<link type="text/css" href="__PUBLIC__/Css/Appz/userApp.css" rel="stylesheet">
	</head>
	<body>
		<div id="page">
			<div id="headerPage">
				<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<body>
<div id="header">
				<div id="headerContent">
					<div id="logo"></div>
					<ul class="nav">
						<li><a href="#">Home</a></li>
						<li><a href="#">About us</a></li>
						<li><a href="<?php echo U('Index/index');?>">App store</a></li>
						<li><a href="#">Support</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
					<div id="banner">
						<form method="post" action="#" name="searchForm">
							<input id="search" class="textBox" type="txt" value="输入关键字" name="search">
							<label>
								<a href="#">高级搜索</a>
							</label>
							<input class="go" type="button" value="Go" name="go">
						</form>
					</div>
				</div>
			</div>
</body>
			</div>
		
			<div id="content">
				<div id="showUserApps">
					<?php if(is_array($userAppList)): foreach($userAppList as $key=>$app): ?><a href="<?php echo ($app["displayUrl"]); ?>">
							<div class="app">
								<div class="appImg">
									<img alt="<?php echo ($app["name"]); ?>" src="__PUBLIC__/Images/AppIcon/YouTube.png">
								</div>
								<div class="appContent">
									<h3 class="appName"><?php echo ($app["name"]); ?></h3>
									<h3 class="deleteApp">删除应用</span>
								</div>
							</div>
						</a><?php endforeach; endif; ?>
				</div>
				
				<div id="rightBar">
					<div id="welcomeUser">
						<h2>欢迎您!</h2>
					</div>
					<div id="tuijieApp">
						<h2>推荐应用</h2>
						<ul>
							<li>应用1</li>
							<li>应用2</li>
							<li>应用3</li>
							<li>应用4</li>
						</ul>
					</div>
				</div>
			</div>
				
			<div id="footerPage">
				<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<div id="footer">
	<div id="footerLogo">
			<img src="__PUBLIC__/Images/logo_footer" alt="REWO">
	</div>
	<div id="footerContent">
		<div id="footerNav">
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="<?php echo U('Index/index');?>">APP Store</a></li>
				<li><a href="#">Support</a></li>
				<li><a href="#">Contact Us</a></li>
				<li><a href="#">About Us</a></li>
			</ul>
		</div>
		<div id="copyright">
		<h3>Copyright @ Wo-rehov co.ltd 2012-2013. All Rights Reserved.</h3>
		</div>
	</div>
</div>
			</div>
		</div>
	</body>
</html>