<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
		<title>重置密码</title>
		<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>

		<script type="text/javascript">
			function checkNewPWD()
			{
			  new_pwd=document.getElementById("new_pwd").value;
			  if(new_pwd.length<6)
				document.getElementById("tip").innerHTML="密码至少6位";
			  else
				document.getElementById("tip").innerHTML="";			
			}
			function checkNewPWD2()
			{
			  new_pwd2=document.getElementById("new_pwd2").value;
			  new_pwd=document.getElementById("new_pwd").value;
			  if(new_pwd2!=new_pwd)
				document.getElementById("tip").innerHTML="确认新密码不正确";
			  else
				document.getElementById("tip").innerHTML="";			
			}
		</script>
	</head>
	<body>
	<center>
		<form method='post' action='<?php echo U('User/phoneResetPWD');?>'>
			<table>
				<tr><td align='right' valign='middle'>新密码：</td><td align='left' valign='middle'><input type='password' id='new_pwd' name='new_pwd' onblur='checkNewPWD()'/></td></tr>
				<tr><td align='right' valign='middle'>确认新密码：</td><td align='left' valign='middle'><input type='password' id='new_pwd2' name='new_pwd2' onblur='checkNewPWD2()'/></td></tr>
				<tr><td align='right' valign='middle'></td><td align='left' valign='middle'><input type='submit' value='提交' /><input type='hidden' id='rand' name='rand' value='<?php echo ($randStr); ?>'></td></tr>
				<tr><td align='right' valign='middle'></td><td align='left' valign='middle'><label id='tip' color='red'></label></td></tr>
			</table>
		</form>
	</center>
	</body>
</html>