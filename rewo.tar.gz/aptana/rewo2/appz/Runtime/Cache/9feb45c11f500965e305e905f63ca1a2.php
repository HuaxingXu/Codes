<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>App Detail</title>
		<meta name="author" content="Yefn" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
		<link type="text/css" href="__PUBLIC__/Css/Appz/detail.css" rel="stylesheet">
	</head>
	<body>
		<div id="page">
		<div id="headerPage">
			<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">

<script type="text/javascript">

function clickSearch(){
						if($("#search").val()!="输入关键字"&&$("#search").val()!="")
						{
							var search=$("#search").val();
							$.ajax({
							type: "POST",
							url: "<?php echo ($Url['searchUrl']); ?>",
							dataType:"text",
							data:{"search":search},
							beforeSend: function() {},
							success: function(json) {
							    json=eval('(' + json + ')');
								re_str="";
								if(json!=null)
								{
									now_location=document.location.href;
									now_location_end=now_location.indexOf("index.php");
									if(now_location_end>0)
										now_location=now_location.substr(0,now_location_end);
									for(i=0;i<json.length;i++)
									{
										re_str+="<a href=\""+now_location+"index.php/App/index?id="+json[i].id+"\">";  
										re_str+="<div class=\"app\">";
										re_str+="<div class=\"appImg\">";
										re_str+="<img alt=\""+json[i].name+"\" src=\"__PUBLIC__/Images/AppIcon/YouTube.png\">";
										re_str+="<span class=\"addApp\">添加应用</span>";
										re_str+="</div>";
										re_str+="<div class=\"appContent\">";
										re_str+="<h2 class=\"appName\">"+json[i].name+"</h2>";
										re_str+="<p class=\"description\">"+json[i].info+"</p>";
										re_str+="</div></div></a>";
									}
								}
								 $("#applications").html(re_str);
							}
							});
					
						}
                      }

  $(document).ready(function () {
			 	$("#search").click(function() {
				    if($("#search").val()=="输入关键字")
				    $("#search").val("");
					});
					
				$("#search").blur(function() {
				    if($("#search").val()=="")
				    $("#search").val("输入关键字");
					});
					
				$("#goSearch").click(function() {
				       clickSearch();
					});
			    
			 });
</script>

</head>
<body>
<div id="header">
				<div id="headerContent">
					<div id="logo"></div>
					<ul class="nav">
						<li><a href="<?php echo U('Index/home');?>">主页</a></li>
						<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
						<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
						<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
						<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
					</ul>
					<div id="banner">
						<form method="post" action="<?php echo U('Index/index');?>" name="searchForm"><!-- <?php echo U('Index/search');?>   onkeydown="if(event.keycode==13){clickSearch();};" -->
							<input id="search" class="textBox" type="txt" value="输入关键字" name="search">
							<label>
								<a href="#">高级搜索</a>
							</label>
							<input class="go" id="goSearch" type="button" value="Go" name="go">
						</form>
					</div>
				</div>
			</div>
</body>

		</div>
		
		<div id="content">
			<div id="appDetail">
				<div id="detailLeftArea">
					<div id="appIcon">
						<img alt="App Icon" src="<?php echo ($app["image"]); ?>">
					</div>
					<div id="appCharacteristic">
						<p>种类: <?php echo ($app["category"]); ?></p>
						<p>上架日期:<?php echo ($app["time"]); ?></p>
						<p>版本:<?php echo ($app["version"]); ?></p>
						<p>作者:<?php echo ($app["author"]); ?></p>
					</div>
				</div>
				<div id="detailRightArea">
					<div id="appName">
						<h1><?php echo ($app["name"]); ?></h1>
					</div>
					<div id="appDesciption">
						<p><?php echo ($app["info"]); ?></p>
					</div>
					<div id="appAddButton">
						<input alt="Add" name="Add" type="button" value="添加">
					</div>
				</div>
			</div>
			<div id="rightArea">
				<h1>具体内容未定</h1>
			</div>
		</div>
		
		<div id="footerPage">
			<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<div id="footer">
	<div id="footerLogo">
			<img src="__PUBLIC__/Images/logo_footer.png" alt="REWO">
	</div>
	<div id="footerContent">
		<div id="footerNav">
			<ul>
				<li><a href="<?php echo U('Index/home');?>">主页</a></li>
				<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
				<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
				<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
				<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
			</ul>
		</div>
		<div id="copyright">
		<h3>Copyright @ Wo-rehov co.ltd 2012-2013. All Rights Reserved.</h3>
		</div>
	</div>
</div>
		</div>
	</div>
	</body>
</html>