<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Register</title>
<meta name="Author" content="Yefn">
<meta name="description" content="" />
<meta name="keywords" content="" />
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
<link type="text/css" href="__PUBLIC__/Css/Appz/register.css" rel="stylesheet">
<script src="__PUBLIC__/Js/jquery-1.7.js" type="text/javascript"></script>
<script src="__PUBLIC__/Js/formValidator-4.1.1.js" type="text/javascript" charset="UTF-8"></script>
<script src="__PUBLIC__/Js/formValidatorRegex.js" type="text/javascript" charset="UTF-8"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$.formValidator.initConfig({formID:"regForm",theme:'ArrowSolidBox',mode:'AutoTip',onError:function(msg){alert(msg)},inIframe:true});
		$("#username").formValidator({onShow:"请输入用户名,只有输入\"maodong\"才是对的",onFocus:"用户名至少6个字符,最多10个字符",onCorrect:"该用户名可以注册"}).inputValidator({min:6,max:10,onError:"你输入的用户名非法,请确认"}).regexValidator({regExp:"username",dataType:"enum",onError:"用户名格式不正确"});
	    // .ajaxValidator({
		// dataType : "html",
		// async : true,
		// url : "",
		// success : function(data){
            // if( data.indexOf("此用户名可以注册!") > 0 ) {return true};
			// return data;
		// },
		// buttons: $("#button"),
		// error: function(jqXHR, textStatus, errorThrown){alert("服务器没有返回数据，可能服务器忙，请重试"+errorThrown);},
		// onError : "该用户名不可用，请更换用户名",
		// onWait : "正在对用户名进行合法性校验，请稍候..."
		// });
		$("#password1").formValidator({onShow:"请输入密码",onFocus:"密码不能为空",onCorrect:"密码合法"}).inputValidator({min:3,onError:"密码至少3个字符,请确认"});
		$("#password2").formValidator({onShow:"请输入重复密码",onFocus:"两次密码必须一致哦",onCorrect:"密码一致"}).inputValidator({min:3,onError:"密码至少3个字符,请确认"}).compareValidator({desid:"password1",operateor:"=",onError:"2次密码不一致,请确认"});
		$("#email").formValidator({onShow:"请输入邮箱",onFocus:"邮箱至少6个字符,最多100个字符",onCorrect:"恭喜你,你输对了",defaultValue:"@"}).inputValidator({min:6,max:100,onError:"你输入的邮箱长度非法,请确认"}).regexValidator({regExp:"^([\w-.]+)@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.)|(([\\w-]+.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(]?)$",onError:"你输入的邮箱格式不正确"});
		$.formValidator.reloadAutoTip();
	});
	
	function reloadAutoTip()
	{
		$.formValidator.reloadAutoTip();
	}
</script>

</head>
<body>
	<div id="page">
		<div id="headerPage">
			<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">

<script type="text/javascript">

function clickSearch(){
						if($("#search").val()!="输入关键字"&&$("#search").val()!="")
						{
							var search=$("#search").val();
							$.ajax({
							type: "POST",
							url: "<?php echo ($Url['searchUrl']); ?>",
							dataType:"text",
							data:{"search":search},
							beforeSend: function() {},
							success: function(json) {
							    json=eval('(' + json + ')');
								re_str="";
								if(json!=null)
								{
									now_location=document.location.href;
									now_location_end=now_location.indexOf("index.php");
									if(now_location_end>0)
										now_location=now_location.substr(0,now_location_end);
									for(i=0;i<json.length;i++)
									{
										re_str+="<a href=\""+now_location+"index.php/App/index?id="+json[i].id+"\">";  
										re_str+="<div class=\"app\">";
										re_str+="<div class=\"appImg\">";
										re_str+="<img alt=\""+json[i].name+"\" src=\"__PUBLIC__/Images/AppIcon/YouTube.png\">";
										re_str+="<span class=\"addApp\">添加应用</span>";
										re_str+="</div>";
										re_str+="<div class=\"appContent\">";
										re_str+="<h2 class=\"appName\">"+json[i].name+"</h2>";
										re_str+="<p class=\"description\">"+json[i].info+"</p>";
										re_str+="</div></div></a>";
									}
								}
								 $("#applications").html(re_str);
							}
							});
					
						}
                      }

  $(document).ready(function () {
			 	$("#search").click(function() {
				    if($("#search").val()=="输入关键字")
				    $("#search").val("");
					});
					
				$("#search").blur(function() {
				    if($("#search").val()=="")
				    $("#search").val("输入关键字");
					});
					
				$("#goSearch").click(function() {
				       clickSearch();
					});
			    
			 });
</script>

</head>
<body>
<div id="header">
				<div id="headerContent">
					<div id="logo"></div>
					<ul class="nav">
						<li><a href="<?php echo U('Index/home');?>">主页</a></li>
						<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
						<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
						<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
						<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
					</ul>
					<div id="banner">
						<form method="post" action="<?php echo U('Index/index');?>" name="searchForm"><!-- <?php echo U('Index/search');?>   onkeydown="if(event.keycode==13){clickSearch();};" -->
							<input id="search" class="textBox" type="txt" value="输入关键字" name="search">
							<label>
								<a href="#">高级搜索</a>
							</label>
							<input class="go" id="goSearch" type="button" value="Go" name="go">
						</form>
					</div>
				</div>
			</div>
</body>

		</div>
		
		<div id="content">
			<div id="regPanel">
				<h2>注册新用户</h2>
				<form id="regForm" name="regForm" method="post" action="<?php echo U('User/signup');?>">
					<div class="txt_row">
						<label>用户名:</label>
						<input id="username" class="txtBox"  type="text" alt="username" name="username">
					</div>
					<div class="txt_row">
					<label id="pw_lb">设置密码:</label>
					<input id="password1" class="txtBox"  type="text" alt="password" name="password">
					</div>
					<div class="txt_row">
					<label id="pw_lb">重复密码:</label>
					<input id="password2" class="txtBox"  type="text" alt="password" name="password">
					</div>
					<div class="txt_row">
					<label id="pw_lb">电子邮箱:</label>
					<input id="email" class="txtBox"  type="text" alt="email" name="email">
					</div>
					<input id="regBtn" type="submit" name="regBtn" alt="regBtn" value="注册" >	 
				</form>
			</div>
			<div id="logPanelInReg">
				<h2>已经注册？</h2>
				<form id="logForm" name="logForm" method="post" action="<?php echo U('User/auth');?>">
					<div class="txt_row">
						<label>用户名:</label>
						<input id="username" class="txtBox"  type="text" alt="username" name="username">
					</div>
					<div class="txt_row">
					<label id="pw_lb_log">密码:</label>
					<input id="password1" class="txtBox"  type="text" alt="password" name="password">
					</div>
					<input id="logBtn" type="submit" name="logBtn" alt="logBtn" value="直接登录" >	 
				</form>
			</div>
		</div>
		
		<div id="footerPage">
			<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<div id="footer">
	<div id="footerLogo">
			<img src="__PUBLIC__/Images/logo_footer.png" alt="REWO">
	</div>
	<div id="footerContent">
		<div id="footerNav">
			<ul>
				<li><a href="<?php echo U('Index/home');?>">主页</a></li>
				<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
				<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
				<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
				<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
			</ul>
		</div>
		<div id="copyright">
		<h3>Copyright @ Wo-rehov co.ltd 2012-2013. All Rights Reserved.</h3>
		</div>
	</div>
</div>
		</div>
	</div>
</body>
</html>