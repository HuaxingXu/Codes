<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
		<title>Home</title>
		<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
		<link type="text/css" href="__PUBLIC__/Css/Appz/userCenter.css" rel="stylesheet">

		<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$("dd").hide();
				$("dt a").click(function() {
					$(this).parent().nextAll("dd").slideToggle();
					//$(this).parent().prevAll("dd").slideUp("slow");
					//$(this).parent().next().nextAll("dd").slideUp("slow");
					return false;
				});
			});
		</script>
	</head>
	<body>
		<div id="page">
			<div id="headerPage">
				<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">

<script type="text/javascript">

function clickSearch(){
						if($("#search").val()!="输入关键字"&&$("#search").val()!="")
						{
							var search=$("#search").val();
							$.ajax({
							type: "POST",
							url: "<?php echo ($Url['searchUrl']); ?>",
							dataType:"text",
							data:{"search":search},
							beforeSend: function() {},
							success: function(json) {
							    json=eval('(' + json + ')');
								re_str="";
								if(json!=null)
								{
									now_location=document.location.href;
									now_location_end=now_location.indexOf("index.php");
									if(now_location_end>0)
										now_location=now_location.substr(0,now_location_end);
									for(i=0;i<json.length;i++)
									{
										re_str+="<a href=\""+now_location+"index.php/App/index?id="+json[i].id+"\">";  
										re_str+="<div class=\"app\">";
										re_str+="<div class=\"appImg\">";
										re_str+="<img alt=\""+json[i].name+"\" src=\"__PUBLIC__/Images/AppIcon/YouTube.png\">";
										re_str+="<span class=\"addApp\">添加应用</span>";
										re_str+="</div>";
										re_str+="<div class=\"appContent\">";
										re_str+="<h2 class=\"appName\">"+json[i].name+"</h2>";
										re_str+="<p class=\"description\">"+json[i].info+"</p>";
										re_str+="</div></div></a>";
									}
								}
								 $("#applications").html(re_str);
							}
							});
					
						}
                      }

  $(document).ready(function () {
			 	$("#search").click(function() {
				    if($("#search").val()=="输入关键字")
				    $("#search").val("");
					});
					
				$("#search").blur(function() {
				    if($("#search").val()=="")
				    $("#search").val("输入关键字");
					});
					
				$("#goSearch").click(function() {
				       clickSearch();
					});
			    
			 });
</script>

</head>
<body>
<div id="header">
				<div id="headerContent">
					<div id="logo"></div>
					<ul class="nav">
						<li><a href="<?php echo U('Index/home');?>">主页</a></li>
						<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
						<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
						<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
						<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
					</ul>
					<div id="banner">
						<form method="post" action="<?php echo U('Index/index');?>" name="searchForm"><!-- <?php echo U('Index/search');?>   onkeydown="if(event.keycode==13){clickSearch();};" -->
							<input id="search" class="textBox" type="txt" value="输入关键字" name="search">
							<label>
								<a href="#">高级搜索</a>
							</label>
							<input class="go" id="goSearch" type="button" value="Go" name="go">
						</form>
					</div>
				</div>
			</div>
</body>

			</div>

			<div id="content">
				<div id="op_leftNav">
					<div id="userInfo" class="clearfix">
						<img id="userIcon" alt="Icon" src="<?php echo U('User/getUserIcon');?>">
						<p id="username">
							<span>User Name</span>
						</p>
					</div>
					<p id="hint">
						请选择你要进行的操作
					</p>
					<ul id="menu">
						<li class="current">
							<a class="link" id="it_userInfo" href="#">个人信息</a>
						</li>
						<li>
							<a class="link" id="it_myApp" href="<?php echo U('User/app');?>">我的应用</a>
						</li>
						<li>
							<dl>
								<dt  id="it_hardware">
									<a href="javascript:void(0)">硬件绑定</a>
									<a class="turn_off" href="javascript:void(0)"><img id="arch" alt="" src="__PUBLIC__/Images/arch_1.png"></a>
								</dt>
								<dd>
									<a class="title" href="<?php echo U('User/robot');?>">机器人</a>
								</dd>
								<dd>
									<a class="title" href="<?php echo U('User/rfid');?>">RFID卡</a>
								</dd>

							</dl>
						</li>
						<li>
							<a class="link" id="it_account" href="<?php echo U('User/account');?>">账户信息</a>
						</li>
						<li>
							<a></a>
						</li>
					</ul>
				</div>

				<div id="op_main">
					<div id="op_title">
						<h3>基本信息 <span class="W_textb">(<span class="redStar">*</span>必须填写项)</span></h3>
					</div>
					<div id="info_box">
						<form method="post" action="<?php echo U('User/updateUserInfo');?>" name="info">
							<table>
								<tbody>
									<tr>
										<th><span class="redStar">*</span>用户名:</th>
										<td><em>Vincent</em><a href="#">修改密码</a></td>
									</tr>
									<tr>
										<th><span class="redStar">*</span>昵称:</th>
										<td>
										<input type="text" name="nickname" alt="nickname" value="小风"/>
										</td>
									</tr>
									<tr>
										<th><span class="redStar">*</span>邮箱:</th>
										<td>
										<input type="text" name="email" alt="email" value="123456@qq.com"/>
										</td>
									</tr>
									<tr>
										<th>手机:</th>
										<td>
										<input type="text" name="phone" alt="phone" value="123456789"/>
										</td>
									</tr>
									<tr>
										<th>所在地:</th>
										<td>
										<input type="text" name="address" alt="address" value="广东省广州市海珠区"/>
										</td>
									</tr>
								</tbody>
							</table>
							<input id="baocun" type="submit" name="baocun"alt="baocun" value="保存">
						</form>
					</div>
				</div>
			</div>

			<div id="footerPage">
				<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<div id="footer">
	<div id="footerLogo">
			<img src="__PUBLIC__/Images/logo_footer.png" alt="REWO">
	</div>
	<div id="footerContent">
		<div id="footerNav">
			<ul>
				<li><a href="<?php echo U('Index/home');?>">主页</a></li>
				<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
				<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
				<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
				<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
			</ul>
		</div>
		<div id="copyright">
		<h3>Copyright @ Wo-rehov co.ltd 2012-2013. All Rights Reserved.</h3>
		</div>
	</div>
</div>
			</div>
		</div>
	</body>
</html>