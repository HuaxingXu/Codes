<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
		<title>App List</title> 
		<link type="text/css" href="app.css" rel="stylesheet">
		<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
		<script src="app.js" type="text/javascript"></script>
		<script src="__PUBLIC__/Js/jquery-1.7.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			 $(document).ready(function () {
			 	$("#loginBtn").click(function() {
			 		var username = $("#username").val();
			 		var password = $("#password").val();

			 		if (username == "") {
			 			$("#input_us").html("<label>输入账号：</label>");
			 			$('<div id="msg" style="float:right;font-weight:bold;color:red"/>').html("用户名不能为空！").appendTo("#input_us").fadeOut(2000); 
						$("#username").focus();
					}
					else if (password == "") {
						$("#input_pw").html("<label>输入密码：</label>");
						$('<div id="msg" style="float:right;font-weight:bold;color:red"/>').html("密码不能为空！").appendTo("#input_pw").fadeOut(2000); 
			 		}
			 		
			 		$.ajax({
						type: "POST",
						url: "<?php echo ($Url['loginUrl']); ?>",
						dataType:"json",
						data:{"username":username,"password":password},
						beforeSend: function() {
							if (!(username == "" || password == "")) {
								$("#input_us").html("<label>输入账号：</label>");
								$('<div id="msg" style="float:right;font-weight:bold;color:red"/>').html("正在登录.....").appendTo("#input_us").fadeOut(5000);
							}
						},
						success: function(json) {
							if (json.status == 200) {
								$("#loginForm").remove() ;
								var div = "<div id='result'><p><strong>"+username+ "</strong>,恭喜你登录成功!</p>";
								$("#loginPanel").append(div);
							}
							else {
								if (!(username == "" || password == "")) {
									$("#input_us").html("<label>输入账号：</label>");
									$('<div id="msg" style="float:right;font-weight:bold;color:red"/>').html("账号/密码错误！").appendTo("#input_us").fadeOut(2000);
								}
							}
						}
					});
			 	});
			 });
 			
		</script>
	</head>
	<body>
		<div id="page">
			<div id="headerPage">
				<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">

<script type="text/javascript">

function clickSearch(){
						if($("#search").val()!="输入关键字"&&$("#search").val()!="")
						{
							var search=$("#search").val();
							$.ajax({
							type: "POST",
							url: "<?php echo ($Url['searchUrl']); ?>",
							dataType:"text",
							data:{"search":search},
							beforeSend: function() {},
							success: function(json) {
							    json=eval('(' + json + ')');
								re_str="";
								if(json!=null)
								{
									now_location=document.location.href;
									now_location_end=now_location.indexOf("index.php");
									if(now_location_end>0)
										now_location=now_location.substr(0,now_location_end);
									for(i=0;i<json.length;i++)
									{
										re_str+="<a href=\""+now_location+"index.php/App/index?id="+json[i].id+"\">";  
										re_str+="<div class=\"app\">";
										re_str+="<div class=\"appImg\">";
										re_str+="<img alt=\""+json[i].name+"\" src=\"__PUBLIC__/Images/AppIcon/YouTube.png\">";
										re_str+="<span class=\"addApp\">添加应用</span>";
										re_str+="</div>";
										re_str+="<div class=\"appContent\">";
										re_str+="<h2 class=\"appName\">"+json[i].name+"</h2>";
										re_str+="<p class=\"description\">"+json[i].info+"</p>";
										re_str+="</div></div></a>";
									}
								}
								 $("#applications").html(re_str);
							}
							});
					
						}
                      }

  $(document).ready(function () {
			 	$("#search").click(function() {
				    if($("#search").val()=="输入关键字")
				    $("#search").val("");
					});
					
				$("#search").blur(function() {
				    if($("#search").val()=="")
				    $("#search").val("输入关键字");
					});
					
				$("#goSearch").click(function() {
				       clickSearch();
					});
			    
			 });
</script>

</head>
<body>
<div id="header">
				<div id="headerContent">
					<div id="logo"></div>
					<ul class="nav">
						<li><a href="<?php echo U('Index/home');?>">主页</a></li>
						<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
						<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
						<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
						<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
					</ul>
					<div id="banner">
						<form method="post" action="<?php echo U('Index/index');?>" name="searchForm"><!-- <?php echo U('Index/search');?>   onkeydown="if(event.keycode==13){clickSearch();};" -->
							<input id="search" class="textBox" type="txt" value="输入关键字" name="search">
							<label>
								<a href="#">高级搜索</a>
							</label>
							<input class="go" id="goSearch" type="button" value="Go" name="go">
						</form>
					</div>
				</div>
			</div>
</body>

			</div>
			<div id="content">
				<div id="displayAreaLeft">
					<div id="loginPanel">
						<h2>用户登录</h2>
						<?php if(($isLogin != true)): ?><form id="loginForm" method="post" action="<?php echo U('User/auth');?>" name="memberLogin">
							<div id="input_us">
								<label>输入账号：</label>
							</div>
							<input id="username" class="txtBox" type="text" name="username">
							<div id ="input_pw">
								<label id=>输入密码：</label>
							</div>
							<input id="password" class="txtBox" type="text" name="password">
							<a href="#">忘记密码?</a>
							<a href="<?php echo U('Signup/signup');?>">注册</a>
							<input id="loginBtn" class="login" type="button" value="login" name="login"/>	
						</form>
						
						<?php else: ?>
						
						<div id='result'><p>已经登录!</p></div>
						<div id='logout'><p>退出登录</p></div><?php endif; ?>
					</div>
				</div>
				<div id="displayAreaCenter">
				   <table>
				   <tr>
				    <td valign='top' align='left'>
						<h1>Our&nbsp;&nbsp;&nbsp;Goal：</h1>
						<h2>Intelligence</h2>
						<p>tmake it easy to the world!</p>
					</td>
					<td valign='top' align='left'>
					  <!--<div style='border-width:1px; border-color:blue;border-style:solid;'>-->
						<font style='color:#0c6ba1'>热门应用</font><br/>
					    <?php if(is_array($hotAppList)): foreach($hotAppList as $key=>$hotApp): ?><div><a href="<?php echo ($hotApp["hotAppDisplayUrl"]); ?>" style="color:#931103;"><?php echo ($hotApp["name"]); ?></a></div><?php endforeach; endif; ?>
					  <!--</div>-->
					</td>
				   </tr>
				   </table>
				</div>
				<div class="clear"></div>
				<div id="chooseApp">
					<div id="categoryBar">
						<div id="catLeft"></div>
						<ul id="chooseCategory">
							<li class="category">
								<a href="#">
									<img title="日常" alt="日常" src="__PUBLIC__/Images/daily_icon.png">
										<span>日常</span>
								</a>
						    </li>
							<li class="category">
								<a href="#">
									<img title="音乐" alt="音乐" src="__PUBLIC__/Images/music_icon.png">
										<span>音乐</span>
								</a>
						   </li>
							<li class="category">
								<a href="#">
									<img title="RSS" alt="RSS"  src="__PUBLIC__/Images/rss_icon.png">
										<span>RSS</span>
								</a>
						   </li>
							<li class="category">
								<a href="#">
									<img title="交友" alt="交友"  src="__PUBLIC__/Images/sns_icon.png">
										<span>交友</span>
								</a>
						   </li>
							<li class="category">
								<a href="#">
									<img title="微博" alt="微博"  src="__PUBLIC__/Images/weibo_icon.png">
										<span>微博</span>
								</a>
						   </li>
						</ul>
						<div id="catRight"></div>
					</div>
					<div id="specificFilters"></div>
					<div id="applications">
						<?php if(is_array($appList)): foreach($appList as $key=>$app): ?><a href="<?php echo ($app["displayUrl"]); ?>">
							<div class="app">
								<div class="appImg">
									<img alt="<?php echo ($app["name"]); ?>" src="<?php echo ($app["image"]); ?>">
									<span class="addApp">添加应用</span>
								</div>
								<div class="appContent">
									<h2 class="appName"><?php echo ($app["name"]); ?></h2>
									<p class="description"><?php echo ($app["info"]); ?></p>
								</div>
							</div>
						</a><?php endforeach; endif; ?>
					</div>
				</div>
			</div>
		<div id="footerPage">
			<head>
<link type="text/css" href="__PUBLIC__/Css/Global/global.css" rel="stylesheet">
</head>
<div id="footer">
	<div id="footerLogo">
			<img src="__PUBLIC__/Images/logo_footer.png" alt="REWO">
	</div>
	<div id="footerContent">
		<div id="footerNav">
			<ul>
				<li><a href="<?php echo U('Index/home');?>">主页</a></li>
				<li><a href="<?php echo U('User/info');?>">用户中心</a></li>
				<li><a href="<?php echo U('Index/index');?>">应用商店</a></li>
				<li><a href="<?php echo U('Static/support');?>">产品支持</a></li>
				<li><a href="<?php echo U('Static/about');?>">关于我们</a></li>
			</ul>
		</div>
		<div id="copyright">
		<h3>Copyright @ Wo-rehov co.ltd 2012-2013. All Rights Reserved.</h3>
		</div>
	</div>
</div>
		</div>
	</body>
</html>