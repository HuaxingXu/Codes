<?php
		echo "aa";
		//$images2 = new Images("file","","","12.png");
		$now_png=getimagesize("../aptana/public_image/user/00/00/00/00/00/3/12.png");//$images2
		$srcWidth2=$now_png["0"];
		$srcHeight2=$now_png["1"];
		echo "!!".$srcWidth2."!!";


?>



