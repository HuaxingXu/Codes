<?php
function makeProductSeriesSelect($now_id,$now_value,$now_func="",$now_class="")
{
	$ProductSeries = new ProductSeriesModel();
	$list=$ProductSeries -> order("series_id asc") -> select();
	$re_str="";
	$re_str.="<select id='".$now_id."' class='".$now_class."' ".$now_func.">";
	for($i=0;$i<sizeof($list);$i++)
	{
		if($list[$i]['series_id']==$now_value)
			$re_str.="<option value='".$list[$i]['series_id']."' selected>".$list[$i]['series_name']."</option>";
		else
			$re_str.="<option value='".$list[$i]['series_id']."'>".$list[$i]['series_name']."</option>";
	}
	$re_str.="</select>";
	return $re_str;
}

function makeProductTypeSelect($now_id,$now_value,$now_func="",$now_class="")
{
	$list=array();
	$list[0]="玩具";
	$list[1]="配件";
	$re_str="";
	$re_str.="<select id='".$now_id."' class='".$now_class."' ".$now_func.">";
	for($i=0;$i<sizeof($list);$i++)
	{
		if($i==$now_value)
			$re_str.="<option value='".$i."' selected>".$list[$i]."</option>";
		else
			$re_str.="<option value='".$i."'>".$list[$i]."</option>";
	}
	$re_str.="</select>";
	return $re_str;
}


function make_app_setstr($length,$n)
{
	$restr="";
	for($p=0;$p<$length;$p++)
	{
		if($p==$n)
			$restr.="1";
		else
			$restr.="0";
	}
	return $restr;
}

function MakeUserPath($user_id)
{
   $src_num=100000000000+intval($user_id);
   $re_str=strval($src_num);
   $re_str=substr($re_str,1,strlen($re_str)-1);
   $now_re_str="";
   for($k=0;$k<strlen($re_str);$k=$k+2)
   {
		$now_re_str.=substr($re_str,$k,2)."/";
   }
   return $now_re_str;
}