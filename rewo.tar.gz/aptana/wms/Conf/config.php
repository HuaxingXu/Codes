<?php
return array(
    'URL_MODEL'=>1, // 如果你的环境不支持PATHINFO 请设置为3
    'DB_TYPE'=>'mysql',
    'DB_HOST'=>'localhost',
    'DB_NAME'=>'think_rewo',
    'DB_USER'=>'root',  //用户名
    'DB_PWD'=>'',  //密码
    'DB_PORT'=>'3306',
    'DB_PREFIX'=>'rewo_',
	'APP_AUTOLOAD_PATH' => '@.Tool'//自动加载路径
);
?>