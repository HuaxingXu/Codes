<?php
require_once("uploadClass/uploadFunction.php");//引入php上传图片类

class AppAction extends Action {

	public function app() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$App = new AppModel();
		$list=$App -> order("id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['id'])+1);
		$this -> assign('AppList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("App:app");
	}
	
	public function dealApp() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["operation"])&&isset($_REQUEST["id"])&&isset($_REQUEST["name"])&&isset($_REQUEST["category"])
		&&isset($_REQUEST["category_dir"])&&isset($_REQUEST["app_dir"])&&isset($_REQUEST["image"])&&isset($_REQUEST["client"])
		&&isset($_REQUEST["brief"])&&isset($_REQUEST["info"])&&isset($_REQUEST["price"])&&isset($_REQUEST["time"])&&isset($_REQUEST["new_flag"])&&isset($_REQUEST["recommen_level"])&&isset($_REQUEST["speech_command"])&&isset($_REQUEST["rfid_card"])&&isset($_REQUEST["setting"])&&isset($_REQUEST["introduce_word"])&&isset($_REQUEST["config_care"])&&isset($_REQUEST["allow_multi_set"]))
		{
			$operation=$_REQUEST["operation"];
			$id=intval($_REQUEST["id"]);
			$name=$_REQUEST["name"];
			$category=$_REQUEST["category"];
			$category_dir=$_REQUEST["category_dir"];
			$app_dir=$_REQUEST["app_dir"];
			$image=$_REQUEST["image"];
			$client=$_REQUEST["client"];
			$brief=$_REQUEST["brief"];
			$info=$_REQUEST["info"];
			$price=$_REQUEST["price"];
			$time=$_REQUEST["time"];
			$new_flag=$_REQUEST["new_flag"];
			$recommen_level=$_REQUEST["recommen_level"];
			$speech_command=$_REQUEST["speech_command"];
			$rfid_card=$_REQUEST["rfid_card"];
			$config_care=$_REQUEST["config_care"];
			$setting=$_REQUEST["setting"];
			$introduce_word=$_REQUEST["introduce_word"];
			$allow_multi_set=$_REQUEST["allow_multi_set"];
			
			$App = new AppModel();
			
			if($operation=="add")
			{
				$data=array();
				$data['id']=$id;
				$data['name']=$name;
				$data['category']=$category;
				$data['category_dir']=$category_dir;
				$data['app_dir']=$app_dir;
				$data['image']=$image;
				$data['client']=$client;
				$data['brief']=$brief;
				$data['info']=$info;
				$data['price']=$price;
				$data['time']=strtotime($time);
				$data['new_flag']=$new_flag;
				$data['recommen_level']=$recommen_level;
				$data['speech_command']=$speech_command;
				$data['rfid_card']=$rfid_card;
				$data['config_care']=$config_care;
				//$data['setting']=$setting;
				$data['introduce_word']=$introduce_word;
				$data['allow_multi_set']=$allow_multi_set;
				
				$result=$App-> add($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="增加失败！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['name']=$name;
				$data['category']=$category;
				$data['category_dir']=$category_dir;
				$data['app_dir']=$app_dir;
				$data['image']=$image;
				$data['client']=$client;
				$data['brief']=$brief;
				$data['info']=$info;
				$data['price']=$price;
				$data['time']=strtotime($time);
				$data['new_flag']=$new_flag;
				$data['recommen_level']=$recommen_level;
				$data['speech_command']=$speech_command;
				$data['rfid_card']=$rfid_card;
				$data['config_care']=$config_care;
				//$data['setting']=$setting;
				$data['introduce_word']=$introduce_word;
				$data['allow_multi_set']=$allow_multi_set;
				
				$result=$App-> where("id=".$id) -> save($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$App-> where("id=".$id) -> delete();
				if($result)
				{
					$return_arr["state"]=1;
					$UserApp = new UserAppModel();
				$result=$UserApp-> where("app_id=".$id) -> delete();
				}
				else
					$return_arr["desc"]="删除失败！";
					
				
			}
			
		}
		echo json_encode($return_arr);
	}
	
	function uploadFormZipFile()
	{
		if (!$_SESSION['userManager']) {//未登陆则跳转到登陆页面
			$this -> display("Login:login");
			return NULL;
		}
		
		if(isset($_REQUEST["id"]))
		{
			$app_id=$_REQUEST["id"];
			if(isset($_REQUEST["path_dir_".$app_id]))
			{
				$now_path=$_REQUEST["path_dir_".$app_id];
				$now_name="file_".$app_id;
				$re_str=uploadZip($now_name,$now_path);
				$this->app();
				$add_script="";
				if($re_str!="没有文件被上传")
					$add_script="broadcastGetClientFile(__ROOT__,'".$app_id."');";
				echo "<script>alert('".$re_str."');".$add_script."</script>";
			}
		
		}
	}
	
	function appOpenWin()
	{
		if (!$_SESSION['userManager']) {//未登陆则跳转到登陆页面
			$this -> display("Login:login");
			return NULL;
		}
		if(isset($_REQUEST["app_id"]))
		{
			$app_id=$_REQUEST["app_id"];
			$App = new AppModel();
			$list=$App -> where("id=".$app_id) -> find();
			$this -> assign('AppSet', $list);
			
			$type="";
			if(isset($_REQUEST["type"]))
				$type=$_REQUEST["type"];		
			$this -> assign('type', $type);
		}
		$this -> display("App:appOpenWin");
	}
	
	function appOpenWinMin()
	{
		if (!$_SESSION['userManager']) {//未登陆则跳转到登陆页面
			$this -> display("Login:login");
			return NULL;
		}
		if(isset($_REQUEST["app_id"]))
		{
			$app_id=$_REQUEST["app_id"];
			$App = new AppModel();
			$list=$App -> where("id=".$app_id) -> find();
			$this -> assign('AppSet', $list);
			
			$rewo_type="";
			if(isset($_REQUEST["rewo_type"]))
				$rewo_type=$_REQUEST["rewo_type"];
			$this -> assign('rewo_type', $rewo_type);
		}
		$this -> display("App:appOpenWinMin");
	}
	
	public function saveAppSet() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["setting_str"])&&isset($_SESSION["userManager"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["type"]))
		{   
			$setting_str=$_REQUEST["setting_str"];
			$app_id=$_REQUEST["app_id"];
			$type=$_REQUEST["type"];
			
			$set_field="setting";
			if($type=="rewo")
				$set_field="rewo_setting";
			
			$settng_make=array();
			$setting_str = explode("--",$setting_str);
			for($k=0;$k<sizeof($setting_str);$k++)
			{
				$setting_str2 = explode("||",$setting_str[$k]);
				$settng_arr[$setting_str2[0]]=$setting_str2[1];
		   	}
			$setting_str=json_encode($settng_arr);
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			$new_setting=json_decode($setting_str);
			
			for($n=0;$n<sizeof($src_setting);$n++)
       			{
				$now_name=$src_setting[$n]->Name;
				$src_setting[$n]->Default=$new_setting->$now_name;
			}
			
			  $data=array();
			  $data[$set_field]=json_encode($src_setting);
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
			}
			else
				$return_arr["desc"]="保存失败，信息没有修改";
		}
		echo json_encode($return_arr);
	}
	
	
	public function deleteAppSet() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["set_name"])&&isset($_SESSION["userManager"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["type"]))
		{   
			$set_name=$_REQUEST["set_name"];
			$app_id=$_REQUEST["app_id"];
			$type=$_REQUEST["type"];
			
			$set_field="setting";
			if($type=="rewo")
				$set_field="rewo_setting";
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			
			$del_num=-1;
			for($n=0;$n<sizeof($src_setting);$n++)
       		{
				if($src_setting[$n]->Name==$set_name)
				{
				  unset($src_setting[$n]);
				  $del_num=$n;
				}
			}
			
			  $data=array();
			  
			  $make_str="";
			  if(sizeof($src_setting)>0)
			  	$make_str="[";
			  for($k=0;$k<=sizeof($src_setting);$k++)
			  {
			    if($k!=$del_num)
			  		$make_str.=json_encode($src_setting[$k]).",";
			  }
			  if(sizeof($src_setting)>0)
			  {
			  	$make_str=substr($make_str,0,strlen($make_str)-1);
			  	$make_str.="]";
			  }
			  
			  $data[$set_field]=$make_str;//json_encode($src_setting)
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
				
				
				if($type!="rewo")
				{
				$list=$App->table("rewo_user_app") -> where("app_id=".$app_id) -> select();
				
				for($k=0;$k<sizeof($list);$k++)
				{
					$src_setting=json_decode($list[$k]["setting"]);
			
					for($n=0;$n<sizeof($src_setting);$n++)
       				{
						if(isset($src_setting->$set_name))
				  			unset($src_setting->$set_name);
					}
			
			  		$data=array();
			  		$data["setting"]=json_encode($src_setting);
			  		$result=$App->table("rewo_user_app")-> where("app_id=".$app_id." and user_id=".$list[$k]["user_id"]) -> save($data);
				}
				}
				
			}
			else
				$return_arr["desc"]="删除失败";
				
			
			
	
				
		}
		echo json_encode($return_arr);
	}
	
	
	public function addAppSetInput() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["input_name"])&&isset($_REQUEST["input_default"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["rewo_type"]))
		{   
			$input_name=$_REQUEST["input_name"];
			$input_default=$_REQUEST["input_default"];
			$app_id=$_REQUEST["app_id"];
			$rewo_type=$_REQUEST["rewo_type"];
			
			$set_field="setting";
			if($rewo_type=="rewo")
				$set_field="rewo_setting";
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			
			$src_setting[sizeof($src_setting)]=json_decode("{\"Name\":\"".$input_name."\",\"Category\":\"EditText\",\"Default\":\"".$input_default."\",\"Candidate\":[]}");
			
			  $data=array();
			  $data[$set_field]=json_encode($src_setting);
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
				
				if($rewo_type!="rewo")
				{
				$list=$App->table("rewo_user_app") -> where("app_id=".$app_id) -> select();
				
				for($k=0;$k<sizeof($list);$k++)
				{
					$src_setting=json_decode($list[$k]["setting"]);
					$src_setting->$input_name=$input_default;
			
			  		$data=array();
			  		$data["setting"]=json_encode($src_setting);
			  		$result=$App->table("rewo_user_app")-> where("app_id=".$app_id." and user_id=".$list[$k]["user_id"]) -> save($data);
				}
				}	
				
			}
			else
				$return_arr["desc"]="提交失败";
				
			
			
		}
		echo json_encode($return_arr);
	}
	
	public function addAppSetURL() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["input_name"])&&isset($_REQUEST["input_default"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["rewo_type"]))
		{   
			$input_name=$_REQUEST["input_name"];
			$input_default=$_REQUEST["input_default"];
			$app_id=$_REQUEST["app_id"];
			$rewo_type=$_REQUEST["rewo_type"];
			
			$set_field="setting";
			if($rewo_type=="rewo")
				$set_field="rewo_setting";
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			
			$src_setting[sizeof($src_setting)]=json_decode("{\"Name\":\"".$input_name."\",\"Category\":\"URL\",\"Default\":\"".$input_default."\",\"Candidate\":[]}");
			
			  $data=array();
			  $data[$set_field]=json_encode($src_setting);
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
				
				if($rewo_type!="rewo")
				{
				$list=$App->table("rewo_user_app") -> where("app_id=".$app_id) -> select();
				
				for($k=0;$k<sizeof($list);$k++)
				{
					$src_setting=json_decode($list[$k]["setting"]);
					$src_setting->$input_name=$input_default;
			
			  		$data=array();
			  		$data["setting"]=json_encode($src_setting);
			  		$result=$App->table("rewo_user_app")-> where("app_id=".$app_id." and user_id=".$list[$k]["user_id"]) -> save($data);
				}
				}	
				
			}
			else
				$return_arr["desc"]="提交失败";
				
			
			
		}
		echo json_encode($return_arr);
	}
	
	public function addAppSetRadio() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["radio_name"])&&isset($_REQUEST["value_str"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["rewo_type"]))
		{   
			$radio_name=$_REQUEST["radio_name"];
			$value_str=$_REQUEST["value_str"];
			
			
			
			$app_id=$_REQUEST["app_id"];
			$rewo_type=$_REQUEST["rewo_type"];
			
			$set_field="setting";
			if($rewo_type=="rewo")
				$set_field="rewo_setting";
			
			$value_str_num=sizeof(explode(",",$_REQUEST["value_str"]));
			$default=1;
			for($k=0;$k<$value_str_num-1;$k++)
				$default*=10;
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			
			$value_str=str_replace("\\","",$value_str);
			$src_setting[sizeof($src_setting)]=json_decode("{\"Name\":\"".$radio_name."\",\"Category\":\"RadioGroup\",\"Default\":\"".$default."\",\"Candidate\":[".$value_str."]}");
			
			
			  $data=array();
			  $data[$set_field]=json_encode($src_setting);
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
				
				if($rewo_type!="rewo")
				{
				$list=$App->table("rewo_user_app") -> where("app_id=".$app_id) -> select();
				
				for($k=0;$k<sizeof($list);$k++)
				{
					$src_setting=json_decode($list[$k]["setting"]);
					$src_setting->$radio_name=$default;
			
			  		$data=array();
			  		$data["setting"]=json_encode($src_setting);
			  		$result=$App->table("rewo_user_app")-> where("app_id=".$app_id." and user_id=".$list[$k]["user_id"]) -> save($data);
				}
				}	
				
			}
			else
				$return_arr["desc"]="提交失败";
				
				
			
			
		}
		echo json_encode($return_arr);//"提交失败";
	}
	
	
	public function addAppSetCheckBox() {
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["checkbox_name"])&&isset($_REQUEST["value_str"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["rewo_type"]))
		{   
			$checkbox_name=$_REQUEST["checkbox_name"];
			$value_str=$_REQUEST["value_str"];
			$app_id=$_REQUEST["app_id"];
			$rewo_type=$_REQUEST["rewo_type"];
			
			$set_field="setting";
			if($rewo_type=="rewo")
				$set_field="rewo_setting";
			
			$value_str_num=sizeof(explode(",",$_REQUEST["value_str"]));
			$default=1;
			for($k=0;$k<$value_str_num-1;$k++)
				$default*=10;
			
			//验证格式
			$App = new AppModel();
			
			$list=$App -> where("id=".$app_id) -> find();
			$src_setting=json_decode($list[$set_field]);
			
			$value_str=str_replace("\\","",$value_str);
			$src_setting[sizeof($src_setting)]=json_decode("{\"Name\":\"".$checkbox_name."\",\"Category\":\"CheckBox\",\"Default\":\"".$default."\",\"Candidate\":[".$value_str."]}");
			
			  $data=array();
			  $data[$set_field]=json_encode($src_setting);
			  $result=$App-> where("id=".$app_id) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
				
				if($rewo_type!="rewo")
				{
				$list=$App->table("rewo_user_app") -> where("app_id=".$app_id) -> select();
				
				for($k=0;$k<sizeof($list);$k++)
				{
					$src_setting=json_decode($list[$k]["setting"]);
					$src_setting->$checkbox_name=$default;
			
			  		$data=array();
			  		$data["setting"]=json_encode($src_setting);
			  		$result=$App->table("rewo_user_app")-> where("app_id=".$app_id." and user_id=".$list[$k]["user_id"]) -> save($data);
				}
				}	
				
			}
			else
				$return_arr["desc"]="提交失败";
		}
		echo json_encode($return_arr);//"提交失败";
	}
	
	public function broadcastIntroduce()
	{
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		$myNatManager= new NatManager();
		if(isset($_REQUEST["app_name"])&&isset($_REQUEST["app_id"]))
		{
			if($myNatManager->broadcastNewApp($_REQUEST["app_id"]))
			{
				$return_arr["state"]=1;
			}else{
				$return_arr["desc"]="广播失败";
			}
		}
		echo json_encode($return_arr);
	}
	
}
