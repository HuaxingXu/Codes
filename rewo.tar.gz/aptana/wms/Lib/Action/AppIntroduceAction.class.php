<?php

class AppIntroduceAction extends Action {

	public function appIntroduce() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$AppIntroduce = new AppIntroduceModel();
		$list=$AppIntroduce -> order("id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['id'])+1);
		$this -> assign('AppIntroduceList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("App:appIntroduce");
	}
	
	public function dealAppIntroduce() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["operation"])&&isset($_REQUEST["id"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["title"])&&isset($_REQUEST["content"])&&isset($_REQUEST["image"]))
		{
			$operation=$_REQUEST["operation"];
			$id=intval($_REQUEST["id"]);
			$app_id=$_REQUEST["app_id"];
			$content=$_REQUEST["content"];
			$image=$_REQUEST["image"];
			$title=$_REQUEST["title"];
			
			$AppIntroduce = new AppIntroduceModel();
			$App =new AppModel();
			$is_exist_app_id=1;
			$Applist=$App->where("id=".$app_id)->select();	
			if(sizeof($Applist)<=0)
					$is_exist_app_id=0;	

			if($operation=="add")
			{
				$data=array();
				$data['id']=$id;
				$data['app_id']=$app_id;
				$data['title']=$title;
				$data['content']=$content;
				$data['image']=$image;
				if($is_exist_app_id==1)
				{
					$result=$AppIntroduce-> add($data);
					if($result)
						$return_arr["state"]=1;
					else
						$return_arr["desc"]="增加失败！";
				}else
					$return_arr["desc"]="应用编号不存在！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['app_id']=$app_id;
				$data['title']=$title;
				$data['content']=$content;
				$data['image']=$image;
				
				if($is_exist_app_id==1)
				{
					$result=$AppIntroduce-> where("id=".$id) -> save($data);
					if($result)
						$return_arr["state"]=1;
					else
						$return_arr["desc"]="内容没有改动，修改失败！";
				}else
					$return_arr["desc"]="应用编号不存在！";
			}else if($operation=="del")
			{
				$result=$AppIntroduce-> where("id=".$id) -> delete();
				if($result)
				{
					$return_arr["state"]=1;
				}
				else
					$return_arr["desc"]="删除失败！";
					
			}
			
		}
		echo json_encode($return_arr);
	}
	
	
}
