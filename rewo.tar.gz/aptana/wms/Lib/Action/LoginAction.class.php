<?php

class LoginAction extends Action {

	public function login() {
	session_start();
	$return_arr=array();
	$return_arr["state"]=0;
	$return_arr["desc"]="";
	
		if(isset($_REQUEST["username"])&&isset($_REQUEST["password"]))
		{
			$username=$_REQUEST["username"];
			$password=$_REQUEST["password"];
			if($username==""||$password=="")
			{
				$return_arr["state"]=0;
				$return_arr["desc"]="用户名或密码错误！";
			}
			else
			{
				$Manager = new ManagerModel();
				$list = $Manager -> where("username='".$username."'") -> field("username") -> select();
				if(sizeof($list)<=0)
				{
					$return_arr["state"]=0;
					$return_arr["desc"]="用户名不存在！";
				}
				else
				{
					$list = $Manager -> where("username='".$username."' and password='".md5($password)."'") -> field("username") -> select();
					if(sizeof($list)>0)
					{
						$return_arr["state"]=1;
						$return_arr["desc"]="";
						$_SESSION["userManager"]=$username;
					}
					else
					{
						$return_arr["state"]=0;
						$return_arr["desc"]="密码错误！";
					}
				}
			}
		}
		echo json_encode($return_arr);
	}
	
	public function loginDisplay() {
			$this -> display("Login:login");
	}
	
	public function logout() {
			if(isset($_SESSION["userManager"]))
			{
				session('[destroy]');
				$this -> display("Login:login");
			}
	}

}
