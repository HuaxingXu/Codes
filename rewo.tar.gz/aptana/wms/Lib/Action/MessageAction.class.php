<?php

class MessageAction extends Action {

	public function message() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$Message = new MessageModel();
		$list=$Message -> order("user_id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('MessageList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("Other:message");
	}
	
	public function dealMessage() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["operation"])&&isset($_REQUEST["user_id"])&&isset($_REQUEST["content"]))
		{
			$operation=$_REQUEST["operation"];
			$user_id=intval($_REQUEST["user_id"]);
			$content=$_REQUEST["content"];
			
			$Message = new MessageModel();
				
			if($operation=="del")
			{
				$result=$Message-> where("user_id=".$user_id." and content='".$content."'") -> delete();
				if($result)
				{
					$return_arr["state"]=1;
				}
				else
					$return_arr["desc"]="删除失败！";
					
			}
			
		}
		echo json_encode($return_arr);
	}
	
	
}
