<?php

class ProductAction extends Action {

	public function product() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$Product = new ProductModel();
		$list=$Product -> order("product_id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
			$list[$i]['productSeriesSelect']=makeProductSeriesSelect("series_id_".$list[$i]['product_id'],$list[$i]['series_id']);
			$list[$i]['productTypeSelect']=makeProductTypeSelect("product_type_".$list[$i]['product_id'],$list[$i]['product_type']);
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['product_id'])+1);
		$this -> assign('productList', $list);
				
		$productSeriesStr=makeProductSeriesSelect("series_id","");
		$this -> assign('productSeriesSelect', $productSeriesStr);
		$productTypeStr=makeProductTypeSelect("product_type","");
		$this -> assign('productTypeSelect', $productTypeStr);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("Product:product");
	}
	
	public function dealProduct() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["product_id"])&&isset($_REQUEST["series_id"])&&isset($_REQUEST["product_type"])&&isset($_REQUEST["product_name"])
		&&isset($_REQUEST["price"])&&isset($_REQUEST["info"])&&isset($_REQUEST["image"])&&isset($_REQUEST["produce_time"])
		&&isset($_REQUEST["sell_url"])&&isset($_REQUEST["operation"])&&isset($_REQUEST["sequence_num"])&&isset($_REQUEST["new_flag"]))
		{
			$operation=$_REQUEST["operation"];
			$product_id=intval($_REQUEST["product_id"]);
			$series_id=intval($_REQUEST["series_id"]);
			$product_type=intval($_REQUEST["product_type"]);
			$product_name=$_REQUEST["product_name"];
			$price=$_REQUEST["price"];
			$info=$_REQUEST["info"];
			$image=$_REQUEST["image"];
			$produce_time=$_REQUEST["produce_time"];
			$sell_url=$_REQUEST["sell_url"];
			$sequence_num=$_REQUEST["sequence_num"];
			$new_flag=$_REQUEST["new_flag"];
			
			$Product = new ProductModel();
			
			if($operation=="add")
			{
				$data=array();
				$data['product_id']=$product_id;
				$data['series_id']=$series_id;
				$data['product_type']=$product_type;
				$data['product_name']=$product_name;
				$data['price']=$price;
				$data['info']=$info;
				$data['image']=$image;
				$data['produce_time']=$produce_time;
				$data['sell_url']=$sell_url;
				$data['sequence_num']=$sequence_num;
				$data['new_flag']=$new_flag;
				
				$result=$Product-> add($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="增加失败！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['series_id']=$series_id;
				$data['product_type']=$product_type;
				$data['product_name']=$product_name;
				$data['price']=$price;
				$data['info']=$info;
				$data['image']=$image;
				$data['produce_time']=$produce_time;
				$data['sell_url']=$sell_url;
				$data['sequence_num']=$sequence_num;
				$data['new_flag']=$new_flag;

				$result=$Product-> where("product_id=".$product_id) -> save($data);
				if($result)
				{
					$return_arr["state"]=1;
					$data=array();
					$data["product_id"]=$sequence_num;
					$Product->table("rewo_user_product")->where("product_id=".$_REQUEST["old_sequence_num"]) -> save($data);
				}
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$Product-> where("product_id=".$product_id) -> delete();
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="删除失败！";
			}
			
		}
		echo json_encode($return_arr);
	}
	
}
