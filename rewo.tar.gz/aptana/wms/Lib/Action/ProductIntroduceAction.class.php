<?php

class ProductIntroduceAction extends Action {

	public function productIntroduce() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$ProductIntroduce = new ProductIntroduceModel();
		$list=$ProductIntroduce -> order("id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
			$list[$i]['productSeriesSelect']=makeProductSeriesSelect("series_id_".$list[$i]['id'],$list[$i]['series_id']);
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['id'])+1);

		$productSeriesStr=makeProductSeriesSelect("series_id","");
		$this -> assign('productSeriesSelect', $productSeriesStr);

		$this -> assign('productIntroduceList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("Product:productIntroduce");
	}
	
	public function dealProductIntroduce() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["id"])&&isset($_REQUEST["operation"])&&isset($_REQUEST["series_id"])&&isset($_REQUEST["title"])&&isset($_REQUEST["content"])&&isset($_REQUEST["coin"])&&isset($_REQUEST["image"]))
		{
			$operation=$_REQUEST["operation"];
			$id=intval($_REQUEST["id"]);
			$series_id=intval($_REQUEST["series_id"]);
			$title=$_REQUEST["title"];
			$content=$_REQUEST["content"];
			$coin=$_REQUEST["coin"];
			$image=$_REQUEST["image"];
			
			$ProductIntroduce = new ProductIntroduceModel();
			
			if($operation=="add")
			{
				$data=array();
				$data['id']=$id;
				$data['series_id']=$series_id;
				$data['title']=$title;
				$data['content']=$content;
				$data['coin']=$coin;
				$data['image']=$image;
				
				$result=$ProductIntroduce-> add($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="增加失败！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['series_id']=$series_id;
				$data['title']=$title;
				$data['content']=$content;
				$data['coin']=$coin;
				$data['image']=$image;

				$result=$ProductIntroduce-> where("id=".$id) -> save($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$ProductIntroduce-> where("id=".$id) -> delete();
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="删除失败！";
			}
			
		}
		echo json_encode($return_arr);
	}
	
}
