<?php

class ProductSeriesAction extends Action {

	public function productSeries() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$ProductSeries = new ProductSeriesModel();
		$list=$ProductSeries-> order("series_id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['series_id'])+1);
		$this -> assign('productSeriesList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("Index:index");
	}
	
	public function dealProductSeries() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["series_id"])&&isset($_REQUEST["series_name"])&&isset($_REQUEST["info"])&&isset($_REQUEST["operation"]))
		{
			$operation=$_REQUEST["operation"];
			$series_id=intval($_REQUEST["series_id"]);
			$series_name=$_REQUEST["series_name"];
			$info=$_REQUEST["info"];
			
			$ProductSeries = new ProductSeriesModel();
			
			if($operation=="add")
			{
				$data=array();
				$data['series_id']=$series_id;
				$data['series_name']=$series_name;
				$data['info']=$info;
				$result=$ProductSeries-> add($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="增加失败！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['series_name']=$series_name;
				$data['info']=$info;
				$result=$ProductSeries-> where("series_id=".$series_id) -> save($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$ProductSeries-> where("series_id=".$series_id) -> delete();
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="删除失败！";
			}
			
		}
		echo json_encode($return_arr);
	}
	
}
