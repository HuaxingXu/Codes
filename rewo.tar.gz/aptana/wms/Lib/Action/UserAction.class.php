<?php

class UserAction extends Action {

	public function user() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$User = new UserModel();
		$list=$User -> order("id asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('nowid', intval($list[sizeof($list)-1]['id'])+1);
		$this -> assign('userList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("User:user");
	}
	
public function dealUser() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["operation"])&&isset($_REQUEST["id"])&&isset($_REQUEST["username"])&&isset($_REQUEST["password"])
		&&isset($_REQUEST["email"])&&isset($_REQUEST["encode"])&&isset($_REQUEST["nickname"])&&isset($_REQUEST["sex"])
		&&isset($_REQUEST["balance"])&&isset($_REQUEST["flag"])&&isset($_REQUEST["getpwdlink_str"])&&isset($_REQUEST["getpwdlink_time"])&&isset($_REQUEST["signature"])&&isset($_REQUEST["age"])&&isset($_REQUEST["location"])&&isset($_REQUEST["constellation"])&&isset($_REQUEST["last_login_time"]))
		{
			$operation=$_REQUEST["operation"];
			$id=intval($_REQUEST["id"]);
			$username=$_REQUEST["username"];
			$password=$_REQUEST["password"];
			$email=$_REQUEST["email"];
			$encode=$_REQUEST["encode"];
			$nickname=$_REQUEST["nickname"];
			$sex=$_REQUEST["sex"];
			$balance=$_REQUEST["balance"];
			$flag=$_REQUEST["flag"];
			$getpwdlink_str=$_REQUEST["getpwdlink_str"];
			$getpwdlink_time=$_REQUEST["getpwdlink_time"];
			$signature=$_REQUEST["signature"];
			$age=$_REQUEST["age"];
			$location=$_REQUEST["location"];
			$constellation=$_REQUEST["constellation"];
			$last_login_time=$_REQUEST["last_login_time"];
			
			
			$User = new UserModel();
			
			if($operation=="add")
			{
				$data=array();
				$data['id']=$id;
				$data['username']=$username;
				$data['password']=$password;
				$data['email']=$email;
				$data['encode']=$encode;
				$data['nickname']=$nickname;
				$data['sex']=$sex;
				$data['balance']=$balance;
				$data['flag']=$flag;
				$data['getpwdlink_str']=$getpwdlink_str;
				$data['getpwdlink_time']=$getpwdlink_time;
				$data['signature']=$signature;
				$data['age']=$age;
				$data['location']=$location;
				$data['constellation']=$constellation;
				$data['last_login_time']=$last_login_time;
				
				$result=$User-> add($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="增加失败！";
			}else if($operation=="mod")
			{
				$data=array();
				$data['username']=$username;
				$data['password']=$password;
				$data['email']=$email;
				$data['encode']=$encode;
				$data['nickname']=$nickname;
				$data['sex']=$sex;
				$data['balance']=$balance;
				$data['flag']=$flag;
				$data['getpwdlink_str']=$getpwdlink_str;
				$data['getpwdlink_time']=$getpwdlink_time;
				$data['signature']=$signature;
				$data['age']=$age;
				$data['location']=$location;
				$data['constellation']=$constellation;
				$data['last_login_time']=$last_login_time;
				
				$result=$User-> where("id=".$id) -> save($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$User-> where("id=".$id) -> delete();
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="删除失败！";
					
				$UserApp = new UserAppModel();
				$result=$UserApp-> where("user_id=".$id) -> delete();
			}
			
		}
		echo json_encode($return_arr);
	}
	
}
