<?php

class UserAppAction extends Action {

	public function userApp() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$UserApp = new UserAppModel();
		$list=$UserApp -> order("user_id,app_id,set_file_num asc") -> select();
		for($i=0;$i<sizeof($list);$i++) {
			$list[$i]['bgColor'] ="#ffffff";
			if($i%2==0)
				$list[$i]['bgColor'] ="#f6f6f6";
		}
		$this -> assign('userAppList', $list);
		
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("User:userApp");
	}
	
public function dealUserApp() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		if(isset($_REQUEST["operation"])&&isset($_REQUEST["user_id"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["setting"])
		&&isset($_REQUEST["word"])&&isset($_REQUEST["flag"])&&isset($_REQUEST["speech_command"])&&isset($_REQUEST["rfid_card"])&&isset($_REQUEST["language_flag"])&&isset($_REQUEST["set_file_num"])&&isset($_REQUEST["set_file_name"]))
		{
			$operation=$_REQUEST["operation"];
			$user_id=intval($_REQUEST["user_id"]);
			$app_id=$_REQUEST["app_id"];
			$setting=$_REQUEST["setting"];
			$word=$_REQUEST["word"];
			$speech_command=$_REQUEST["speech_command"];
			$flag=$_REQUEST["flag"];
			$rfid_card=$_REQUEST["rfid_card"];
			$language_flag=$_REQUEST["language_flag"];
			$set_file_num=$_REQUEST["set_file_num"];
			$set_file_name=$_REQUEST["set_file_name"];
			
			$UserApp = new UserAppModel();
			$User = new UserModel();
			$App = new AppModel();
			
			if($operation=="add")
			{
				
				
			$nowList1=$User-> where("id=".$user_id) -> select();
			$nowList2=$App-> where("id=".$app_id) -> select();
			
			$src_app_setting=$nowList2[0]["setting"];
			$src_app_setting=json_decode($src_app_setting);
			$now_setting_str="{";
			for($m=0;$m<sizeof($src_app_setting);$m++)
			{
				$now_setting_str.="\"".$src_app_setting[$k]->Name."\":\"".$src_app_setting[$k]->Default."\",";
			}
			$now_setting_str=substr($now_setting_str,0,strlen($now_setting_str)-1);
			$now_setting_str.="}";
			
			$data=array();
			$data['user_id']=$user_id;
			$data['app_id']=$app_id;
			$data['setting']=$now_setting_str;
			$data['word']=$word;
			$data['speech_command']=$speech_command;
			$data['flag']=$flag;
			$data['rfid_card']=$rfid_card;
			$data['language_flag']=$language_flag;
			$data['set_file_num']=$set_file_num;
			$data['set_file_name']=$set_file_name;

			if(sizeof($nowList1)>0&&sizeof($nowList2)>0)
			{
				$result=$UserApp-> add($data);
				if($result)
				{
					$return_arr["state"]=1;
					
					$App = new AppModel();
					$list=$App -> where("id=".$app_id) -> find();
					$src_setting=json_decode($list["setting"]);
					$new_setting="{";
					for($k=0;$k<sizeof($src_setting);$k++)
					{
						$new_setting.="\"".$src_setting[$k]->Name."\":\"".$src_setting[$k]->Default."\",";
					}
					if(sizeof($src_setting)>0)
						$new_setting=substr($new_setting,0,strlen($new_setting)-1);
					$new_setting.="}";
					$data=array();
					$data['setting']=$new_setting;
					$App ->table("rewo_user_app")->where("user_id=".$user_id." and app_id=".$app_id)->save($data);
				}
				else
					$return_arr["desc"]="增加失败！";
			}else
			{
				$return_arr["desc"]="用户ID或应用ID不存在！";
			}
			
			}else if($operation=="mod")
			{
				$data=array();
				//$data['setting']=$setting;
				$data['word']=$word;
				$data['speech_command']=$speech_command;
				$data['flag']=$flag;
				$data['rfid_card']=$rfid_card;
				$data['language_flag']=$language_flag;
				$data['set_file_num']=$set_file_num;
				$data['set_file_name']=$set_file_name;// add 与 save 两处
				
				$result=$UserApp-> where("user_id=".$user_id." and app_id=".$app_id." and set_file_num=".$set_file_num) -> save($data);
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="内容没有改动，修改失败！";
			}else if($operation=="del")
			{
				$result=$UserApp-> where("user_id=".$user_id." and app_id=".$app_id." and set_file_num=".$set_file_num) -> delete();
				if($result)
					$return_arr["state"]=1;
				else
					$return_arr["desc"]="删除失败！";
			}
			
		}
		echo json_encode($return_arr);
	}
	
	public function userAppOpenWin()
	{
		if (!$_SESSION['userManager']) {//未登陆则跳转到登陆页面
			$this -> display("Login:login");
			return NULL;
		}
		if(isset($_REQUEST["app_id"])&&isset($_REQUEST["user_id"])&&isset($_REQUEST["set_file_num"]))
		{
			$app_id=$_REQUEST["app_id"];
			$user_id=$_REQUEST["user_id"];
			$set_file_num=$_REQUEST["set_file_num"];
			$UserApp = new UserAppModel();
			$list=$UserApp ->table("rewo_app,rewo_user_app")->
			 where("rewo_user_app.app_id=".$app_id." and rewo_user_app.user_id=".$user_id." and rewo_user_app.app_id=rewo_app.id and rewo_user_app.set_file_num=".$set_file_num)
			  ->field("rewo_user_app.*,rewo_app.name,rewo_app.setting as app_setting") -> find();
			$this -> assign('UserAppSet', $list);
		}
		$this -> display("User:userAppOpenWin");
	}
	
    public function saveUserAppSet()
	{
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if(!isset($_SESSION["userManager"]))
		{
			$return_arr["desc"]="请先登录";
		}
		
		if(isset($_REQUEST["setting_str"])&&isset($_SESSION["userManager"])&&isset($_REQUEST["app_id"])&&isset($_REQUEST["user_id"])&&isset($_REQUEST["set_file_num"]))
		{   
			$setting_str=$_REQUEST["setting_str"];
			$app_id=$_REQUEST["app_id"];
			$user_id=$_REQUEST["user_id"];
			$set_file_num=$_REQUEST["set_file_num"];
			
			$settng_make=array();
			$setting_str = explode("-",$setting_str);
			for($k=0;$k<sizeof($setting_str);$k++)
			{
				$setting_str2 = explode(":",$setting_str[$k]);
				$settng_arr[$setting_str2[0]]=$setting_str2[1];
		    }
			$setting_str=json_encode($settng_arr);
			
			//验证格式
			$UserApp = new UserAppModel();
			
			  $data=array();
			  $data['setting']=$setting_str;
			  $result=$UserApp-> where("app_id=".$app_id." and user_id=".$user_id." and set_file_num=".$set_file_num) -> save($data);

			if($result)
			{
				$return_arr["state"]=1;
			}
			else
				$return_arr["desc"]="保存失败，信息没有修改";
		}
		echo json_encode($return_arr);
	}
	
}
