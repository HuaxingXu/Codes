<?php

/**
 */
class UserProductAction extends Action {

	public function add() {
		//检查是否传参正确
		if (!isset($_REQUEST['robot_id'])) {
			$this -> ajaxReturn(0, 'no robot id', 400);
		}
		if (!isset($_SESSION['id'])) {
			$this -> ajaxReturn(0, 'no user id', 400);
		}
		$user_id = $_SESSION['id'];
		$robot_id = $_REQUEST['robot_id'];
		//检查数据库中，用户和机器人是否存在
		$User = M('user');
		if (! $User -> find($user_id)) {
			$this -> ajaxReturn(0, 'user does not exist', 401);
		}
		$Product = M('Product');
		if (! $Product -> find($robot_id)) {
			$this -> ajaxReturn(0, 'robot does not exist', 401);
		}
		//检查用户和机器人的唯一性，每个用户只对应一个机器人
		$UserProduct = new UserProductModel();
		if ($UserProduct -> where("user_id=$user_id") -> find()) {
			$this -> ajaxReturn(0, 'each user can only bind one robot', 402);
		}
		if ($UserProduct -> where("product_id=$robot_id") -> find()) {
			$this -> ajaxReturn(0, 'each robot can only be binded by one user', 402);
		}
		//绑定操作
		$condition = array();
		$condition['user_id'] = $user_id;
		$condition['product_id'] = $robot_id;
		
		$saveResult = $UserProduct -> add($condition);
		if ($saveResult === FALSE) {
			$this -> ajaxReturn(0, 'false', 503);
		} else if ($saveResult <= 0) {
			$this -> ajaxReturn(0, 'null', 404);
		} else {
			$this -> ajaxReturn(0, 'success', 200);
		}
	}
	
	public function userProduct() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$UserProduct = M('user_product');
		$list = $UserProduct -> order("user_id, product_id asc") -> select();
		for ($i = 0; $i < sizeof($list); ++ $i) {
			$list[$i]['bgColor'] = "#ffffff";
			if($i % 2 == 0) {
				$list[$i]['bgColor'] = "#f6f6f6";
			}
		}
		$this -> assign('userProductList', $list);
		$this -> assign('user',$_SESSION["userManager"]);
		$this -> display("User:userProduct");
	}
	//ajax处理修改和删除操作
	public function dealUserProduct() {
		if(!isset($_SESSION["userManager"])) {
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr=array();
		$return_arr["state"]=0;
		$return_arr["desc"]="";
		
		if (isset($_REQUEST['operation']) && isset($_REQUEST['user_id']) 
				&& isset($_REQUEST['product_id']) && isset($_REQUEST['status'])) {
			$operation = $_REQUEST['operation'];
			$user_id = $_REQUEST['user_id'];
			$product_id = $_REQUEST['product_id'];
			$status = $_REQUEST['status'];
			
			$UserProduct = D('user_product');
			$User = D('user');
			$Product = D('product');
			$Product2 = M('product');
			$Product2List=$Product2 -> where("sequence_num=".$product_id." and sequence_num!=''")->select();
			//添加操作
			if ($operation == "add") {
				if ($User -> find($user_id) && (sizeof($Product2List)>0)//检查用户和产品是否存在
						&& ! $UserProduct -> where("user_id=$user_id") -> find() 
						&& ! $UserProduct -> where("product_id=$product_id") -> find()) {//检查唯一性
					$data = array();
					$data['user_id'] = $user_id;
					$data['product_id'] = $product_id;
					$data['status'] = $status;
					$result = $UserProduct -> add($data);
					if ($result) {
						$return_arr["state"]=1;
					}
					else {
						$return_arr["desc"]="增加失败！";
					}
				} 
				else {
					$return_arr["desc"]="用户不存在 或 产品不存在 或 绑定唯一性不符合！";
				}
			}
			//修改操作
			else if ($operation == "mod") {
				$data = array();
				$data['user_id'] = $user_id;
				$data['product_id'] = $product_id;
				$data['status'] = $status;
				$result = $UserProduct -> where("user_id=".$user_id." and product_id='".$product_id."'") -> save($data);
				if($result) {
					$return_arr["state"]=1;
				}
				else {
					$return_arr["desc"]="内容没有改动，修改失败！";
				}
			}
			//删除操作
			else if ($operation == "del") {
				$result = $UserProduct-> where("user_id=".$user_id." and product_id='".$product_id."'") -> delete();
				if($result) {
					$return_arr["state"]=1;
				}
				else {
					$return_arr["desc"]="删除失败！";
				}
			}
		}
		echo json_encode($return_arr);
	}
	
	
	//向守护进程发送同步用户应用
	public function notifyUpdateAppConfig() {
		if (!$_SESSION['userManager']) {
			exit;
		}
		if(isset($_SESSION['userManager'])&&isset($_REQUEST['app_id'])&&isset($_REQUEST['user_id'])&&isset($_REQUEST['is_new']))
		{
			$nowUser = new UserModel();
			$product_id=$nowUser->table("rewo_user,rewo_user_product")
			->where("rewo_user.id=rewo_user_product.user_id and rewo_user.id='".$_REQUEST['user_id']."'")
			->field("product_id")->select();
			if(sizeof($product_id)>0)
			{
				$myNatManager=new NatManager();
				$myNatManager->notifyUpdateConfig($product_id[0]["product_id"], $_REQUEST['app_id'],$_REQUEST['is_new']);
			}
		}
	}
	
	//向守护进程发送同步公共应用
	public function broadcastNotifyUpdateAppConfig() {
		if (!$_SESSION['userManager']) {
			exit;
		}
		if(isset($_SESSION['userManager'])&&isset($_REQUEST['app_id'])&&isset($_REQUEST['is_new']))
		{
				$myNatManager=new NatManager();
				$myNatManager->broadcastNotifyUpdateConfig($_REQUEST['app_id'],$_REQUEST['is_new']);
		}
	}
	
	//向守护进程发送同步公共应用zip资源
	public function broadcastGetClientFile() {
		if (!$_SESSION['userManager']) {
			exit;
		}
		if(isset($_SESSION['userManager'])&&isset($_REQUEST['app_id']))
		{
				//$myNatManager=new NatManager();
				//$myNatManager->notifyUpdateResource("",$_REQUEST['app_id']);
echo $_REQUEST['app_id'];
		}
	}
	
	//重新生成用户语音命令文件
	public function remakeUserSpeechFile() {

		session_start();
		if(isset($_SESSION['userManager'])&&isset($_REQUEST['user_id']))
		{
			$user_id=$_REQUEST['user_id'];
			$nowUser = new UserModel();
			$user_path="../public_image/user/".MakeUserPath($user_id)."";
			if(!file_exists($user_path)){       
			mkdir($user_path,0777,true);   
			}
			
			$list=$nowUser->table("rewo_user_app")->where("user_id=".$user_id)->field("speech_command")->select();
			
			if(!file_exists($user_path.$user_id."_speech.txt"))
 		    	touch($user_path.$user_id."_speech.txt");
			
			$write_str="";
			for($k=0;$k<sizeof($list);$k++)
				$write_str.=$list[$k]["speech_command"]."\n";
			
			$handle=fopen($user_path.$user_id."_speech.txt",'w');
			fwrite($handle,$write_str);
			fclose($handle);
			
			system("python ../speech_command_python/C2Sphinx.py ".$user_path.$user_id."_speech.txt ".$user_path);
			
			$list=$nowUser->table("rewo_user_product")->where("user_id=".$user_id)->field("product_id")->select();
			if(sizeof($list)>0)
			{
				$myNatManager=new NatManager();
				$myNatManager->getUserSpeechZipFile($list[0]["product_id"]);
			}


		}
	}


	//重新生成用户联系人字典文件
	public function remakeUserFriendsFile() {
		session_start();
		if(isset($_SESSION['userManager'])&&isset($_REQUEST['user_id']))
		{
			$user_id=$_REQUEST['user_id'];
			$nowUser = new UserModel();
			$user_path="../public_image/user/".MakeUserPath($user_id)."";
			if(!file_exists($user_path)){       
			mkdir($user_path,0777,true);   
			}
			
			$list2=$nowUser->table("rewo_user_friends,rewo_user")->where("rewo_user_friends.friends_id=rewo_user.id and rewo_user_friends.user_id=".$user_id." and rewo_user.username!=''")->field("username")->select();
			
			if(!file_exists($user_path.$user_id."_friends.txt"))
 		    	touch($user_path.$user_id."_friends.txt");
			
			$write_str="";
			for($k=0;$k<sizeof($list2);$k++)
				$write_str.=$list2[$k]["username"]."\n";

			
			$handle=fopen($user_path.$user_id."_friends.txt",'w');
			fwrite($handle,$write_str);
			fclose($handle);
			
			system("python ../speech_command_python/C2Sphinx_sp.py ".$user_path.$user_id."_friends.txt ".$user_path);

			$list=$nowUser->table("rewo_user_product")->where("user_id=".$user_id)->field("product_id")->select();
			if(sizeof($list)>0)
			{
				$myNatManager=new NatManager();
				$myNatManager->getUserFriendsZipFile($list[0]["product_id"]);
			}

		}
	}

	
}
