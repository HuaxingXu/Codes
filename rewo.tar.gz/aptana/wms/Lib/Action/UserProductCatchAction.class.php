<?php

class UserProductCatchAction extends Action {
	
	public function userProductCatch() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$UserProduct = M('user_product_catch');
		$list = $UserProduct -> order("user_id, product_id, time asc") -> select();
		for ($i = 0; $i < sizeof($list); ++ $i) {
			$list[$i]['bgColor'] = "#ffffff";
			if($i % 2 == 0) {
				$list[$i]['bgColor'] = "#f6f6f6";
			}
		}
		$this -> assign('userProductCatchList', $list);
		$this -> assign('user',$_SESSION["userManager"]);
		
		$this -> display("User:userProductCatch");
	}
	
	public function dealUserProductCatch() {
		if(!isset($_SESSION["userManager"])) {
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr = array();
		$return_arr["state"] = 0;
		$return_arr["desc"] = "";
		
		if (isset($_REQUEST['operation']) 
				&& isset($_REQUEST['user_id']) && isset($_REQUEST['product_id']) 
				&& isset($_REQUEST['type']) && isset($_REQUEST['content'])
				&& isset($_REQUEST['time'])) {
			
			$id = $_REQUEST['id'];
			$user_id = $_REQUEST['user_id'];
			$product_id = $_REQUEST['product_id'];
			$type = $_REQUEST['type'];
			$content = $_REQUEST['content'];
			$time = $_REQUEST['time'];
			$operation = $_REQUEST['operation'];
			
			$UserProductCatch = D('user_product_catch');
			$User = D('user');
			$Product = D('product');
			//添加操作
			if ($operation == "add") {
				if ($User -> find($user_id) && $Product -> find($product_id)) {
					$data = array();
					$data['user_id'] = $user_id;
					$data['product_id'] = $product_id;
					$data['type'] = $type;
					$data['content'] = $content;
					$data['time'] = $time;
					$result = $UserProductCatch -> add($data);
					if ($result) {
						$return_arr["state"]=1;
					}
					else {
						$return_arr["desc"]="增加失败！";
					}
				}
				else {
					$return_arr["desc"]="用户不存在 或 产品不存在！";
				}
			}
			//修改操作
			else if ($operation == "mod") {
				$data = array();
				$data['user_id'] = $user_id;
					$data['product_id'] = $product_id;
					$data['type'] = $type;
					$data['content'] = $content;
					$data['time'] = $time;
				$result = $UserProductCatch -> where("id='$id' and user_id='$user_id' and product_id='$product_id'") -> save($data);
				if($result) {
					$return_arr["state"] = 1;
				}
				else {
					$return_arr["desc"] = "内容没有改动，修改失败！";
				}
			}
			//删除操作
			else if ($operation == "del") {
				$result = $UserProductCatch -> where("id='$id' and user_id='$user_id' and product_id='$product_id'") -> delete();
				if($result) {
					$return_arr["state"] = 1;
				}
				else {
					$return_arr["desc"] = "删除失败！";
				}
			}
		}
		
		echo json_encode($return_arr);
	}
}