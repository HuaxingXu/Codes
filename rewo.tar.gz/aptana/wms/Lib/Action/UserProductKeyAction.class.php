<?php

class UserProductKeyAction extends Action {
	
	public function userProductKey() {
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$UserProduct = M('user_product_key');
		$list = $UserProduct -> order("time asc") -> select();
		for ($i = 0; $i < sizeof($list); ++ $i) {
			$list[$i]['bgColor'] = "#ffffff";
			if($i % 2 == 0) {
				$list[$i]['bgColor'] = "#f6f6f6";
			}
		}
		$this -> assign('userProductKeyList', $list);
		$this -> assign('user',$_SESSION["userManager"]);
		
		$this -> display("User:userProductKey");
	}
	
	public function dealUserProductKey() {
		
		if(!isset($_SESSION["userManager"]))
		{
			$this -> display("Login:login");
			return NULL;
		}
		
		$return_arr = array();
		$return_arr["state"] = 0;
		$return_arr["desc"] = "";
		
		if (isset($_REQUEST['operation'])
				&& isset($_REQUEST['key_value']) && isset($_REQUEST['time'])) {
				
			$id = $_REQUEST['id'];
			$key_value = $_REQUEST['key_value'];
			$time = $_REQUEST['time'];
			$operation = $_REQUEST['operation'];
			
			$UserProductKey = D("user_product_key");
			//添加操作
			if ($operation == "add") {
				$data = array();
				$data['key_value'] = $key_value;
				$data['time'] = $time;
				
				$result = $UserProductKey -> add($data);
				if ($result) {
					$return_arr["state"] = 1;
				}
				else {
					$return_arr["desc"] = "增加失败！";
				}
			}
			//修改操作
			else if ($operation == "mod") {
				$data = array();
				$data['key_value'] = $key_value;
				$data['time'] = $time;
				
				$result = $UserProductKey -> where("id='$id'") -> save($data);
				if($result) {
					$return_arr["state"] = 1;
				}
				else {
					$return_arr["desc"] = "内容没有改动，修改失败！";
				}
			}
			//删除操作
			else if ($operation == "del") {
				$result = $UserProductKey -> where("id='$id'") -> delete();
				if($result) {
					$return_arr["state"] = 1;
				}
				else {
					$return_arr["desc"] = "删除失败！";
				}
			}
		}
		
		echo json_encode($return_arr);
	}
}