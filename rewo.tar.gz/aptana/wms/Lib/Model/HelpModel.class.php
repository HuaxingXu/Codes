<?php
class HelpModel extends Model {	
	protected $_validate = array();
	protected $_auto = array();
	
}
?>
