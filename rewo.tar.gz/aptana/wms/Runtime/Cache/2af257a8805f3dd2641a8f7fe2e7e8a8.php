<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
        
         <!--[if lte IE 6]>
		<script src="__ROOT__/wms/Script/DD_belatedPNG_0.0.8a.js" type="text/javascript"></script>
    	<script type="text/javascript">
       		 DD_belatedPNG.fix('div, ul, img, li, input , a');
   	    </script>
		<![endif]-->
        
        <link type="text/css" href="__ROOT__/wms/Css/css.css" rel="stylesheet">
		<script src="__ROOT__/wms/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/index.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/app.js" type="text/javascript"></script>
		<title>网站后台管理-应用设置</title> 
	</head>
	<body style="background:none;background-color:#fcfafb;">
    <center>
    
    <table width="100%">
    <tr><td align="center" valign="top">
    
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr><td align="center" valign="middle" height="40" style="background-color:#8a8a8a">
    <font style="font-size:16px; color:#ffffff;"><?php echo ($AppSet["id"]); ?>&nbsp;&nbsp;<?php echo ($AppSet["name"]); ?>&nbsp;&nbsp;的应用设置</font>
    </td></tr>
    <tr><td align="center" valign="middle" height="30" style="background-color:#cecece">
    工具栏:&nbsp;&nbsp;&nbsp;
    <a href="javascript:appSetAddInput('__ROOT__','input','<?php echo ($AppSet["id"]); ?>','<?php echo ($type); ?>')" style="text-decoration:none;">
    <img src="__ROOT__/wms/Image/coin_add.png" style="position:absolute;"/>&nbsp;&nbsp;&nbsp;输入框设置
    </a>
    &nbsp;&nbsp;
    <a href="javascript:appSetAddRadio('__ROOT__','radio','<?php echo ($AppSet["id"]); ?>','<?php echo ($type); ?>')" style="text-decoration:none;">
    <img src="__ROOT__/wms/Image/coin_add.png" style="position:absolute;"/>&nbsp;&nbsp;&nbsp;单选设置
    </a>
    &nbsp;&nbsp;
    <a href="javascript:appSetAddCheckBox('__ROOT__','checkbox','<?php echo ($AppSet["id"]); ?>','<?php echo ($type); ?>')" style="text-decoration:none;">
    <img src="__ROOT__/wms/Image/coin_add.png" style="position:absolute;"/>&nbsp;&nbsp;&nbsp;多选设置
    </a>
    <?php if($type=="rewo"){ ?>
    &nbsp;&nbsp;
    <a href="javascript:appSetAddURL('__ROOT__','url','<?php echo ($AppSet["id"]); ?>','<?php echo ($type); ?>')" style="text-decoration:none;">
    <img src="__ROOT__/wms/Image/coin_add.png" style="position:absolute;"/>&nbsp;&nbsp;&nbsp;URL设置
    </a>
    <?php } ?>
    </td></tr>
    <tr><td align="center" valign="top" id="setting_tb">
    
    
     <?php  $str_name=""; if($type=="rewo") $set_str=json_decode($AppSet["rewo_setting"]); else $set_str=json_decode($AppSet["setting"]); for($k=0;$k<sizeof($set_str);$k++) { ?>
	
    <table border="0" width="50%" cellpadding="0" cellspacing="0">
    <tr><td colspan="3" height="5"></td></tr>
    <tr><td align="right" valign="middle" width="125">
    <?php echo $set_str[$k]->Name; ?>：</td>
    <td align="left" valign="middle">
    <?php if($set_str[$k]->Category=="EditText"){?>
    <input id="<?php echo $set_str[$k]->Name; ?>" type="text" value="<?php echo $set_str[$k]->Default; ?>"/>
    <?php }else if($set_str[$k]->Category=="URL"){?>
    <input id="<?php echo $set_str[$k]->Name; ?>" type="text" value="<?php echo $set_str[$k]->Default; ?>" style="display:inline; width:120px;"/>(URL)
    <?php }else if($set_str[$k]->Category=="RadioGroup") { for($n=0;$n<sizeof($set_str[$k]->Candidate);$n++) { ?>
                                       <?php if(substr($set_str[$k]->Default,$n,1)=="1") { ?>
                                    <input name="<?php echo $set_str[$k]->Name; ?>" type="radio"
                                     value="<?php echo make_app_setstr(strlen($set_str[$k]->Default),$n); ?>" checked="checked" />
                                    	<?php } else { ?>
                                        <input name="<?php echo $set_str[$k]->Name; ?>" type="radio"
                                         value="<?php echo make_app_setstr(strlen($set_str[$k]->Default),$n); ?>" />
                                        <?php } ?>
                                    <?php echo $set_str[$k]->Candidate[$n]; ?>
                                    <?php
 } }else if($set_str[$k]->Category=="CheckBox"){ for($n=0;$n<sizeof($set_str[$k]->Candidate);$n++) { if(substr($set_str[$k]->Default,$n,1)=="1") { ?>
                                    <input name="<?php echo $set_str[$k]->Name; ?>" type="checkbox"
                                     value="<?php echo make_app_setstr(strlen($set_str[$k]->Default),$n); ?>" checked="checked" />
                                    	<?php } else { ?>
                                        <input name="<?php echo $set_str[$k]->Name; ?>" type="checkbox"
                                         value="<?php echo make_app_setstr(strlen($set_str[$k]->Default),$n); ?>" />
                                        <?php } echo $set_str[$k]->Candidate[$n]; } } ?>  <?php
 $str_name.=$set_str[$k]->Category."||".$set_str[$k]->Name."--"; ?>
    </td>
    <td align="left" valign="middle">
    <label onclick="deleteAppSet('__ROOT__','<?php echo ($AppSet["id"]); ?>','<?php echo $set_str[$k]->Name; ?>','<?php echo ($type); ?>')" style="cursor:pointer;">
    <img src="__ROOT__/wms/Image/delete.png"/></label>
    </td>
    </tr>
    <tr><td colspan="3" height="10"></td></tr>
    </table>                                
    <?php } $str_name=substr($str_name,0,strlen($str_name)-2); ?>
    
    
    
    </td></tr>
    <tr><td align="center" valign="middle" height="35">
    <input type="button" value="保存" onclick="saveAppSet('__ROOT__','<?php echo ($AppSet["id"]); ?>','<?php echo ($str_name); ?>','<?php echo ($type); ?>')" style="cursor:pointer;"/>
    </td></tr>
    </table>
    
    </td></tr></table>
    
    </center>
    </body>
</html>