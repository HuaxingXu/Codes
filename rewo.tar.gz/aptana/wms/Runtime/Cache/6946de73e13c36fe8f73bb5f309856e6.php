<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
        <link type="text/css" href="__ROOT__/wms/Css/css.css" rel="stylesheet">
		<script src="__ROOT__/wms/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/index.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/productIntroduce.js" type="text/javascript"></script>
		<title>网站后台管理-最新产品介绍</title> 
	</head>
	<body>
    <center>
    
    <table width="100%">
    <tr><td align="left" valign="top">
    
    
	<!-- 头部 -->
<table width="100%">
	<tr><td align="left" height="85" valign="middle" class="MainTitle">
    &nbsp;&nbsp;网站后台管理系统
    </td></tr>
    <tr><td align="left" valign="middle" class="top_location">
    	<table width="100%" border="0">
        	<tr><td width="40%" align="left" valign="middle">
            &nbsp;>>> <?php echo ($user); ?> 欢迎使用火里火网站后台管理系统
            </td>
            <td width="30%"></td>
            <td width="30%" align="right" valign="middle">
            <a href="__ROOT__/wms/index.php/Login/logout">注销登录</a>&nbsp;
            </td></tr>
        </table>
    </td></tr>
</table>

    <table width="100%" cellpadding="0" cellspacing="0" border="0">
    	<tr>
        	<td align="center" valign="top" height="475px" width="215px">
            <div style="width:215px; height:475px; overflow-y:auto; overflow-x:hidden">
            	<table id="nav_tb">
	<tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_product')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    产品管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_product" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">产品系列管理</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Product/product'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">产品列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/ProductIntroduce/productIntroduce'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">最新产品介绍</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    </table>
    
    </div>
    </td></tr>
    
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_app')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    应用管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_app" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">增加应用</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    -->
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/App/app'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">应用列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
     <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/AppIntroduce/appIntroduce'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">最新应用介绍</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    
    </table>
    
    </div>
    </td></tr>
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_user')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    用户管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_user" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/User/user'"  onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    
    
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserApp/userApp'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户应用列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    
<!-- add by yzf -->
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserProduct/userProduct'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户产品列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserFriends/userFriends'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户好友列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
<!-- end by yzf -->


<!-- add by yzf -->
	<tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserProductCatch/userProductCatch'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户行为记录列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserProductKey/userProductKey'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">互动关键字列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>

    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserProductReturn/userProductReturn'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">rewo反应列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
<!-- end by yzf -->
    
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户购物车列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>-->
    </table>
    
    </div>
    </td></tr>
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_manager')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    后台账号</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_manager" style="display:block;">
    <div class="sub_nav">
   
    <table border="0" cellpadding="0" cellspacing="0">
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">增加账号</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>-->
    
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Manager/root'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">修改超级账号</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    </table>
   
    </div>
    </td></tr>
</table>

            </div>
            </td>
            <td class="split_line">&nbsp;
            </td>
        	<td align="left" valign="top" height="475" width="100%">
            <div id="main_content" style="width:100%; float:left; height:475px; overflow-y:auto; overflow-x:auto"> 
            
            <!-- 产品 -->
            	
                <table width="100%">
	<tr><td align="left" valign="bottom" class="productSeries">
    
        <table>
        	<tr><td colspan="2" height="7"></td></tr>
        	<tr><td width="15"></td>
            <td align="center" valign="bottom" style="width:130px; height:20px;background-color:#FFFFFF;">产品管理/最新产品介绍</td>
            </tr>
        </table>
        
    </td></tr>
    
    <tr><td align="left" valign="top">
    
    	<table border="0" cellpadding="0" cellspacing="0" class="productSeriesList">
        	<tr class="productSeriesListTH">
            	<td align="center" valign="middle" width="50">序号</td>
            	<td align="center" valign="middle" width="100">系列名</td>
            	<td align="center" valign="middle" width="100">标题</td>
                <td align="center" valign="middle" width="100">内容</td>
                <td align="center" valign="middle" width="60">图标</td>
                <td align="center" valign="middle" width="60">图片</td>
                <td align="center" valign="middle" width="130">操作</td>
            </tr>
            
            <tr>
            	<td align="center" valign="middle">
                <?php echo ($nowid); ?><input type="hidden" id="id" value="<?php echo ($nowid); ?>"/>
                </td>
                <td align="center" valign="middle">
		<?php echo ($productSeriesSelect); ?>
                </td>
                <td align="center" valign="middle">
                <input type="text" id="title" style="width:150px;" value=""/>
                </td>
                <td align="center" valign="middle">
                <textarea cols="17" id="content"></textarea>
                </td>
                <td align="center" valign="middle">
                <input type="text" id="coin" style="width:120px;" value=""/>
                </td>
                <td align="center" valign="middle">
                <input type="text" id="image" style="width:120px;" value=""/>
                </td>
                
                <td align="center" valign="middle">
                <input type="button" value="增加" onclick="dealProductIntroduce('__ROOT__','add','')" style="cursor:pointer;"/>
                </td>
            </tr>
            
            
            <?php if(is_array($productIntroduceList)): foreach($productIntroduceList as $key=>$productIntroduce): ?><tr style="background-color:<?php echo ($productIntroduce["bgColor"]); ?>;" onmouseover="tbMouseover(this)" onmouseout="tbMouseout(this,'<?php echo ($productIntroduce["bgColor"]); ?>')">
            	<td align="center" valign="middle">
                <?php echo ($productIntroduce["id"]); ?><input type="hidden" id="id_<?php echo ($productIntroduce["id"]); ?>" value="<?php echo ($productIntroduce["id"]); ?>"/>
                </td>
                <td align="center" valign="middle">
		<?php echo ($productIntroduce["productSeriesSelect"]); ?>               
		 </td>
                <td align="center" valign="middle">
                <input type="text" id="title_<?php echo ($productIntroduce["id"]); ?>" style="width:150px;" value="<?php echo ($productIntroduce["title"]); ?>"/>
                </td>
                <td align="center" valign="middle">
                <textarea cols="17" id="content_<?php echo ($productIntroduce["id"]); ?>"><?php echo ($productIntroduce["content"]); ?></textarea>
                </td>
                <td align="center" valign="middle">
                <input type="text" id="coin_<?php echo ($productIntroduce["id"]); ?>" style="width:120px;" value="<?php echo ($productIntroduce["coin"]); ?>"/>
                </td>
                <td align="center" valign="middle">
                <input type="text" id="image_<?php echo ($productIntroduce["id"]); ?>" style="width:120px;" value="<?php echo ($productIntroduce["image"]); ?>"/>
                </td>
            	
                <td align="center" valign="middle">
                <input type="button" value="修改" onclick="dealProductIntroduce('__ROOT__','mod','_<?php echo ($productIntroduce["id"]); ?>')" style="cursor:pointer;"/>
                <input type="button" value="删除" onclick="dealProductIntroduce('__ROOT__','del','_<?php echo ($productIntroduce["id"]); ?>')" style="cursor:pointer;"/>
                </td>
             </tr><?php endforeach; endif; ?>
            
            
         
         </table>
         
    </td></tr>
    
</table>
                
            <!-- 产品end -->
                
            </div>
            </td>
        </tr>
    </table>
    
		
    <!-- 底部 -->
<table width="100%">
	<tr><td align="center" valign="middle" class="footer">
    <hr style="color:#d3d3d3"/>
    POWERED BY WO-Rehov @2012
    </td></tr>
</table>
	
    </td></tr></table>
    
    </center>
    </body>
</html>