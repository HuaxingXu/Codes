<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta content =text/html; charset="UTF-8" http-equiv="Content-Type">
        <link type="text/css" href="__ROOT__/wms/Css/css.css" rel="stylesheet">
		<script src="__ROOT__/wms/Script/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/index.js" type="text/javascript"></script>
        <script src="__ROOT__/wms/Script/manager.js" type="text/javascript"></script>
		<title>网站后台管理-后台账号</title> 
	</head>
	<body>
    <center>
    
    <table width="100%">
    <tr><td align="left" valign="top">
    
    
	<!-- 头部 -->
<table width="100%">
	<tr><td align="left" height="85" valign="middle" class="MainTitle">
    &nbsp;&nbsp;网站后台管理系统
    </td></tr>
    <tr><td align="left" valign="middle" class="top_location">
    	<table width="100%" border="0">
        	<tr><td width="40%" align="left" valign="middle">
            &nbsp;>>> <?php echo ($user); ?> 欢迎使用火里火网站后台管理系统
            </td>
            <td width="30%"></td>
            <td width="30%" align="right" valign="middle">
            <a href="__ROOT__/wms/index.php/Login/logout">注销登录</a>&nbsp;
            </td></tr>
        </table>
    </td></tr>
</table>

    <table width="100%" cellpadding="0" cellspacing="0" border="0">
    	<tr>
        	<td align="center" valign="top" height="475px" width="215px">
            <div style="width:215px; height:475px; overflow-y:auto; overflow-x:hidden">
            	<table id="nav_tb">
	<tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_product')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    产品管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_product" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">产品系列管理</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Product/product'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">产品列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/ProductIntroduce/productIntroduce'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">最新产品介绍</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    </table>
    
    </div>
    </td></tr>
    
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_app')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    应用管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_app" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">增加应用</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    -->
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/App/app'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">应用列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
     <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/AppIntroduce/appIntroduce'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">最新应用介绍</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    
    </table>
    
    </div>
    </td></tr>
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_user')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    用户管理</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_user" style="display:block;">
    <div class="sub_nav">
    
    <table border="0" cellpadding="0" cellspacing="0">
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/User/user'"  onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    
    
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserApp/userApp'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户应用列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    
<!-- add by yzf -->
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserProduct/userProduct'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户产品列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/UserFriends/userFriends'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户好友列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
<!-- end by yzf -->


<!-- add by yzf -->
	<tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Manager/root'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户行为记录列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Manager/root'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">互动关键字列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>

    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Manager/root'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">rewo反应列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
<!-- end by yzf -->
    
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">用户购物车列表</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>-->
    </table>
    
    </div>
    </td></tr>
    
    <tr><td align="center" valign="middle"><button onclick="SubNavHideShow('sub_nav_manager')">
    <img src="__ROOT__/wms/Image/nav_button_coin.jpg"/>
    后台账号</button></td></tr>
    <tr><td align="center" valign="top" id="sub_nav_manager" style="display:block;">
    <div class="sub_nav">
   
    <table border="0" cellpadding="0" cellspacing="0">
    <!--
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">增加账号</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>-->
    
    <tr><td style="height:3px; background-color:#ffffff;"></td></tr>
    <tr><td valign="top" align="center">
    <table border="0" cellpadding="0" cellspacing="0" class="nav_out_class" onclick="document.location.href='__ROOT__/wms/index.php/Manager/root'" onmouseover="navMouseover(this)" onmouseout="navMouseout(this)">
    <tr><td class="nav_leftTd"></td>
    <td rowspan="2" align="left" valign="middle">修改超级账号</td></tr><tr>
    <td align="right" valign="top"><img src="__ROOT__/wms/Image/nav_coin.jpg"/>&nbsp;</td></tr></table>
    </td></tr>
    </table>
   
    </div>
    </td></tr>
</table>

            </div>
            </td>
            <td class="split_line">&nbsp;
            </td>
        	<td align="left" valign="top" height="475" width="100%">
            <div id="main_content" style="width:100%; float:left; height:475px; overflow-y:auto; overflow-x:auto"> 
            
            <!-- root -->
            <table width="100%">
			<tr><td align="left" valign="bottom" class="productSeries">
    
        		<table>
        			<tr><td colspan="2" height="7"></td></tr>
        			<tr><td width="15"></td>
            		<td align="center" valign="bottom" style="width:160px; height:20px;background-color:#FFFFFF;">后台账号/修改超级账号</td>
            		</tr>
        		</table>
        
    		</td></tr>
            
            <tr><td align="left" valign="top">
            	<table border="0" cellpadding="0" cellspacing="0">
                	<tr><td align="right" valign="middle">>> 修改 <font style="font-size:14px;"><?php echo ($user); ?></font> 密码：</td>
                    	<td></td>
                    </tr>
                    <tr><td colspan="2" height="2"></td></tr>
                	<tr>
                    	<td align="right" valign="middle">现在的密码：</td>
                        <td align="left" valign="middle">
                        	<input type="password" id="old_password" value=""/>
                        </td>
                    </tr>
                    <tr><td colspan="2" height="8"></td></tr>
                    <tr>
                    	<td align="right" valign="middle">设置新的密码：</td>
                        <td align="left" valign="middle">
                        	<input type="password" id="new_password" value=""/>
                        </td>
                    </tr>
                    <tr><td colspan="2" height="8"></td></tr>
                    <tr>
                    	<td align="right" valign="middle">重复新的密码：</td>
                        <td align="left" valign="middle">
                        	<input type="password" id="new_password2" value=""/>
                        </td>
                    </tr>
                    <tr><td colspan="2" height="8"></td></tr>
                    <tr><td></td><td align="left" valign="top">
                    	<input type="button" value="确定" onclick="modRootPWD('__ROOT__')"/>
                    </td></tr>
                    <tr><td colspan="2" height="8"></td></tr>
                    <tr><td></td><td align="left" valign="top" id="root_tip" style="font-size:13px;">
                    	
                    </td></tr>
                </table>
            </td></tr>
            
    		</table>
            <!-- root end -->
                
            </div>
            </td>
        </tr>
    </table>
    
		
    <!-- 底部 -->
<table width="100%">
	<tr><td align="center" valign="middle" class="footer">
    <hr style="color:#d3d3d3"/>
    POWERED BY WO-Rehov @2012
    </td></tr>
</table>
	
    </td></tr></table>
    
    </center>
    </body>
</html>