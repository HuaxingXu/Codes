/* 应用评论js */

function dealAppComment(root,operation,pos)
{
	now_id=Number($("#id"+pos).val());
	now_app_id=$("#app_id"+pos).val();
	now_comment_name=$("#comment_name"+pos).val();
	now_comment_content=$("#comment_content"+pos).val();
	now_comment_time=$("#comment_time"+pos).val();
	now_level=Number($("#level"+pos).val());
	

	if(now_app_id=="")
	{
		alert("请输入应用编号！");
		return
	}
	if(now_comment_name=="")
	{
		alert("请输入评论者名字！");
		return
	}
	if(now_comment_content=="")
	{
		alert("请输入评论内容！");
		return
	}

	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/AppComment/dealAppComment",
		dataType:"json",
		data:{"operation":operation,
			  "id":now_id,
			  "app_id":now_app_id,
			  "comment_name":now_comment_name,
			  "comment_content":now_comment_content,
			  "comment_time":now_comment_time,
			  "level":now_level},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
				alert("成功！");
				document.location.reload();
			}
			else
				alert(json.desc);
			return
		}
		alert("连接服务器失败！");
		}
	});
	
}


