/* 帮助支持js */

function dealHelp(root,operation,pos)
{
	now_id=Number($("#id"+pos).val());
	now_question=$("#question"+pos).val();
	now_answer=$("#answer"+pos).val();
	now_type_id=$("#type_id"+pos).val();
	now_type_name=$("#type_name"+pos).val();
	

	if(now_type_id=="")
	{
		alert("请输入问题类型编号！");
		return
	}
	if(now_type_name=="")
	{
		alert("请输入问题类型名字！");
		return
	}
	if(now_question=="")
	{
		alert("请输入问题！");
		return
	}
	if(now_answer=="")
	{
		alert("请输入答案！");
		return
	}


	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/Help/dealHelp",
		dataType:"json",
		data:{"operation":operation,
			  "id":now_id,
			  "type_id":now_type_id,
			  "type_name":now_type_name,
			  "question":now_question,
			  "answer":now_answer},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
				alert("成功！");
				document.location.reload();
			}
			else
				alert(json.desc);
			return
		}
		alert("连接服务器失败！");
		}
	});
	
}


