/* 首页js */



function navMouseover(nav_id)
{
	$(nav_id).attr("class",'nav_over_class');
}

function navMouseout(nav_id)
{
	$(nav_id).attr("class",'nav_out_class');
}

function SubNavHideShow(sub_nav_id)
{
	now_var=document.getElementById(sub_nav_id).style.display;
	if(now_var=="block")
		$("#"+sub_nav_id).hide(100);
	else
		$("#"+sub_nav_id).show(100);
}

function tbMouseover(tb_id)
{
	if($(tb_id).attr("style")!='background-color:#ababab;')
		$(tb_id).attr("style",'background-color:#eeeeee;');
}

function tbMouseClick(tb_id,src_color)
{
	if($(tb_id).attr("style")!='background-color:#ababab;')
		$(tb_id).attr("style",'background-color:#ababab;');
	else
		$(tb_id).attr("style","background-color:"+src_color+";");
}

function tbMouseout(tb_id,src_color)
{
	if($(tb_id).attr("style")!='background-color:#ababab;')
		$(tb_id).attr("style","background-color:"+src_color+";");
}


function OpenWin(now_url,now_width,now_height)
{
	now_top=0;
	now_top1=Number(document.documentElement.scrollTop);
	now_top2=Number(document.body.scrollTop);
	now_top=now_top1;
	if(now_top==0)
		now_top=now_top2;
		
	now_left=(screen.width)/2-337;
	now_top3=(screen.height)/2-300+now_top;
	window.open(now_url,"_blank","width="+now_width+",height="+now_height+",left="+now_left+",top="+now_top3+",status=no,resizable=yes");     
}

function OpenWinMin(now_url,now_width,now_height)
{
	now_top=0;
	now_top1=Number(document.documentElement.scrollTop);
	now_top2=Number(document.body.scrollTop);
	now_top=now_top1;
	if(now_top==0)
		now_top=now_top2;
		
	now_left=(screen.width)/2-217;
	now_top3=(screen.height)/2-150+now_top;
	window.open(now_url,"_blank","scrollbars=no,width="+now_width+",height="+now_height+",left="+now_left+",top="+now_top3+",toolbar=no,menubar=no, scrollbars=no,resizable=no,location=no,status=no");     
}


function make_app_setstr(length,n)
{
	restr="";
	for(p=0;p<length;p++)
	{
		if(p==n)
			restr+="1";
		else
			restr+="0";
	}
	return restr;
}

//通知守护进程用户在网站前端更改了应用
function notifyUpdateConfig(root,user_id,app_id,is_new)
{
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProduct/notifyUpdateAppConfig",
		dataType:"text",
		data:{"user_id":user_id,
			  "app_id":app_id,
			  "is_new":is_new}
		});
}
function broadcastNotifyUpdateConfig(root,app_id,is_new)
{
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProduct/broadcastNotifyUpdateAppConfig",
		dataType:"text",
		data:{"app_id":app_id,
			  "is_new":is_new}
		});
}
function broadcastGetClientFile(root,app_id)
{
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProduct/broadcastGetClientFile",
		dataType:"text",
		data:{"app_id":app_id},
		success: function(json) {
			alert("已经发送了要更新zip包消息给机器人了");	
		}
		});
}
//重新生成用户语音命令文件
function RemakeUserSpeechFile(root,user_id)
{
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProduct/remakeUserSpeechFile",
		dataType:"text",
		data:{"user_id":user_id},
		success: function(json) {
			document.location.reload();	
		}
	});
}
//重新生成用户联系人字典文件
function RemakeUserFriendsFile(root,user_id)
{
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProduct/remakeUserFriendsFile",
		dataType:"text",
		data:{"user_id":user_id},
		success: function(json) {
			document.location.reload();	
		}
	});
}
