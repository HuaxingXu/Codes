function checkLogin(root)
{
  username=$("#username").val();
  password=$("#password").val();
  if(username=="")
    $("#login_tip").html("请输入用户名！");
  else if(password=="")
    $("#login_tip").html("请输入密码！");
  else
  {
     $.ajax({
				type: "POST",
				url: root+"/wms/index.php/Login/login",
				dataType:"json",
				data:{"username":username,"password":password},
				beforeSend: function() {
					if (!(username == "" || password == "")) {
						 $("#login_tip").html("<font size='2' color='green'>正在验证登录...</font>");
					}
				},
				success: function(json) {
					$("#login_tip").html("");
					re_str="";
					if(json!=null)
					{
						if(json.state==1)
							document.location.href=root+"/wms/index.php/Index/index";
						else
							$("#login_tip").html(json.desc);
						return
					}
					$("#login_tip").html("连接服务器失败！");
				}
			});
  }
}