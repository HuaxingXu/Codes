/* 最新产品js */

function dealProductIntroduce(root,operation,pos)
{
	now_id=Number($("#id"+pos).val());
	now_series_id=Number($("#series_id"+pos).val());
	now_title=$("#title"+pos).val();
	now_content=$("#content"+pos).val();
	now_coin=$("#coin"+pos).val();
	now_image=$("#image"+pos).val();

	if(now_series_id==0)
	{
		alert("请先添加产品系列！");
		return
	}
	if(now_title=="")
	{
		alert("请输入介绍产品的标题！");
		return
	}

	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/ProductIntroduce/dealProductIntroduce",
		dataType:"json",
		data:{"operation":operation,
			  "id":now_id,
			  "series_id":now_series_id,
			  "title":now_title,
			  "content":now_content,
			  "coin":now_coin,
			  "image":now_image},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
				alert("成功！");
				document.location.reload();
			}
			else
				alert(json.desc);
			return
		}
		alert("连接服务器失败！");
		}
	});
	
}
