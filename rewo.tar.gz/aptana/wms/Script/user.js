/* 用户js */

function dealUser(root,operation,pos)
{
	now_id=Number($("#id"+pos).val());
	now_username=$("#username"+pos).val();
	now_password=$("#password"+pos).val();
	now_email=$("#email"+pos).val();
	now_encode=$("#encode"+pos).val();
	now_nickname=$("#nickname"+pos).val();
	now_sex=$("#sex"+pos).val();
	now_balance=$("#balance"+pos).val();
	now_flag=$("#flag"+pos).val();
	now_getpwdlink_str=$("#getpwdlink_str"+pos).val();
	now_getpwdlink_time=$("#getpwdlink_time"+pos).val();
	now_signature=$("#signature"+pos).val();
	now_age=$("#age"+pos).val();
	now_location=$("#location"+pos).val();
	now_constellation=$("#constellation"+pos).val();
	now_last_login_time=$("#last_login_time"+pos).val();
	
	if(now_username=="")
	{
		alert("请输入用户名称！");
		return
	}

	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/User/dealUser",
		dataType:"json",
		data:{"operation":operation,
			  "id":now_id,
			  "username":now_username,
			  "password":now_password,
			  "email":now_email,
			  "encode":now_encode,
			  "nickname":now_nickname,
			  "sex":now_sex,
			  "balance":now_balance,
			  "flag":now_flag,
			  "getpwdlink_str":now_getpwdlink_str,
			  "getpwdlink_time":now_getpwdlink_time,
			  "signature":now_signature,
			  "age":now_age,
			  "location":now_location,
			  "constellation":now_constellation,
			  "last_login_time":now_last_login_time},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
				alert("成功！");
				document.location.reload();
			}
			else
				alert(json.desc);
			return
		}
		alert("连接服务器失败！");
		}
	});
	
}