/* 用户应用js */

function dealUserApp(root,operation,pos)
{
	now_user_id=Number($("#user_id"+pos).val());
	now_app_id=Number($("#app_id"+pos).val());
	now_setting=$("#setting"+pos).val();
	now_word=$("#word"+pos).val();
	now_flag=$("#flag"+pos).val();
	now_speech_command=$("#speech_command"+pos).val();
	now_rfid_card=$("#rfid_card"+pos).val();
	now_language_flag=$("#language_flag"+pos).val();
	now_set_file_num=Number($("#set_file_num"+pos).val());
	now_set_file_name=$("#set_file_name"+pos).val();
	
	
	if(now_user_id=="")
	{
		alert("请输入用户ID！");
		return
	}
	if(now_app_id=="")
	{
		alert("请输入应用ID！");
		return
	}

	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserApp/dealUserApp",
		dataType:"json",
		data:{"operation":operation,
			  "user_id":now_user_id,
			  "app_id":now_app_id,
			  "setting":now_setting,
			  "word":now_word,
			  "flag":now_flag,
			  "speech_command":now_speech_command,
			  "rfid_card":now_rfid_card,
			  "set_file_num":now_set_file_num,
		          "set_file_name":now_set_file_name,
			  "language_flag":now_language_flag},
		success: function(json) {
		if(json!=null)
		{
			if(json.state==1)
			{
				alert("成功！");
				
				is_new="modify";
				if(operation="add")
					is_new="add";
				if(operation="del")
					is_new="delete";
				notifyUpdateConfig(root,now_user_id,now_app_id,is_new);
				RemakeUserSpeechFile(root,now_user_id);
				//document.location.reload();
			}
			else
				alert(json.desc);
			return
		}
		alert("连接服务器失败！");
		}
	});
	
}

function openUserAppSetWin(root,app_id,user_id,set_file_num)
{   
	OpenWin(root+"/wms/index.php/UserApp/userAppOpenWin?app_id="+app_id+"&user_id="+user_id+"&set_file_num="+set_file_num,600,450);
}

function saveUserAppSet(root,app_id,user_id,arr_name,set_file_num)
{

	if(!confirm("确定保存该应用设置为当前配置吗？")){
		return
	}
	
	setting_str="";
	arr_name=arr_name.split("-"); 
	for(n=0;n<arr_name.length;n++)
	{
		arr_name2=arr_name[n].split(":"); 
		set_type=arr_name2[0];
		set_name=arr_name2[1];
		set_value="";
		if(set_type=="EditText")
		{
			set_value=$("#"+set_name).val();
		}
		else if(set_type=="RadioGroup")
		{
			set_value=$("input[name='"+set_name+"']:checked").val();
		}
		else if(set_type=="CheckBox")
		{
			set_value=1;
			for(p=0;p<$("input[name='"+set_name+"']").length;p++)
				set_value*=10;
			$("input[name='"+set_name+"']:checked").each(function(){ 
 				set_value+=Number($(this).val());
 			});
			set_value=String(set_value);
			set_value=set_value.substr(1,set_value.length);
		}
		setting_str+=set_name+":"+set_value+"-";
	}
	if(setting_str!="")
		setting_str=setting_str.substr(0,setting_str.length-1);


	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserApp/saveUserAppSet",
		dataType:"json",
		data:{"setting_str":setting_str,
			   "app_id":app_id,
			   "set_file_num":set_file_num,
			   "user_id":user_id},
		success: function(json) {
			if(json!=null)
			{
				if(json.state==1)
				{
					alert("保存成功");
					notifyUpdateConfig(root,user_id,app_id,"modify");
				}	
				else
				{
					alert(json.desc);
				}
			}
		}
		});

}

