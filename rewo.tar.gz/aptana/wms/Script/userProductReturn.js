/*rewo反应js*/

function dealUserProductReturn(root, operation, pos) {
	
	var id = Number($("#id" + pos).val());
	var key_id = Number($("#key_id" + pos).val());
	var type = $("#type" + pos).val();
	var content = $("#content" + pos).val();
	var time = $("#time" + pos).val();
/*
	if(key_id == "") {
		alert("请输入关键字ID！");
		return
	}*/
	if(type == "") {
		alert("请输入类型！");
		return
	}
	if(content == "") {
		alert("请输入内容！");
		return
	}
	if(time == "") {
		alert("请输入时间！");
		return
	}
	
	$.ajax({
		type: "POST",
		url: root+"/wms/index.php/UserProductReturn/dealUserProductReturn",
		dataType:"json",
		data:{"operation":operation,
			  "id":id,
			  "key_id":key_id,
			  "type":type,
			  "content":content,
			  "time":time},
		success: function(json) {
			if(json != null) {
				if(json.state == 1)
				{
					alert("成功！");
					document.location.reload();
				}
				else {
					alert(json.desc);
				}
				return
			}
			alert("连接服务器失败！");
		}
	});
}
