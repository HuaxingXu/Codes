<?php
error_reporting(7);
date_default_timezone_set("Asia/Shanghai");
header("Content-type:text/html; Charset=utf-8");
require_once("image.class.php");

function uploadHeadImage($user_path)
{
	$images = new Images("file","","","aptana/public_image/user/".$user_path);
	$path = $images->move_uploaded();
	//$images->thumb($path,false,0);							
	if($path == false){
		return $images->get_errMsg();
	}else{
		return $images->file_newname;
	}
}

function cutHeadImage($user_path,$file_name)
{
	$images = new Images("file","","","aptana/public_image/user".$user_path);//,"","","../public_image/user".$user_path
	$image = "aptana/public_image/user".$user_path.$file_name;
	$res = $images->thumb($image,false,1);
	if($res == false){
		return "裁剪失败！";
	}else{
		return "裁剪成功！";
	}
}
