<?php

define('APP_NAME', 'web');
define('APP_PATH', './');
define('APP_DEBUG', TRUE);

require( "aptana/ThinkPHP/ThinkPHP.php" );
