<?php
//邮件函数
require("class.phpmailer.php"); 
date_default_timezone_set("Asia/Shanghai");

function sendEmail($send_mail,$send_name,$title,$content) {
$mail = new PHPMailer(); 

/*
$mail->IsSMTP(); 
$mail->Host = "smtp.163.com"; 
$mail->SMTPAuth = true; 
$mail->Username = "rewomail@163.com"; 
$mail->Password = "rewomail123"; 
$mail->Port=25;
$mail->From = "rewomail@163.com"; 
$mail->FromName = "REWO";
$mail->AddAddress("$send_mail", "$send_name");

$mail->AddReplyTo("rewomail@163.com", "REWO");
//$mail->AddAttachment("/var/tmp/file.tar.gz"); 
//$mail->IsHTML(true); // set email format to HTML 

$mail->Subject = $title; 
$mail->Body = $content; 
*/

	$mail->IsSMTP();                                      // set mailer to use SMTP
	$mail->Host = "irewo.com";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "rewo";  // SMTP username
	$mail->Password = "rewo"; // SMTP password
	$mail->From = "rewo@irewo.com";
	$mail->FromName = "rewo";

	$mail->AddAddress($send_mail, $send_name);
	$mail->Subject = $title;
	$mail->Body    =  $content;


//$mail->AltBody = "This is the body in plain text for non-HTML mail clients"; 
if(!$mail->Send())
{
//echo "fault<p>";
//echo "error:" . $mail->ErrorInfo;
return false;
exit;
}
return true;

}



/*


function send_email($address, $subject, $body) {
	$mail = new PHPMailer();

	$mail->IsSMTP();                                      // set mailer to use SMTP
	$mail->Host = "irewo.com";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "rewo";  // SMTP username
	$mail->Password = "rewo"; // SMTP password
	$mail->From = "rewo@irewo.com";
	$mail->FromName = "rewo";

	$mail->AddAddress($address['email'], $address['name']);
	$mail->Subject = $subject;
	$mail->Body    = $body;

	$return_arr = array();
	$return_arr['status'] = 0;
	$return_arr['desc'] = "";
	if ($mail->Send()) {
		$return_arr['status'] = 1;
		$return_arr['desc'] = "success";
	}
	else {
		$return_arr['desc'] = $mail->ErrorInfo;
	}

	return json_encode($return_arr);
}

*/



?>
